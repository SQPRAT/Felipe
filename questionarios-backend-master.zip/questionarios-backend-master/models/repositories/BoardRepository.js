import Sequelize from 'sequelize';

const { Model, DataTypes, Op } = Sequelize;
export class Board extends Model {
  static init(sequelize) {
    super.init({
      name: DataTypes.STRING,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.hasMany(models.Test, { foreignKey: 'boardId', as: 'tests' });
  }
}

export const find = async (keyword) => {
  try {
    const board = await Board.findOne({
      where: {
        name: {
          [Op.like]: `%${(keyword || '')}%`
        }
      }
    })

    return board ? board.dataValues : null;
  } catch {
    return null;
  }
}

export const search = async (keyword) => {
  try {
    const boards = await Board.findAll({
      where: {
        ...(keyword ? ({
          name: {
            [Op.like]: `%${(keyword || '')}%`
          }
        }) : ({})),
      }
    });

    return boards;
  } catch {
    return null;
  }
}

export const save = async board => await Board.create(board);
