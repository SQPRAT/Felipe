import Sequelize from 'sequelize';
import moment from 'moment';
import { ITEMS_PER_PAGE } from '../../config/constants.js';
import Pages from '../../services/Pages.js';

const { Model, Op } = Sequelize;

export class Question extends Model {
  static init(sequelize) {
    super.init({
      description: Sequelize.TEXT,
      explanation: Sequelize.TEXT,
      answers: Sequelize.JSON,
      position: Sequelize.INTEGER,
      isCommented: Sequelize.BOOLEAN,
      isDraft: Sequelize.BOOLEAN
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsTo(models.Test, { foreignKey: 'testId', as: 'test' });
    this.belongsTo(models.User, { foreignKey: 'createdBy', as: 'owner' });
    this.belongsToMany(models.Branch, {
      through: models.QuestionBranch,
      as: 'questionBranches',
      foreignKey: 'questionId',
      otherKey: 'branchId',
    });
    this.belongsToMany(models.Badge, {
      through: models.QuestionBadge,
      as: 'questionBadges',
      foreignKey: 'questionId',
      otherKey: 'badgeId',
    });
  }
}

export const save = async question => await Question.create(question);

export const search = async ({
  keyWord = '',
  page = 0,
  userId = null,
  testId = null,
}) => await Question.findAll({
  where: {
    [Sequelize.Op.or]: [
      {
        description: {
          [Sequelize.Op.like]: `%${keyWord}%`
        },
        explanation: {
          [Sequelize.Op.like]: `%${keyWord}%`
        },
      },
    ],
    ...(userId ? { createdBy: userId } : {}),
    ...(testId ? { testId } : {}),
  },
  order: [
    ['id', 'ASC'],
  ],
  offset: page * ITEMS_PER_PAGE,
  limit: ITEMS_PER_PAGE
});

export const countPages = async ({
  userId = null,
  testId = null,
}) => {
  const where = {
    ...(userId ? { createdBy: userId } : {}),
    ...(testId ? { testId } : {})
  }
  const amount = await Question.count({ where });
  const amountOfPages = Pages.calcPages(amount);

  return amountOfPages;
}

export const findById = async id => {
  if (!id) return null;

  try {
    const question = await Question.findByPk(id, {
      include: [
        {
          association: 'questionBranches',
        },
        {
          association: 'questionBadges'
        }
      ],
    });

    if (!question) return null;

    return question.dataValues;
  } catch {
    return null;
  }
}

export const findAfterPositionByTest = (testId, position) => findByTest(testId, {
  position: {
    [Op.gt]: Number(position),
  },
});

export const findByTest = async (testId, filters = {}) => {
  if (!testId) return null;

  try {
    const questions = await Question.findAll({
      where: {
        testId,
        ...filters,
      },
      include: [
        { association: 'questionBadges', as: 'badges' },
      ],
    })

    return questions.map((q) => ({ ...q.dataValues, badges: q.questionBadges }));
  } catch {
    return null;
  }
}

export const findByIdWithBranches = async id => {
  if (!id) return null;

  try {
    const question = await Question.findByPk(id, {
      include: [
        { association: 'questionBranches', as: 'branches' },
        { association: 'questionBadges', as: 'badges' },
        { association: 'test', as: 'test' },
      ]
    });

    if (!question) return null;

    return question.dataValues;
  } catch {
    return null;
  }
}

export const updateById = async (id, newProps, callback) => {
  try {
    await Question.update(newProps, {
      where: {
        id,
      }
    }).then(callback.onUpdated).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ]);
  }
}

export const deleteById = async (id, callback) => {
  try {
    await Question.destroy({
      where: {
        id
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}

export const countByTest = async (testId) => {
  const amountOfQuestions = await Question.count({
    where: {
      testId,
    }
  });

  return amountOfQuestions;
};

export const INCLUDER_FILTERS = {
  createdAtAfter: date => ({
    createdAt: {
      [Op.gt]: moment(date).format(),
    }
  }),
  outOfDate: () => ({
    '$questionBadges.name$': 'Desatualizada',
  }),
  canceled: () => ({
    '$questionBadges.name$': 'Anulada',
  }),
  adapted: () => ({
    '$questionBadges.name$': 'Adaptada',
  }),
  review: () => ({
    '$questionBadges.name$': 'Revisar',
  }),
  year: year => ({
    '$test.year$': year
  }),
  type: type => ({
    '$test.type$': type
  }),
  questionTypes: questionTypes => ({
    '$test.questionTypes$': questionTypes
  }),
};

export const BLOCKER_FILTERS = {
  outOfDate: () => ({
    '$questionBadges.name$': {
      [Op.ne]: 'Desatualizada',
    },
  }),
  canceled: () => ({
    '$questionBadges.name$': {
      [Op.ne]: 'Anulada',
    },
  }),
  adapted: () => ({
    '$questionBadges.name$': {
      [Op.ne]: 'Adaptada',
    },
  }),
  review: () => ({
    '$questionBadges.name$': {
      [Op.ne]: 'Revisar',
    },
  }),
  createdAtAfter: date => ({
    createdAt: {
      [Op.lt]: moment(date).format(),
    }
  }),
  commiteds: () => ({
    isCommented: true,
  }),
  notCommiteds: () => ({
    isCommented: false,
  }),
  year: year => ({
    '$test.year$': {
      [Op.ne]: year
    }
  }),
  type: type => ({
    '$test.type$': {
      [Op.ne]: type
    }
  }),
  questionTypes: questionTypes => ({
    '$test.questionTypes$': {
      [Op.ne]: questionTypes
    }
  }),
};

export const createWhereFiltersFromHash = (hash, filtersArray, includerFilter = true) => filtersArray.reduce((filters, { key, value }) => {
  const currentFilterFunction = hash[key];

  if (!currentFilterFunction) return { ...filters };

  const currentFilter = currentFilterFunction(value);
  const [currentKeyFilter] = Object.keys(currentFilter);
  const isDuplicatedKeyFilter = Object.keys(filters).some((keyFilter) => keyFilter === currentKeyFilter)

  if (isDuplicatedKeyFilter) {
    const operator = includerFilter ? Op.in : Op.notIn;
    const [newFilter] = Object.values(currentFilter);
    const oldFilters = filters[currentKeyFilter];
    const arrayStringOldFilters = typeof oldFilters === 'string' ? [oldFilters] : oldFilters[operator];

    if (!arrayStringOldFilters) {
      const prevFilters = filters[currentKeyFilter][Op.and] || [filters[currentKeyFilter]]

      return {
        ...filters,
        [currentKeyFilter]: {
          [Op.and]: [
            ...prevFilters,
            newFilter,
          ]
        }
      }
    }

    return {
      ...filters,
      [currentKeyFilter]: {
        [operator]: [
          ...arrayStringOldFilters,
          newFilter,
        ]
      }
    }
  }

  return { ...filters, ...currentFilter };
}, {});

const createWhereFilters = (branchesIds, boards, includerFilters = [], blockerFilters = []) => {
  const boardsWhere = (boards.length
    ? ({
      '$test.board.name$': {
        [Sequelize.Op.in]: boards
      },
    })
    : ({})
  );
  const whereIncluder = createWhereFiltersFromHash(INCLUDER_FILTERS, includerFilters);
  const whereBlocker = createWhereFiltersFromHash(BLOCKER_FILTERS, blockerFilters, false);

  return {
    ...(branchesIds?.length ? { '$questionBranches.id$': branchesIds } : {}),
    ...boardsWhere,
    ...whereIncluder,
    ...whereBlocker,
  };
};

export const count = async (boards, includerFilters, blockerFilters) => {
  const amountOfQuestions = await Question.count({
    where: createWhereFilters([], boards, includerFilters, blockerFilters),
    include: [
      { association: 'questionBadges' },
      {
        association: 'test',
        include: [
          {
            association: 'board',
          }
        ],
      },
    ],
  });

  return amountOfQuestions;
}

export const countByBranch = async (branchId, boards, includerFilters, blockerFilters, dependencies) => {
  const { repositories: { BranchRepository } } = dependencies;
  const relatedBranches = await BranchRepository.findChildrens(branchId);
  const branchesIds = relatedBranches.map(branch => branch.id);

  const amountOfQuestions = await Question.count({
    where: createWhereFilters(branchesIds, boards, includerFilters, blockerFilters),
    include: [
      { association: 'questionBranches' },
      { association: 'questionBadges' },
      {
        association: 'test',
        include: [
          {
            association: 'board',
          }
        ],
      },
    ],
  });

  return amountOfQuestions;
}

export const findRandomly = async (branchId, amount, boards, includerFilters, blockerFilters, dependencies) => {
  const { repositories: { BranchRepository } } = dependencies;
  const childrenBranches = await BranchRepository.findChildrens(branchId);
  const branchesIds = childrenBranches.map(branch => branch.id);
  const questions = await Question.findAll({
    where: createWhereFilters(branchesIds, boards, includerFilters, blockerFilters),
    order: [
      Sequelize.fn('RANDOM'),
    ],
    include: [
      { association: 'questionBranches' },
      {
        association: 'test',
        include: [
          {
            association: 'board',
          },
        ],
      },
      { association: 'questionBadges' },
    ]
  });

  return questions.slice(0, amount);
};
