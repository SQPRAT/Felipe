import Sequelize from 'sequelize';

const { Model, DataTypes } = Sequelize;

export class Badge extends Model {
  static init(sequelize) {
    super.init({
      name: DataTypes.STRING,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsToMany(models.Question, {
      through: models.QuestionBadge,
      as: 'questionBadges',
      foreignKey: 'badgeId',
      otherKey: 'questionId',
    });
  }
}

export const all = async () => await Badge.findAll();

export const save = async badge => await Badge.create(badge);

export const findById = async id => {
  if (!id) return null;

  try {
    const badge = await Badge.findByPk(id);

    if (!badge) return null;

    return badge.dataValues;
  } catch {
    return null;
  }
}

export const updateById = async (id, newProps, callback) => {
  try {
    await Badge.update(newProps, {
      where: {
        id,
      }
    }).then(callback.onUpdated).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ]);
  }
}

export const deleteById = async (id, callback) => {
  try {
    await Badge.destroy({
      where: {
        id
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}
