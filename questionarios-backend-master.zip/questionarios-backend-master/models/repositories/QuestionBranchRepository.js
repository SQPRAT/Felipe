import Sequelize from 'sequelize';
import i18next from 'i18next';
import moment from 'moment'

import { createWhereFiltersFromHash } from './QuestionRepository.js';

const { Model, Op } = Sequelize;

export class QuestionBranch extends Model {
  static init(sequelize) {
    super.init({}, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsTo(models.Branch, { foreignKey: 'branchId', as: 'branch' });
    this.belongsTo(models.Question, { foreignKey: 'questionId', as: 'question' });
  }
}

export const save = async questionBranch => await QuestionBranch.create(questionBranch);

export const INCLUDER_FILTERS = {
  createdAtAfter: date => ({
    '$question.createdAt$': {
      [Op.gt]: moment(date).format(),
    }
  }),
  outOfDate: () => ({
    '$question.questionBadges.name$': 'Desatualizada',
  }),
  canceled: () => ({
    '$question.questionBadges.name$': 'Anulada',
  }),
  adapted: () => ({
    '$question.questionBadges.name$': 'Adaptada',
  }),
  review: () => ({
    '$question.questionBadges.name$': 'Revisar',
  }),
  year: year => ({
    '$question.test.year$': year
  }),
  type: type => ({
    '$question.test.type$': type
  }),
  questionTypes: questionTypes => ({
    '$question.test.questionTypes$': questionTypes
  }),
};

export const BLOCKER_FILTERS = {
  outOfDate: () => ({
    '$question.questionBadges.name$': {
      [Op.ne]: 'Desatualizada',
    },
  }),
  canceled: () => ({
    '$question.questionBadges.name$': {
      [Op.ne]: 'Anulada',
    },
  }),
  adapted: () => ({
    '$question.questionBadges.name$': {
      [Op.ne]: 'Adaptada',
    },
  }),
  review: () => ({
    '$question.questionBadges.name$': {
      [Op.ne]: 'Revisar',
    },
  }),
  createdAtAfter: date => ({
    '$question.createdAt$': {
      [Op.lt]: moment(date).format(),
    }
  }),
  commiteds: () => ({
    '$question.explanation$': '',
  }),
  notCommiteds: () => ({
    '$question.explanation$': {
      [Op.ne]: '',
    },
  }),
  year: year => ({
    '$question.test.year$': {
      [Op.ne]: year
    }
  }),
  type: type => ({
    '$question.test.type$': {
      [Op.ne]: type
    }
  }),
  questionTypes: questionTypes => ({
    '$question.test.questionTypes$': {
      [Op.ne]: questionTypes
    }
  }),
};

const createWhereFilters = (includerFilters = [], blockerFilters = [], boards = []) => {
  const boardsWhere = (boards.length
    ? ({
      '$question.test.board.name$': {
        [Sequelize.Op.in]: boards
      },
    })
    : ({})
  );
  const whereIncluder = createWhereFiltersFromHash(INCLUDER_FILTERS, includerFilters);
  const whereBlocker = createWhereFiltersFromHash(BLOCKER_FILTERS, blockerFilters, false);

  return {
    ...boardsWhere,
    ...whereIncluder,
    ...whereBlocker,
    ...(whereBlocker['$question.questionBadges.name$'] ? ({
      '$question.questionBadges.name$': {
        [Op.or]: [
          whereBlocker['$question.questionBadges.name$'],
          { [Op.eq]: null }
        ]
      }
    }) : ({}))
  };
};

export const countByBranches = async (
  { includerFilters = [], blockerFilters = [], boards = [] },
  dependencies,
) => {
  const { repositories: { BranchRepository } } = dependencies;
  
  try {
    let qbs = await QuestionBranch.findAll({
      where: {
        ...createWhereFilters(includerFilters, blockerFilters, boards),
      },
      include: [
        {
          association: 'question',
          include: [
            {
              association: 'test',
              include: [
                {
                  association: 'board',
                }
              ]
            },
            {
              association: 'questionBadges',
            }
          ]
        }
      ]
    });

    return qbs.reduce((acc, item) => {
      if (!acc.hasOwnProperty(item.branchId)){
        acc[item.branchId] = 1;
      } else {
        acc[item.branchId]++;
      }
      return acc;
    }, {});
    
  } catch {
    return {};
  }
}

export const countByBranch = async (
  branchId,
  { includerFilters = [], blockerFilters = [], boards = [] },
  dependencies,
) => {
  const { repositories: { BranchRepository } } = dependencies;
  const childrenBranches = await BranchRepository.findChildrens(branchId);
  const branchesIds = [branchId, ...childrenBranches.map((b) => b.id)];

  try {
    return await QuestionBranch.count({
      where: {
        branchId: branchesIds,
        ...createWhereFilters(includerFilters, blockerFilters, boards),
      },
      include: [
        {
          association: 'question',
          include: [
            {
              association: 'test',
              include: [
                {
                  association: 'board',
                }
              ]
            },
            {
              association: 'questionBadges',
            }
          ]
        }
      ]
    });
  } catch {
    return 0
  }
}

export const deleteByQuestion = async (questionId, callback) => {
  try {
    await QuestionBranch.destroy({
      where: {
        questionId,
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}

export const deleteByBranch = async (branchId) =>
  await QuestionBranch.destroy({
    where: {
      branchId: Number(branchId),
    },
  });
