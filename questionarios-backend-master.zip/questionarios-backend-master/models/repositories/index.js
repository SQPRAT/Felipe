import * as UserRepository from './UserRepository.js';
import * as TestRepository from './TestRepository.js';
import * as QuestionRepository from './QuestionRepository.js';
import * as BranchRepository from './BranchRepository.js';
import * as BookRepository from './BookRepository.js';
import * as FolderRepository from './FolderRepository.js';
import * as QuestionBranchRepository from './QuestionBranchRepository.js';
import * as BadgeRepository from './BadgeRepository.js';
import * as QuestionBadgeRepository from './QuestionBadgeRepository.js';
import * as TestFileRepository from './TestFileRepository.js';
import * as BoardRepository from './BoardRepository.js';
import * as UserAccessRepository from './UserAccessRepository.js';
import * as TestTypeRepository from './TestTypeRepository.js';

export default {
  UserRepository,
  TestRepository,
  QuestionRepository,
  BranchRepository,
  BookRepository,
  FolderRepository,
  QuestionBranchRepository,
  BadgeRepository,
  QuestionBadgeRepository,
  TestFileRepository,
  BoardRepository,
  BoardRepository,
  UserAccessRepository,
  TestTypeRepository,
}
