import Sequelize from 'sequelize';

const { Model } = Sequelize;

export class TestFile extends Model {
  static init(sequelize) {
    super.init({
      description: Sequelize.TEXT,
      path: Sequelize.TEXT,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsTo(models.Test, { foreignKey: 'testId', as: 'test' });
  }
}

export const save = async testFile => await TestFile.create(testFile);

export const findByTest = async testId => await TestFile.findAll({
  where: {
    testId,
  },
});

export const deleteById = async (id, callback) => {
  try {
    await TestFile.destroy({
      where: {
        id
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}

