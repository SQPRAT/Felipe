import Sequelize from 'sequelize';
import { ITEMS_PER_PAGE } from '../../config/constants.js';
import Pages from '../../services/Pages.js';

const { Model } = Sequelize;

export class UserAccess extends Model {
  static init(sequelize) {
    super.init({
      ip: Sequelize.INET,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsTo(models.User, { foreignKey: 'userId', as: 'user' });
  }
}

export const save = async accessData => await UserAccess.create(accessData);

export const search = async (keyWord = '', page = 0) => await UserAccess.findAll({
  where: {
    [Sequelize.Op.or]: [
      {
        '$user.name$': {
          [Sequelize.Op.like]: `%${keyWord}%`
        }
      },
      {
        '$user.email$': {
          [Sequelize.Op.like]: `%${keyWord}%`
        }
      },
    ],
  },
  order: [
    ['id', 'ASC'],
  ],
  offset: page * ITEMS_PER_PAGE,
  limit: ITEMS_PER_PAGE,
  include: [
    { association: 'user', as: 'user' }
  ],
});

export const countPages = async () => {
  const amount = await UserAccess.count();
  const amountOfPages = Pages.calcPages(amount);

  return amountOfPages;
}
