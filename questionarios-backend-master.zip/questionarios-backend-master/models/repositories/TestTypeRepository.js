import Sequelize from 'sequelize';

const { Model, DataTypes } = Sequelize;

export class TestType extends Model {
  static init(sequelize) {
    super.init({
      name: DataTypes.STRING,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.hasMany(models.Test, { foreignKey: 'type', as: 'tests' });
  }
}

export const save = async testType => await TestType.create(testType);

export const all = async () => await TestType.findAll({ where: {} });

export const deleteById = async (id, callback) => {
  try {
    await TestType.destroy({
      where: {
        id
      }
    }).then(callback.onDeleted).catch(console.log);
  } catch(error) {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}
