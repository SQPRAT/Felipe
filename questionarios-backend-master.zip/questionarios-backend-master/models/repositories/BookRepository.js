import Sequelize from 'sequelize';
import Pages from '../../services/Pages.js';
import { ITEMS_PER_PAGE } from '../../config/constants.js';

const { Model, DataTypes } = Sequelize;

export class Book extends Model {
  static init(sequelize) {
    super.init({
      name: DataTypes.STRING,
      config: DataTypes.JSON,
      questions: DataTypes.JSON,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsTo(models.Folder, { foreignKey: 'folderId', as: 'folder' });
  }
}

export const findAnsweredQuestionsByUser = async (userId) => {
  try {
    const books = await Book.findAll({
      where: {
        '$folder.user$': userId,
      },
      include: [
        {
          association: 'folder'
        }
      ]
    });

    return books.reduce((accumulator, book) => [...accumulator, ...book.questions], []);
  } catch {
    return [];
  }
}

export const searchByFolder = async (folderId, keyWord = '', page = 0) => await Book.findAll({
  where: {
    name: {
      [Sequelize.Op.like]: `%${keyWord}%`
    },
    folderId,
  },
  order: [
    ['id', 'ASC'],
  ],
  offset: page * ITEMS_PER_PAGE,
  limit: ITEMS_PER_PAGE
});

export const countPagesByFolder = async folderId => {
  const amount = await Book.count({
    where: {
      folderId,
    },
  });
  const amountOfPages = Pages.calcPages(amount);

  return amountOfPages;
}

export const save = async book => await Book.create(book);

export const findById = async id => {
  if (!id) return null;

  try {
    const book = await Book.findByPk(id);

    if (!book) return null;

    return book.dataValues;
  } catch {
    return null;
  }
}

export const updateById = async (id, newProps, callback) => {
  try {
    await Book.update(newProps, {
      where: {
        id,
      }
    }).then(callback.onUpdated).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ]);
  }
}

export const deleteById = async (id, callback) => {
  try {
    await Book.destroy({
      where: {
        id
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}
