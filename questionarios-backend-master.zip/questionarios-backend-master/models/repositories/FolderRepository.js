import Sequelize from 'sequelize';
import { ITEMS_PER_PAGE } from '../../config/constants.js';
import Pages from '../../services/Pages.js';

const { Model, DataTypes } = Sequelize;

export class Folder extends Model {
  static init(sequelize) {
    super.init({
      name: DataTypes.STRING,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsTo(models.User, { foreignKey: 'user', as: 'owner' });
    this.hasMany(models.Book, { foreignKey: 'folderId', as: 'books' });
  }
}

export const findFolderWithBooks = async (userId) => await Folder.findAll({
  where: {
    user: userId,
  },
  oder: [
    ['id', 'ASC'],
  ],
  include: [
    { association: 'books' }
  ]
})

export const searchByUser = async (userId, keyWord = '', page = 0) => await Folder.findAll({
  where: {
    name: {
      [Sequelize.Op.like]: `%${keyWord}%`
    },
    user: userId
  },
  order: [
    ['id', 'ASC'],
  ],
  offset: page * ITEMS_PER_PAGE,
  limit: ITEMS_PER_PAGE
});

export const countPagesByUser = async userId => {
  const amount = await Folder.count({
    where: {
      user: userId,
    },
  });
  const amountOfPages = Pages.calcPages(amount);

  return amountOfPages;
}

export const save = async folder => await Folder.create(folder);

export const findById = async id => {
  if (!id) return null;

  try {
    const folder = await Folder.findByPk(id);

    if (!folder) return null;

    return folder.dataValues;
  } catch {
    return null;
  }
}

export const updateById = async (id, newProps, callback) => {
  try {
    await Folder.update(newProps, {
      where: {
        id,
      }
    }).then(callback.onUpdated).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ]);
  }
}

export const deleteById = async (id, callback) => {
  try {
    await Folder.destroy({
      where: {
        id
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}
