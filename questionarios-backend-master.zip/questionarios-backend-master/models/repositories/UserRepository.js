import Sequelize from 'sequelize';
import { ITEMS_PER_PAGE } from '../../config/constants.js';
import Pages from '../../services/Pages.js';
import i18next from 'i18next';

const { Model, DataTypes } = Sequelize;

export class User extends Model {
  static init(sequelize) {
    super.init({
      email: DataTypes.STRING,
      password: DataTypes.STRING,
      type: DataTypes.INTEGER,
      name: DataTypes.STRING,
      token: DataTypes.TEXT,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.hasMany(models.Question, { foreignKey: 'createdBy', as: 'questions' });
    this.hasMany(models.Branch, { foreignKey: 'createdBy', as: 'branches' });
    this.hasMany(models.Test, { foreignKey: 'createdBy', as: 'tests' });
  }
}

export const findByEmail = async email => {
  if (!email) return null;
  
  const user = await User.findOne({
    where: {
      email
    }
  });

  if (!user) return null;
 
  return user.dataValues;
}

export const findById = async id => {
  if (!id) return null;

  try {
    const user = await User.findByPk(id);

    if (!user) return null;

    return user.dataValues;
  } catch {
    return null;
  }
}

export const updateById = async (id, newProps, callback) => {
  try {
    await User.update(newProps, {
      where: {
        id,
      }
    }).then(callback.onUpdated).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ]);
  }
}

export const deleteById = async (id, callback) => {
  try {
    await User.destroy({
      where: {
        id
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}

export const save = async user => await User.create(user);

export const search = async (keyWord = '', page = 0) => await User.findAll({
  where: {
    [Sequelize.Op.or]: [
      {
        email: {
          [Sequelize.Op.like]: `%${keyWord}%`
        }
      },
    ],
  },
  order: [
    ['id', 'ASC'],
  ],
  offset: page * ITEMS_PER_PAGE,
  limit: ITEMS_PER_PAGE
});

export const countPages = async () => {
  const amount = await User.count();
  const amountOfPages = Pages.calcPages(amount);

  return amountOfPages;
}
