import Sequelize from 'sequelize';
import i18next from 'i18next';

const { Model } = Sequelize;

export class QuestionBadge extends Model {
  static init(sequelize) {
    super.init({}, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsTo(models.Badge, { foreignKey: 'badgeId', as: 'badge' });
    this.belongsTo(models.Question, { foreignKey: 'questionId', as: 'question' });
  }
}

export const save = async questionBadge => await QuestionBadge.create(questionBadge);

export const deleteByQuestion = async (questionId, callback) => {
  try {
    await QuestionBadge.destroy({
      where: {
        questionId,
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}
