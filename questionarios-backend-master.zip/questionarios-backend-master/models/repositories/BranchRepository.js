import Sequelize from 'sequelize';

const { Model, DataTypes } = Sequelize;

export class Branch extends Model {
  static init(sequelize) {
    super.init({
      name: DataTypes.STRING,
      active: DataTypes.BOOLEAN,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.belongsTo(models.Branch, { foreignKey: 'parentBranch', as: 'parent' });
    this.belongsTo(models.User, { foreignKey: 'createdBy', as: 'user' });
    this.belongsToMany(models.Question, {
      through: models.QuestionBranch,
      as: 'questionBranches',
      foreignKey: 'branchId',
      otherKey: 'questionId',
    });
  }
}

export const findById = async id => {
  if (!id) return null;

  try {
    const branch = await Branch.findOne({
      where: {
        id,
        active: true,
      }
    });

    if (!branch) return null;

    return branch.dataValues;
  } catch {
    return null;
  }
}

export const findByParentBranch = async parentBranch => {
  try {
    const branches = await Branch.findAll({
      where: {
        parentBranch,
        active: true,
      }
    });

    return branches;
  } catch {
    return [];
  }
}

export const updateById = async (id, newProps, callback) => {
  try {
    await Branch.update(newProps, {
      where: {
        id,
      }
    }).then(callback.onUpdated).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ]);
  }
}

export const deleteById = async (id, callback) => await updateById(id, {
  active: false,
}, {
  ...callback,
  onUpdated: callback.onDeleted,
});

export const findAll = async () => await Branch.findAll({
  where: { active: true },
  order: [
    ['id', 'ASC'],
  ],
});

export const findChildrens = async id => {
  if (!id) return [];

  const allBranches = await findAll();
  const relatedBranches = allBranches.reduce((branches, branch) => {
    const isSameBranch = branch.id === id;

    if (isSameBranch) return [...branches, branch];

    const isRelated = branches.some(b => branch.parentBranch === b.id);

    if (isRelated) return [...branches, branch];

    return [...branches]
  }, []);

  return relatedBranches;
}

export const findParents = async id => {
  if (!id) return [];

  const allBranches = await findAll();
  const relatedBranches = allBranches.reverse().reduce((branches, branch) => {
    const isSameBranch = branch.id === id;

    if (isSameBranch) return [...branches, branch];

    const isRelated = branches.some(b => branch.id === b.parentBranch);

    if (isRelated) return [...branches, branch];

    return [...branches]
  }, []);

  return relatedBranches;
}

export const save = async branch => await Branch.create(branch);
