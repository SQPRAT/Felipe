import Sequelize from 'sequelize';
import Pages from '../../services/Pages.js';
import { ITEMS_PER_PAGE } from '../../config/constants.js';

const { Model, DataTypes } = Sequelize;

export class Test extends Model {
  static init(sequelize) {
    super.init({
      name: DataTypes.STRING,
      year: DataTypes.INTEGER,
      amountOfQuestions: DataTypes.INTEGER,
      questionTypes: DataTypes.INTEGER,
    }, {
      sequelize
    });
  }

  static associate(models) {
    this.hasMany(models.Question, { foreignKey: 'testId', as: 'questions' });
    this.hasMany(models.TestFile, { foreignKey: 'testId', as: 'files' });
    this.belongsTo(models.Board, { foreignKey: 'boardId', as: 'board' });
    this.belongsTo(models.User, { foreignKey: 'createdBy', as: 'owner' });
    this.belongsTo(models.TestType, { foreignKey: 'type', as: 'category' });
  }
}

export const save = async test => await Test.create(test);

export const search = async (keyWord = '', page = 0, board = null, aditionalQuery = {}) => await Test.findAll({
  where: {
    [Sequelize.Op.or]: [
      {
        name: {
          [Sequelize.Op.like]: `%${keyWord}%`
        }
      },
    ],
    ...(!board ? null : ({
      board: {
        [Sequelize.Op.like]: `%${board}%`,
      }
    })),
    ...aditionalQuery,
  },
  order: [
    ['id', 'ASC'],
  ],
  include: [
    { association: 'board', as: 'test' },
    { association: 'category' }
  ],
  offset: page * ITEMS_PER_PAGE,
  limit: ITEMS_PER_PAGE
});

export const countPages = async () => {
  const amount = await Test.count();
  const amountOfPages = Pages.calcPages(amount);

  return amountOfPages;
}

export const findById = async id => {
  if (!id) return null;

  try {
    const test = await Test.findByPk(id, {
      include: [
        { association: 'files' },
        { association: 'board', },
        { association: 'category' }
      ]
    });

    if (!test) return null;

    return test.dataValues;
  } catch {
    return null;
  }
}

export const findByBoard = async board => {
  if (!board) return null;

  try {
    const test = await Test.findOne({
      where: {
        board,
      }
    })

    if (!test) return null;

    return test.dataValues;
  } catch {
    return null;
  }
}

export const findLastTests = async () => {
  try {
    const tests = await Test.findAll({
      limit: 3,
      order: [
        ['id', 'DESC'],
      ],
    });

    return tests;
  } catch {
    return [];
  }
}

export const updateById = async (id, newProps, callback) => {
  try {
    await Test.update(newProps, {
      where: {
        id,
      }
    }).then(callback.onUpdated).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ]);
  }
}

export const deleteById = async (id, callback) => {
  try {
    await Test.destroy({
      where: {
        id
      }
    }).then(callback.onDeleted).catch(callback.onError);
  } catch {
    return callback.onError([ i18next.t('common.somethingWrong') ])
  }
}
