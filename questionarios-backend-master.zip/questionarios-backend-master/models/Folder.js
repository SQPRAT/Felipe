import FolderMapper from './mappers/FolderMapper.js';
import UserMapper from './mappers/UserMapper.js';
import { authenticateAsARegisterer, show as showUser } from './User.js';

export const isAllowedToManageFolders = async (token, userId, callback, dependencies) => await authenticateAsARegisterer(token, {
  ...callback,
  onAuthenticated: async () => await showUser(token, userId, {
    ...callback,
    onFound: callback.onAuthenticated,
  }, dependencies),
}, dependencies);

export const templateFolder = async ({ name }, user) => ({
  name,
  user: user.id,
});

export const store = async (userId, folder, token, callback, dependencies) => await isAllowedToManageFolders(token, userId, {
  ...callback,
  onAuthenticated: async () => {
    const {
      repositories: { FolderRepository },
      services: { Token },
    } = dependencies;
    const folderDTO = FolderMapper.toDTO(folder);
    const userOfToken = Token.decrypt(token);

    return await folderDTO.validate({
      onValidated: async () => {
        const preparedFolder = await templateFolder(FolderMapper.toEntity(folderDTO), userOfToken);
        const savedFolder = await FolderRepository.save(preparedFolder);
  
        return callback.onSaved(savedFolder);
      },
      onInvalidated: callback.onError
    });
  }
}, dependencies);

export const index = async (userId, token, keyWord = '', page = 0, callback, dependencies) => await isAllowedToManageFolders(token, userId, {
  ...callback,
  onAuthenticated: async user => {
    const { repositories: { FolderRepository } } = dependencies;
    const folders = await FolderRepository.searchByUser(user.id, keyWord, page);
    const pages = await FolderRepository.countPagesByUser(user.id);
  
    return callback.onFound(folders, pages);
  },
}, dependencies);

export const show = async (userId, folderId, token, callback, dependencies) => await isAllowedToManageFolders(token, userId, {
  ...callback,
  onAuthenticated: async user => {
    const { repositories: { FolderRepository } } = dependencies;
    const folder = await FolderRepository.findById(Number(folderId));
    const userDTO = UserMapper.toDTO(user);

    if (!folder || folder?.user !== Number(userId)) return callback.onNotFound();
    if (folder?.user !== Number(userId) && !userDTO.isAdmin()) return callback.onNotAllowed();

    return callback.onFound(folder);
  }
}, dependencies);

export const update = async (newProps, userId, folderId, token, callback, dependencies) => await show(userId, folderId, token, {
  ...callback,
  onFound: async folder => {
    const { repositories: { FolderRepository } } = dependencies;
    const folderDTO = FolderMapper.toDTO(folder);

    folderDTO.addNewProps(newProps);

    return await folderDTO.validate({
      onValidated: async () => await FolderRepository.updateById(Number(folderId), newProps, callback),
      onInvalidated: callback.onError
    })
  },
}, dependencies);

export const remove = async (userId, folderId, token, callback, dependencies) => await show(userId, folderId, token, {
  ...callback,
  onFound: async folder => {
    const { repositories: { FolderRepository } } = dependencies;

    return await FolderRepository.deleteById(folder.id, callback);
  }
}, dependencies);
