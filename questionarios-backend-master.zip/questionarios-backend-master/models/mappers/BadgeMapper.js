
import BadgeDTO from '../dtos/BadgeDTO.js';
import Mapper from './Mapper.js';

export default class BadgeMapper {
  static toDTO(badge) {
    return new BadgeDTO(badge);
  }

  static toEntity(badgeDTO) {
    return Mapper.toEntity(badgeDTO);
  }
}
