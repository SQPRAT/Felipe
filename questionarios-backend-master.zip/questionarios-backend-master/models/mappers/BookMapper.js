
import BookDTO from '../dtos/BookDTO.js';
import Mapper from './Mapper.js';

export default class BookMapper {
  static toDTO(book) {
    return new BookDTO(book);
  }

  static toEntity(bookDTO) {
    return Mapper.toEntity(bookDTO);
  }
}
