
import BranchDTO from '../dtos/BranchDTO.js';
import Mapper from './Mapper.js';

export default class BranchMapper {
  static toDTO(branch) {
    return new BranchDTO(branch);
  }

  static toEntity(branchDTO) {
    return Mapper.toEntity(branchDTO);
  }
}
