
import QuestionDTO from '../dtos/QuestionDTO.js';
import Mapper from './Mapper.js';

export default class QuestionMapper {
  static toDTO(question) {
    return new QuestionDTO(question);
  }

  static toEntity(questionDTO) {
    return Mapper.toEntity(questionDTO);
  }
}
