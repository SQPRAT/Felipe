
import TestDTO from '../dtos/TestDTO.js';
import Mapper from './Mapper.js';

export default class TestMapper {
  static toDTO(test) {
    return new TestDTO(test);
  }

  static toEntity(testDTO) {
    return Mapper.toEntity(testDTO);
  }
}
