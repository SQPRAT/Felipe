
import FolderDTO from '../dtos/FolderDTO.js';
import Mapper from './Mapper.js';

export default class folderMapper {
  static toDTO(folder) {
    return new FolderDTO(folder);
  }

  static toEntity(folderDTO) {
    return Mapper.toEntity(folderDTO);
  }
}
