import i18next from 'i18next';
import QuestionMapper from './mappers/QuestionMapper.js';
import { show as showTest } from './Test.js';
import UserMapper from './mappers/UserMapper.js';
import { authenticate } from './User.js';

const updateBranches = async (persistedQuestion, newBranches, dependencies) => {
  const questionId = persistedQuestion.id;
  const { repositories: { QuestionBranchRepository } } = dependencies;

  await QuestionBranchRepository.deleteByQuestion(questionId, {
    onError: () => {},
    onDeleted: () => {},
  });

  newBranches.forEach(async ({ branchId }) => await QuestionBranchRepository.save({ branchId, questionId }));
}

const updateBadges = async (persistedQuestion, newBadges, dependencies) => {
  const questionId = persistedQuestion.id;
  const { repositories: { QuestionBadgeRepository } } = dependencies;

  await QuestionBadgeRepository.deleteByQuestion(questionId, {
    onError: () => {},
    onDeleted: () => {},
  });

  newBadges.forEach(async ({ badgeId }) => await QuestionBadgeRepository.save({ badgeId, questionId }));
}

export const templateQuestion = (questionDTO, test, user) => ({
  ...QuestionMapper.toEntity(questionDTO),
  testId: test.id,
  createdBy: user.id,
  answers: questionDTO.answers.map(({ explanation, correct, description }) => ({
    explanation,
    correct: Boolean(correct),
    description
  }))
});

export const store = async (question, token, testId, callback, dependencies) => await showTest(token, testId, {
  ...callback,
  onFound: async test => {
    const {
      repositories: { QuestionRepository },
      services: { Token },
    } = dependencies;
    const questionDTO = QuestionMapper.toDTO({ ...question, type: test.questionTypes, testId });
    const userOfToken = Token.decrypt(token);
    const amountOfQuestionsOfTest = await QuestionRepository.countByTest(test.id);

    if (amountOfQuestionsOfTest >= test.amountOfQuestions) return callback.onError([i18next.t('models.question.messages.errors.invalidAmount')]);

    return await questionDTO.validate(dependencies, {
      onValidated: async () => {
        const savedQuestion = await QuestionRepository.save(templateQuestion(questionDTO, test, userOfToken));

        await updateBranches(savedQuestion, questionDTO?.branches ?? [], dependencies);
        await updateBadges(savedQuestion, questionDTO?.badges ?? [], dependencies);

        return callback.onSaved(savedQuestion);
      },
      onInvalidated: callback.onError
    });
  }
}, dependencies);

export const index = async (token, testId, keyWord, page, callback, dependencies) => await showTest(token, testId, {
  ...callback,
  onFound: async () => {
    const {
      services: { Token },
      repositories: { QuestionRepository }
    } = dependencies;
    const user = Token.decrypt(token);
    const userDTO = UserMapper.toDTO(user);
    const userId = userDTO.id;
    const questions = userDTO.isQuestionRecorderAndStudent()
      ? await QuestionRepository.search({ keyWord, page, testId, userId })
      : await QuestionRepository.search({ keyWord, page, testId });
    const pages = userDTO.isQuestionRecorderAndStudent()
      ? await QuestionRepository.countPages({ testId, userId })
      : await QuestionRepository.countPages({ testId });

    return callback.onFound(questions, pages);
  },
}, dependencies);

export const reponseTemplate = (question) => {
  const pureBranches = question?.questionBranches?.map((questionBranch) => ({ branchId: questionBranch.id })) ?? [];

  return { ...question, branches: pureBranches };
}

export const show = async (token, testId, questionId, callback, dependencies) => await showTest(token, testId, {
  ...callback,
  onFound: async () => {
    const {
      services: { Token },
      repositories: { QuestionRepository }
    } = dependencies;
    const question = await QuestionRepository.findById(questionId);

    if (!question) return callback.onNotFound();
    if (question.testId !== Number(testId)) return callback.onNotFound();

    const user = Token.decrypt(token);
    const userDTO = UserMapper.toDTO(user);
    const questionIsOfUser = question.createdBy === userDTO.id;

    if (userDTO.isQuestionRecorderAndStudent() && !questionIsOfUser) {
      return callback.onNotAllowed();
    }

    return callback.onFound(reponseTemplate(question));
  }
}, dependencies);

export const showDirectly = async (token, questionId, callback, dependencies) => await authenticate(token, {
  ...callback,
  onAuthenticated: async () => {
    const {
      repositories: { QuestionRepository }
    } = dependencies;
    const question = await QuestionRepository.findById(questionId);

    if (!question) return callback.onNotFound();
  
    return callback.onFound(reponseTemplate(question));
  }
}, dependencies);

export const update = async (newProps, token, testId, questionId, callback, dependencies) => await show(token, testId, questionId, {
  ...callback,
  onFound: async (question) => {
    const { repositories: { QuestionRepository, TestRepository } } = dependencies;
    const test = await TestRepository.findById(testId);
    const questionDTO = QuestionMapper.toDTO({ ...question, type: test.questionTypes });

    questionDTO.addNewProps(newProps);

    return questionDTO.validate(dependencies, {
      onValidated: async () => {
        await updateBranches(question, questionDTO.branches, dependencies);
        await updateBadges(question, questionDTO.badges, dependencies);
        await QuestionRepository.updateById(questionId, { ...newProps, isCommented: questionDTO.isCommented }, callback);
      },
      onInvalidated: callback.onError
    })
  },
}, dependencies);

export const remove = async (token, testId, questionId, callback, dependencies) => await show(token, testId, questionId, {
  ...callback,
  onFound: async () => {
    const { repositories: { QuestionRepository } } = dependencies;

    return await QuestionRepository.deleteById(questionId, callback);
  },
}, dependencies);
