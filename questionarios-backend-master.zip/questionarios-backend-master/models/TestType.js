import { authenticate, authenticateAsAdmin } from './User.js';

export const store = async (testType, token, callback, dependencies) => await authenticateAsAdmin(token, {
  ...callback,
  onAuthenticated: async () => {
    try {
      const { repositories: { TestTypeRepository } } = dependencies;
      const savedTestType = await TestTypeRepository.save(testType);

      return callback.onSaved(savedTestType);
    } catch (error) {
      return callback.onError(error)
    }
  }
}, dependencies);

export const index = async (token, callback, dependencies) => await authenticate(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { TestTypeRepository } } = dependencies;
    const testTypes = await TestTypeRepository.all();

    return callback.onFound(testTypes);
  },
}, dependencies);

export const remove = async (token, testTypeId, callback, dependencies) => await authenticateAsAdmin(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { TestTypeRepository } } = dependencies;

    return await TestTypeRepository.deleteById(testTypeId, callback);
  }
}, dependencies)
