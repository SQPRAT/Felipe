import DTO from './DTO.js';
import isEmpty from 'lodash/isEmpty.js';
import { questionTypes } from '../../config/constants.js';

const MIN_EXPLANATION_LENGTH = 10;
const MIN_DESCRIPTION_LENGTH = 10;

export default class QuestionDTO extends DTO {
	constructor({
		answers,
		type,
		id = null,
		explanation,
		description,
		branchId,
		branches,
		position,
		testId,
		badges,
		isDraft = false
	}) {
		super('question');

		this.answers = answers;
		this.badges = badges;
		this.id = id;
		this.type = type;
		this.explanation = explanation;
		this.description = description;
		this.branchId = branchId;
		this.position = position;
		this.testId = testId;
		this.branches = branches;
		this.isCancelled = false;
		this.isCommented = false;
		this.isDraft = isDraft
	}

	async isValidBadges(dependencies) {
		const { repositories: { BadgeRepository } } = dependencies;
		const badges = this?.badges ?? [];

		for (const badgeItem of badges) {
			const badgeId = badgeItem?.badgeId;

			if (!badgeId) return false;

			const badgeFromDatabse = await BadgeRepository.findById(badgeId);

			if (!badgeFromDatabse) return false;
			if (badgeFromDatabse.name === 'Anulada') this.isCancelled = true;
		}

		return true;
	}

	hasOneBranch() {
		const branches = this?.branches ?? [];

		return Boolean(branches.length)
	}

	async isValidBranches(dependencies) {
		const { repositories: { BranchRepository } } = dependencies;
		const branches = this?.branches ?? [];

		for (const branchItem of branches) {
			const branchId = branchItem?.branchId;

			if (!branchId) return false;

			const branchFromDatabase = await BranchRepository.findById(branchId);

			if (!branchFromDatabase) return false;
		}

		return true;
	}

	isValidAnswer({
		correct,
		description,
	}) {
		return !isEmpty(description) && (correct === true || correct === false);
	}
	
	isValidExplanation() {
		const explanation = this?.explanation ?? null;

		if (!explanation) return false;

		return (
			!isEmpty(explanation) &&
			explanation.length >= MIN_EXPLANATION_LENGTH
		);
	}

	isValidDescription() {
		const description = this?.description ?? null;

		if (!description) return false;

		return (
			!isEmpty(description) &&
			description.length >= MIN_DESCRIPTION_LENGTH
		);
  }
  
  isCorrect({ correct }) {
    return Boolean(correct);
	}

	async isOverflowedPosition(dependencies) {
		const position = this?.position ?? null;

		if (!position) return false;

		const { repositories: { TestRepository } } = dependencies;
		const test = await TestRepository.findById(this.testId);

		if (!test) return false;

		return position <= test.amountOfQuestions;
	}
	
	async isValidPosition(dependencies) {
		const position = this?.position ?? null;

		if (!position) return false;

		const { repositories: { QuestionRepository } } = dependencies;
		const questions = await QuestionRepository.findByTest(this.testId, { position });
		const hasQuestionOnThisPosition = Boolean(questions?.length);

		return !hasQuestionOnThisPosition;
	}

  isValidAnswers() {
		const answers = this?.answers ?? {};

		if (!answers || !answers.length) return false;
    if (!answers.every(this.isValidAnswer)) return false;
    
		const correctAnswers = answers.filter(this.isCorrect);

    if (!this.isCancelled && correctAnswers.length !== 1) return false;
		if (this.type === questionTypes.BOOLEAN) {
			if (answers.length !== 2) return false;
			return true;
		} else if (this.type === questionTypes.ALTERNATIVES) {
			if (answers.length !== 5) return false;
			return true;
		}

		return false;
  }

  async validate(dependencies, callback) {
		this.filterProps();

		const errors = [ ];

		if (!await this.isOverflowedPosition(dependencies)) errors.push(this.errorMessage('overflowedPosition'));

		if (!this.hasOneBranch() && !this.isDraft) errors.push(this.errorMessage('requiredBranch'));
		if (this.isNew()) {
			if (!await this.isValidPosition(dependencies)) errors.push(this.errorMessage('invalidPosition', {
				position: this.position,
			}));
		}
		if (!await this.isValidBadges(dependencies)) errors.push(this.errorMessage('invalidBadges'))
		if (!this.isValidAnswers() && !this.isDraft) errors.push(this.errorMessage('invalidAnswers'));
		if (!await this.isValidBranches(dependencies)) errors.push(this.errorMessage('invalidBranches'));
		if (this.explanation) {
			if (!this.isValidExplanation()) errors.push(this.errorMessage('invalidExplanation', {
				minLength: MIN_EXPLANATION_LENGTH,
			}));
		}
		if (!this.isValidDescription()) errors.push(this.errorMessage('invalidDescription', {
			minLength: MIN_DESCRIPTION_LENGTH,
		}));

		if (errors.length) return callback.onInvalidated(errors);

		const { explanation, answers } = this;
		const someAnswerHasExplanation = answers.some((answer) => answer.hasExplanation);

		this.isCommented = Boolean(explanation) || someAnswerHasExplanation;

    return callback.onValidated();
  }
}
