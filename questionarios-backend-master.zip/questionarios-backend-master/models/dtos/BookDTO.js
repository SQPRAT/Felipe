import DTO from './DTO.js';
import isEmpty from 'lodash/isEmpty.js';
import isInteger from 'lodash/isInteger.js';

const MAX_LENGTH_NAME = 100;
const MIN_LENGTH_NAME = 3;

export default class BookDTO extends DTO {
	constructor({
		name,
    id = null,
    questions = [],
    config = [],
    boards = [],
    total = 0,
	}) {
		super('book');

		this.name = name || 'Meu livro de estudos';
		this.config = config;
    this.id = id;
    this.questions = questions;
    this.boards = boards;
    this.total = total;
  }

  isValidName() {
    const name = this?.name ?? '';

    return (
      !isEmpty(name) &&
      name.length >= MIN_LENGTH_NAME &&
      name.length < MAX_LENGTH_NAME
    );
  }

  isValidConfig() {
    const config = this?.config ?? [];

    if (!Array.isArray(config)) return false;

    return config.every(item => isInteger(item.topic) && isInteger(item.amount));
  }

  async isValidBoard(dependencies, boardName) {
    if (!boardName) return false;

    const { repositories: { BoardRepository } } = dependencies;
    const board = await BoardRepository.find(boardName);

    return Boolean(board);
  }

  async isValidAmounts(dependencies, topic, boards, includerFilters, blockerFilters) {
    const {
      repositories: { BranchRepository, QuestionRepository },
    } = dependencies;
    const branch = await BranchRepository.findById(topic.topic);

    if (!branch) return false;

    const amountOfQuestionsOfTopicOnDatabase = await QuestionRepository.countByBranch(branch.id, boards, includerFilters, blockerFilters, dependencies);
    const amountOfQuestion = topic.amount;

    return amountOfQuestionsOfTopicOnDatabase >= amountOfQuestion;
  }

  async validate(includerFilters, blockerFilters, dependencies, callback) {
    this.filterProps();

    const errors = [ ];

    if (!this.isValidName()) errors.push(this.errorMessage('invalidName', {
      maxLength: MAX_LENGTH_NAME,
      minLength: MIN_LENGTH_NAME,
    }));

    const isValidConfig = this.isValidConfig();

    if (!isValidConfig) return callback.onInvalidated([...errors, this.errorMessage('invalidConfig')]);

    if (!this.total) errors.push(this.errorMessage('invalidTotal'));

    for (let boardName of this.boards) {
      if (!await this.isValidBoard(dependencies, boardName)) {
        errors.push(this.errorMessage('invalidBoard'))
      }
    }

    if (errors.length) return callback.onInvalidated(errors);

    for (let topic of this.config) {
      if (!await this.isValidAmounts(dependencies, topic, this.boards, includerFilters, blockerFilters)) {
        const { repositories: { BranchRepository } } = dependencies;
        const branch = await BranchRepository.findById(Number(topic.topic))

        errors.push(this.errorMessage('invalidTopic', {
          name: branch?.name ?? '',
          amount: topic?.amount ?? 0,
        }));
      }
    }

    return errors.length ? callback.onInvalidated(errors) : callback.onValidated();
  }
}
