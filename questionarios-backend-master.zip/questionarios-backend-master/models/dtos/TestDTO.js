import DTO from './DTO.js';
import isEmpty from 'lodash/isEmpty.js';
import isString from 'lodash/isString.js';
import { questionTypes as questionTypesConstant } from '../../config/constants.js';

const MIN_NAME_LENGTH = 1;
const MAX_NAME_LENGTH = 200;
const MIN_BOARD_LENGTH = 1;
const MAX_BOARD_LENGTH = 200;
const MIN_QUESTIONS = 1;
const MAX_QUESTIONS = 1000;

export default class TestDTO extends DTO {
  constructor({
    name,
    board,
    year,
    type,
    questions,
    amountOfQuestions,
    questionTypes,
    id = null,
  }) {
    super('test');

    this.board = board.name || board;
    this.amountOfQuestions = Number(questions || amountOfQuestions);
    this.name = name;
    this.year = Number(year);
    this.type = Number(type);
    this.questionTypes = Number(questionTypes);
    this.id = id;
  }

  isValidQuestionTypes() {
    const questionTypes = this?.questionTypes ?? '';

    return Object.values(questionTypesConstant).some(questionType => questionType == questionTypes);
  }

  async isValidQuestions(dependncies) {
    const questions = this?.amountOfQuestions ?? 0;
    const isValidQuestions = questions >= MIN_QUESTIONS && questions <= MAX_QUESTIONS;

    if (this.isNew()) return isValidQuestions;

    const { repositories: { QuestionRepository } } = dependncies;
    const questionsAfterPositiont = await QuestionRepository.findAfterPositionByTest(this.id, questions);
    const hasFilledPositionsAfterNewPosition = Boolean(questionsAfterPositiont.length);

    return isValidQuestions && !hasFilledPositionsAfterNewPosition;
  }

  async isValidType(dependncies) {
    const { repositories: { TestTypeRepository } } = dependncies;
    const testTypes = await TestTypeRepository.all();
    const type = this?.type ?? '';

    return testTypes.some((testType) => testType.id == type);
  }

  isValidBoard() {
    const board = this?.board ?? '';

    return (
      !isEmpty(board) &&
      board.length >= MIN_BOARD_LENGTH &&
      board.length <= MAX_BOARD_LENGTH &&
      isString(board)
    );
  }

  isValidName() {
    const name = this?.name ?? '';

    return (
      !isEmpty(name) &&
      name.length >= MIN_NAME_LENGTH &&
      name.length < MAX_NAME_LENGTH
    );
  }

  isValidYear() {
    const year = this?.year ?? 0;

    return (
      Boolean(year)
    );
  }

  async validate(dependncies, callback) {
    this.filterProps();

    const errors = [ ];

    if (!this.isValidQuestionTypes()) errors.push(this.errorMessage('invalidQuestionType'));

    if (!await this.isValidQuestions(dependncies)) {
      errors.push(this.errorMessage('invalidQuestions', {
        min: MIN_QUESTIONS,
        max: MAX_QUESTIONS,
      }));

      if (!this.isNew()) {
        errors.push(this.errorMessage('filledQuestions', {
          position: this.amountOfQuestions,
        }))
      }
    }

    if (!this.isValidName()) errors.push(this.errorMessage('invalidName', {
      minLength: MIN_NAME_LENGTH,
      maxLength: MAX_NAME_LENGTH,
    }));

    if (!await this.isValidType(dependncies)) errors.push(this.errorMessage('invalidType'));

    if (!this.isValidBoard()) errors.push(this.errorMessage('invalidBoard', {
      minLength: MIN_BOARD_LENGTH,
      maxLength: MAX_BOARD_LENGTH,
    }));

    if (this.year) {
      if (!this.isValidYear()) errors.push(this.errorMessage('invalidYear'));
    }

    return errors.length ? callback.onInvalidated(errors) : callback.onValidated();
  }
}
