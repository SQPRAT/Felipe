import DTO from './DTO.js';
import isEmpty from 'lodash/isEmpty.js';

const MAX_LENGTH_NAME = 250;
const MIN_LENGTH_NAME = 5;

export default class BranchDTO extends DTO {
	constructor({
		name,
    id = null,
    parentBranch = null,
	}) {
		super('branch');

		this.name = name;
    this.id = id;
    this.parentBranch = parentBranch;
  }
  
  isValidName() {
    const name = this?.name ?? '';

    return (
      !isEmpty(name) &&
      name.length >= MIN_LENGTH_NAME &&
      name.length < MAX_LENGTH_NAME
    );
  }

  async isValidParentBranch(dependencies) {
    const { repositories: { BranchRepository } } = dependencies;
    const branch = await BranchRepository.findById(this.parentBranch);

    return Boolean(branch) && this.id !== branch?.id;
  }

  async isDuplicatedName(dependencies) {
    const { repositories: { BranchRepository } } = dependencies;
    const parentBranch = this?.parentBranch ?? null;
    const branchesOfSameParent = await BranchRepository.findByParentBranch(parentBranch);

    if (!branchesOfSameParent || !branchesOfSameParent.length) return false;

    const isDuplicatedName = branchesOfSameParent.some((branch) => branch.name === this.name);

    return isDuplicatedName;
  }

  async validate(dependencies, callback) {
    this.filterProps();

    const errors = [ ];

    if (!this.isValidName()) errors.push(this.errorMessage('invalidName', {
      maxLength: MAX_LENGTH_NAME,
      minLength: MIN_LENGTH_NAME,
    }));

    if (this.parentBranch) {
      if (!await this.isValidParentBranch(dependencies)) errors.push(this.errorMessage('invalidParent'));
    }

    if (await this.isDuplicatedName(dependencies)) errors.push(this.errorMessage('duplicatedName'));

    return errors.length ? callback.onInvalidated(errors) : callback.onValidated();
  }
}
