import DTO from './DTO.js';
import isEmpty from 'lodash/isEmpty.js';

const MAX_LENGTH_NAME = 100;
const MIN_LENGTH_NAME = 5;

export default class BadgeDTO extends DTO {
	constructor({
		name,
    id = null,
	}) {
		super('badge');

		this.name = name;
    this.id = id;
  }

  isValidName() {
    const name = this?.name ?? '';

    return (
      !isEmpty(name) &&
      name.length >= MIN_LENGTH_NAME &&
      name.length < MAX_LENGTH_NAME
    );
  }

  async validate(callback) {
    this.filterProps();

    const errors = [ ];

    if (!this.isValidName()) errors.push(this.errorMessage('invalidName', {
      maxLength: MAX_LENGTH_NAME,
      minLength: MIN_LENGTH_NAME,
    }));

    return errors.length ? callback.onInvalidated(errors) : callback.onValidated();
  }
}
