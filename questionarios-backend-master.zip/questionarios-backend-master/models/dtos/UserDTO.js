import DTO from './DTO.js';
import { userTypes } from '../../config/constants.js';
import EmailValidator from 'email-validator';
import isEmpty from 'lodash/isEmpty.js';
import isString from 'lodash/isString.js';

const MIN_LENGTH_EMAIL = 4;
const MAX_LENGTH_EMAIL = 100;
const MIN_LENGTH_PASSWORD = 6;
const MAX_LENGTH_PASSWORD = 20;
const MIN_LENGTH_NAME = 2;
const MAX_LENGTH_NAME = 200;

export default class UserDTO extends DTO {
  constructor({
    email,
    password,
    confirmPassword = null,
    type = userTypes.QUESTION_RECORDER_AND_STUDENT,
    id = null,
    name,
    token,
  }) {
    super('user');

    this.email = email;
    this.password = password;
    this.confirmPassword = confirmPassword;
    this.type = type;
    this.id = id;
    this.name = name;
    this.token = token;
  }

  isValidEmail() {
    const email = this?.email ?? '';

    return (
      !isEmpty(email) &&
      EmailValidator.validate(email) &&
      email.length <= MAX_LENGTH_EMAIL &&
      email.length > MIN_LENGTH_EMAIL
    )
  }

  isValidName() {
    const name = this?.name ?? '';

    return (
      isString(name) &&
      !isEmpty(name) &&
      name?.length <= MAX_LENGTH_NAME &&
      name?.length >= MIN_LENGTH_NAME
    );
  }

  isValidPassword() {
    const password = this?.password ?? '';

    return (
      isString(password) &&
      password?.length < MAX_LENGTH_PASSWORD &&
      password?.length >= MIN_LENGTH_PASSWORD
    );
  }

  isValidType() {
    const types = Object.values(userTypes);
    const type = this?.type ?? null;

    return types.some(item => item === type);
  }

  isSamePassword() {
    return this?.password === this?.confirmPassword;
  }

  isSameUser(user) {
    return this?.id === user?.id;
  }

  async isNewEmail({ repositories: { UserRepository } }) {
    const user = await UserRepository.findByEmail(this.email);

    return isEmpty(user) || user?.id === this?.id;
  }

  isAdmin() {
    const type = this?.type ?? '';

    return type === userTypes.ADMIN;
  }

  isQuestionRecorder() {
    const type = this?.type ?? '';

    return type === userTypes.QUESTION_RECORDER;
  }

  isQuestionRecorderAndStudent() {
    const type = this?.type ?? '';

    return type === userTypes.QUESTION_RECORDER_AND_STUDENT;
  }

  encryptPassword({ services: { Encrypt } }) {
    this.password = Encrypt.encrypt(this.password);
  }

  decryptPassword({ services: { Encrypt } }) {
    this.password = Encrypt.decrypt(this.password);
  }

  canSave({ services: { Token } }, token) {
    const decryptedToken = Token.decrypt(token);

    if (!decryptedToken) return false;

    return decryptedToken.type == userTypes.ADMIN;
  }

  canChange({ id }) {
    return (
      this.isAdmin() ||
      this.id === id
    );
  }

  async validate(dependencies, callback) {
    this.filterProps();

    const errors = [ ];

    if (!this.isValidName()) errors.push(this.errorMessage('invalidName', {
      minLength: MIN_LENGTH_NAME,
      maxLength: MAX_LENGTH_NAME
    }));

    if (!this.isValidEmail()) errors.push(this.errorMessage('invalidEmail', {
      minLength: MIN_LENGTH_EMAIL,
      maxLength: MAX_LENGTH_EMAIL
    }));

    if (!await this.isNewEmail(dependencies)) errors.push(this.errorMessage('duplicatedEmail'));

    if (!this.isValidPassword()) errors.push(this.errorMessage('invalidPassword', {
      minLength: MIN_LENGTH_PASSWORD,
      maxLength: MAX_LENGTH_PASSWORD
    }));

    if (!this.isSamePassword()) errors.push(this.errorMessage('differentPassword'));

    if (!this.isValidType()) errors.push(this.errorMessage('invalidType'));

    return errors.length ? callback.onInvalidated(errors) : callback.onValidated();
  }
}
