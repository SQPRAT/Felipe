import UserMapper from './mappers/UserMapper.js';
import publicIp from 'public-ip';

export const recoverPassword = async (email, callback, dependencies) => {
  const { repositories: { UserRepository }, services: { Encrypt, Email } } = dependencies;
  const user = await UserRepository.findByEmail(email);

  if (!user) return callback.onError();

  const decryptedPassword = Encrypt.decrypt(user.password);
  const emailSubject = 'Recuperação de senha';
  const emailText = `Sua senha é: ${decryptedPassword}`
  
  Email.sendEmail(email, emailText, emailSubject);

  return callback.onSuccess();
}

export const login = async (email, password, callback, { repositories: { UserRepository, UserAccessRepository }, services: { Encrypt, Token } }) => {
  if (!email || !password) return callback.onNotAllowed();

  const user = await UserRepository.findByEmail(email);

  if (!user) return callback.onNotAllowed();

  const decryptedPassword = Encrypt.decrypt(user.password);

  if(decryptedPassword !== password) return callback.onNotAllowed();

  const token = Token.create({
    email: user.email,
    name: user.name,
    type: user.type,
    id: user.id,
  });

  await UserRepository.updateById(
    user.id,
    { token },
    {
      onError: () => {},
      onUpdated: () => {},
    }
  );

  const userIp = await publicIp.v4();

  await UserAccessRepository.save({ ip: userIp, userId: user.id });

  return callback.onAllowed(user, token);
}

export const store = async (user, token, callback, dependencies) => {
  const userDTO = UserMapper.toDTO(user);

  return await userDTO.validate(dependencies, {
    onValidated: async () => {
      const canSave = await userDTO.canSave(dependencies, token);

      if (!canSave) return callback.onNotAllowed();

      userDTO.encryptPassword(dependencies);

      const { repositories: { UserRepository } } = dependencies;
      const user = await UserRepository.save(UserMapper.toEntity(userDTO));

      return callback.onSaved(user);
    },
    onInvalidated: callback.onError
  });
};

export const index = async (token, keyWord, page, callback, dependencies) => {
  const { services: { Token }, repositories: { UserRepository } } = dependencies;
  const userOfToken = Token.decrypt(token);

  if (!userOfToken) return callback.onNotAllowed();

  const userDTO = UserMapper.toDTO(userOfToken);

  if (!userDTO.isAdmin()) return callback.onNotAllowed();

  const users = await UserRepository.search(keyWord, page);
  const pages = await UserRepository.countPages();

  return callback.onFound(users, pages);
}

export const accesses = async (token, keyWord, page, callback, dependencies) => await authenticateAsARegisterer(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { UserAccessRepository } } = dependencies;
    const accessesData = await UserAccessRepository.search(keyWord, page);
    const pages = await UserAccessRepository.countPages();

    return callback.onFound(accessesData, pages);
  }
}, dependencies);

const isAllowedToManage = async (token, userId, callback, dependencies) => {
  const { services: { Token }, repositories: { UserRepository } } = dependencies;
  const userOfToken = Token.decrypt(token);

  if (!userOfToken) return callback.onNotAllowed();

  const user = await UserRepository.findById(userId);

  if (!user) return callback.onNotFound();

  const userDTO = UserMapper.toDTO(userOfToken);

  if (!userDTO.isAdmin() && !userDTO.isSameUser(user)) return callback.onNotAllowed();

  return callback.onAllowed(user);
}

export const show = async (token, userId, callback, dependencies) => await isAllowedToManage(token, userId, {
  ...callback,
  onAllowed: callback.onFound,
}, dependencies);

export const statistics = async (token, userId, callback, dependencies) => await show(token, userId, {
  ...callback,
  onFound: async (user) => {
    const { repositories: { BookRepository, TestRepository } } = dependencies;
    const lastTests = await TestRepository.findLastTests();
    const answeredQuestions = await BookRepository.findAnsweredQuestionsByUser(user.id);
    const correctQuestions = answeredQuestions.filter((question) => Boolean(question?.isCorrect));

    return callback.onFound({ tests: lastTests, answeredQuestions: answeredQuestions.length, correctQuestions: correctQuestions.length });
  },
}, dependencies);

export const update = async (token, userId, newProps, callback, dependencies) => await isAllowedToManage(token, userId, {
  ...callback,
  onAllowed: async user => {
    const userDTO = UserMapper.toDTO(user);
    const { repositories: { UserRepository } } = dependencies;

    userDTO.decryptPassword(dependencies);
    userDTO.confirmPassword = userDTO.password;
    userDTO.addNewProps(newProps);
    return userDTO.validate(dependencies, {
      onInvalidated: callback.onError,
      onValidated: async () => {
        userDTO.encryptPassword(dependencies);

        return await UserRepository.updateById(userId, userDTO, callback);
      }
    });
  }, 
}, dependencies);

export const remove = async (token, userId, callback, dependencies) => await isAllowedToManage(token, userId, {
  ...callback,
  onAllowed: async () => {
    const { repositories: { UserRepository } } = dependencies;

    return await UserRepository.deleteById(userId, callback);
  }, 
}, dependencies);

export const authenticate = async (token, callback, dependencies) => {
  const { services: { Token }, repositories: { UserRepository } } = dependencies;
  const userOfToken = Token.decrypt(token);

  if (!userOfToken) return callback.onNotAllowed();

  const userId = userOfToken?.id ?? null;

  if (!userId) return callback.onNotAllowed();

  const userOfDatabase = await UserRepository.findById(Number(userId));

  if (!userOfDatabase) return callback.onNotAllowed();
  if (userOfDatabase.token !== token) return callback.onNotAllowed();

  return callback.onAuthenticated(userOfToken);
}

export const authenticateAsARegisterer = async (token, callback, dependencies) => await authenticate(token, {
  ...callback,
  onAuthenticated: userOfToken => {
    const userDTO = UserMapper.toDTO(userOfToken);

    return userDTO.isQuestionRecorderAndStudent() ? callback.onNotAllowed() : callback.onAuthenticated(userDTO);
  }
}, dependencies);

export const authenticateAsAdmin = async (token, callback, dependencies) => await authenticate(token, {
  ...callback,
  onAuthenticated: userOfToken => {
    const userDTO = UserMapper.toDTO(userOfToken);

    return userDTO.isAdmin() ? callback.onAuthenticated(userDTO) : callback.onNotAllowed();
  }
}, dependencies);

export const folderWithBooks = async (token, userId, callback, dependencies) => await authenticateAsARegisterer(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { FolderRepository } } = dependencies;
    const folders = await FolderRepository.findFolderWithBooks(userId);

    return callback.onFound(folders);
  }
}, dependencies);
