import BranchMapper from './mappers/BranchMapper.js';
import { authenticate, authenticateAsAdmin } from './User.js';

const templateBranch = (branch, user) => ({
  ...BranchMapper.toEntity(branch),
  createdBy: user.id,
  active: true,
});

export const store = async (branch, token, callback, dependencies) => await authenticateAsAdmin(token, {
  ...callback,
  onAuthenticated: async user => {
    const { repositories: { BranchRepository } } = dependencies;
    const branchDTO = BranchMapper.toDTO(branch);

    return await branchDTO.validate(dependencies, {
      onValidated: async () => {
        const savedBranch = await BranchRepository.save(templateBranch(branchDTO, user));

        return callback.onSaved(savedBranch);
      },
      onInvalidated: callback.onError
    });
  }
}, dependencies);

export const createBranches = list => {
  var map = {}, node, roots = [], i;
  
  for (i = 0; i < list.length; i += 1) {
    map[list[i].id] = i;
    list[i].childrens = [];
  }

  //TODO: Post order traversal needed to correctly sum questions number
  
  for (i = 0; i < list.length; i += 1) {
    node = list[i];
    if (node.parentBranch) {
      list[map[node.parentBranch]].childrens.push(node);
      list[map[node.parentBranch]].questions += node.questions;
    } else {
      roots.push(node);
    }
  }

  return roots;
};

export const index = async (includerFilters, blockerFilters, boards, token, callback, dependencies) => await authenticate(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { BranchRepository, QuestionBranchRepository, QuestionRepository } } = dependencies;
    const pureBranches = await BranchRepository.findAll();

    const count = await QuestionBranchRepository.countByBranches({
      includerFilters,
      blockerFilters,
      boards,
    }, dependencies);

    const branches = pureBranches.map(branch => ({
      ...branch.dataValues,
      questions: count[branch.id] || 0
    }));

    // const branches = await Promise.all(pureBranches.map((async branch => ({
    //   ...branch.dataValues,
    //   questions: await QuestionBranchRepository.countByBranch(branch.id, {
    //     includerFilters,
    //     blockerFilters,
    //     boards,
    //   }, dependencies),
    // }))));
  
    const structuredBranches = createBranches(branches.map(branch => ({ ...branch, childrens: [] })));
    const total = await QuestionRepository.count(boards, includerFilters, blockerFilters);

    return callback.onFound(structuredBranches, total);
  },
}, dependencies);

export const show = async (token, branchId, callback, dependencies) => await authenticateAsAdmin(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { BranchRepository } } = dependencies;
    const branch = await BranchRepository.findById(branchId);

    return branch ? callback.onFound(branch) : callback.onNotFound();
  }
}, dependencies);

export const update = async (newProps, token, branchId, callback, dependencies) => await show(token, branchId, {
  ...callback,
  onFound: async branch => {
    const { repositories: { BranchRepository } } = dependencies;
    const branchDTO = BranchMapper.toDTO(branch);

    branchDTO.addNewProps(newProps);
    return branchDTO.validate(dependencies, {
      onValidated: async () => await BranchRepository.updateById(branchId, newProps, callback),
      onInvalidated: callback.onError
    })
  },
}, dependencies);

export const remove = async (token, branchId, callback, dependencies) => await show(token, branchId, {
  ...callback,
  onFound: async () => {
    const { repositories: { BranchRepository, QuestionBranchRepository } } = dependencies;

    const questionsOfBranch = await QuestionBranchRepository.countByBranch(branchId, { includerFilters: [], blockerFilters: [], boards: [] }, dependencies);

    if (questionsOfBranch) {
      return callback.onError(['Não é possível deletar tags com questões vinculadas a ela.'])
    }

    await QuestionBranchRepository.deleteByBranch(branchId);
    await BranchRepository.deleteById(branchId, callback);

    return;
  },
}, dependencies);
