import i18next from 'i18next';
import TestMapper from './mappers/TestMapper.js';
import UserMapper from './mappers/UserMapper.js';
import { authenticate, authenticateAsARegisterer } from './User.js';

const toStringBoard = ({ board, category, ...test }) => ({
  board: board.name,
  ...test,
  type: category?.name ?? category,
  typeName: category?.name ?? ''
});

export const store = async (test, fileNames, token, callback, dependencies) => authenticate(token, {
  ...callback,
  onAuthenticated: async user => {
    const filesDescriptions = (test?.filesDescriptions ?? '')?.split(',').filter(Boolean) ?? [];

    const { repositories: { TestRepository, TestFileRepository, BoardRepository } } = dependencies;
    const testDTO = TestMapper.toDTO(test);

    return await testDTO.validate(dependencies, {
      onValidated: async () => {
        const board = testDTO.board;
        const boardData = await BoardRepository.find(board);
        const boardId = await boardData ? boardData.id : await (async () => {
          const savedBoard = await BoardRepository.save({ name: board });

          return savedBoard.id;
        })()
        const savedTest = await TestRepository.save({ ...TestMapper.toEntity(testDTO), boardId, createdBy: user.id });

        filesDescriptions.forEach(async (fileDescription, filesDescriptionIndex) => {
          const fileName = fileNames[filesDescriptionIndex];

          await TestFileRepository.save({
            path: fileName,
            description: fileDescription,
            testId: savedTest.id,
          });
        });

        return callback.onSaved(savedTest);
      },
      onInvalidated: callback.onError
    });
  }
}, dependencies);

export const index = async (token, keyWord, type, year, board, page, callback, dependencies) => {
  const {
    repositories: { TestRepository },
    services: { Token },
  } = dependencies;
  const userOfToken = Token.decrypt(token);

  if (!userOfToken) return callback.onNotAllowed();

  const userDTO = UserMapper.toDTO(userOfToken);
  const tests = await TestRepository.search(keyWord, page, board, {
    ...(type ? ({ type }) : ({})),
    ...(year ? ({ year: Number(year) }) : ({})),
    ...(userDTO.isQuestionRecorderAndStudent() ? ({ createdBy: Number(userDTO.id) }) : ({}))
  });
  const pages = await TestRepository.countPages();

  return callback.onFound(tests.map(test => toStringBoard(test.dataValues)), pages);
};

export const show = async (token, testId, callback, dependencies) => await authenticate(token, {
  ...callback,
  onAuthenticated: async user => {
    const { repositories: { TestRepository } } = dependencies;
    const test = await TestRepository.findById(testId);

    if (!test) return callback.onNotFound();

    const userDTO = UserMapper.toDTO(user);
    const testIsOfUser = test.createdBy === userDTO.id;

    if (userDTO.isQuestionRecorderAndStudent() && !testIsOfUser) {
      return callback.onNotAllowed();
    }

    return callback.onFound(toStringBoard(test));
  }
}, dependencies);

export const update = async (newProps, fileNames, token, testId, callback, dependencies) => await show(token, testId, {
  ...callback,
  onFound: test => {
    const { repositories: { TestRepository, TestFileRepository, BoardRepository } } = dependencies;
    const testDTO = TestMapper.toDTO(test);

    testDTO.addNewProps(newProps);

    return testDTO.validate(dependencies, {
      onInvalidated: callback.onError,
      onValidated: async () => {
        const board = testDTO.board;
        const boardData = await BoardRepository.find(board);

        const boardId = await boardData ? boardData.id : await (async () => {
          const savedBoard = await BoardRepository.save({ name: board });

          return savedBoard.id;
        })()

        await TestRepository.updateById(testId, { ...newProps, boardId }, callback);

        const testFiles = await TestFileRepository.findByTest(testId);
        const originalFiles = JSON.parse(newProps?.originalFiles ?? '[]');
        const filesDescriptions = (newProps?.filesDescriptions ?? '')?.split(',') ?? [];

        testFiles.forEach(async (file) => {
          const isDeleted = originalFiles.every((f) => f.id !== file.id);

          if (isDeleted) TestFileRepository.deleteById(file.id, {
            onDeleted: () => {},
            onError: () => {},
          });
        });

        fileNames.forEach(async (fileName, fileIndex) => {
          await TestFileRepository.save({
            path: fileName,
            description: filesDescriptions[fileIndex],
            testId: test.id,
          });
        })
      }
    });
  }
}, dependencies);

export const remove = async (token, testId, callback, dependencies) => await authenticateAsARegisterer(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { TestRepository, QuestionRepository } } = dependencies;
    const test = await TestRepository.findById(testId);

    if (!test) return callback.onNotFound();

    const questions = await QuestionRepository.countByTest(testId);

    if (questions) return callback.onError([ i18next.t('models.test.messages.errors.hasQuestions') ]);

    return await TestRepository.deleteById(testId, callback);
  }
}, dependencies);

export const boards = async (keyWord, token, callback, dependencies) => await authenticateAsARegisterer(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { BoardRepository } } = dependencies;
    const boardsData = await BoardRepository.search(keyWord);
    const boards = boardsData.map((board) => board.name);
    const boardsWithoutDuplication = [...new Set(boards)]

    return callback.onFound(boardsWithoutDuplication)
  }
}, dependencies);

const wizzardItem = ({
  available,
  position,
  id,
  badges,
  isCommented,
  isDraft
}) => ({
  available,
  position,
  id,
  badges,
  isCommented,
  isDraft
})

const templateWizzard = (test, questions) =>
  Array(test.amountOfQuestions)
    .fill()
    .map((_, index) => {
      const position = index + 1;
      const questionOfPosition = questions.find((q) => q.position === position);
      const available = !questionOfPosition;
      const badges = questionOfPosition?.badges ?? [];
      const id = questionOfPosition?.id ?? null;

      return wizzardItem({
        available,
        position,
        id,
        badges,
        isCommented: Boolean(questionOfPosition?.isCommented),
        isDraft: !!questionOfPosition?.isDraft
      });
    });

export const wizzard = async (token, testId, callback, dependencies) => await show(token, testId, {
  ...callback,
  onFound: async test => {
    const { repositories: { QuestionRepository } } = dependencies;
    const testDTO = TestMapper.toDTO(test);
    const questions = await QuestionRepository.findByTest(testDTO.id);
    const testWizzard = templateWizzard(testDTO, questions);

    return callback.onFound(testWizzard);
  },
}, dependencies);
