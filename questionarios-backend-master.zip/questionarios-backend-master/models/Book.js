import BookMapper from './mappers/BookMapper.js';
import i18next from 'i18next';
import { show as showFolder } from './Folder.js';

export const templateBookConfig = ({ amount, topic }) => ({
  amount,
  topic,
});

const getQuestions = async (book, includerFilters, blockerFilters, dependencies) => {
  const { repositories: { QuestionRepository } } = dependencies;
  const boards = book?.boards ?? [];
  const hasSelectedTopic = Boolean(book.config.length);

  if (hasSelectedTopic) {
    const questions = await (async () => {
      const accumulator = [];
  
      for (let item of book.config) {
        const questionsOfTopic = await QuestionRepository.findRandomly(item.topic, item.amount, boards, includerFilters, blockerFilters, dependencies);
        const questionsWithTemplate = questionsOfTopic.map(question => templateAnswer({ id: question.id, branchId: item.topic }));
  
        accumulator.push(...questionsWithTemplate);
      }
  
      return accumulator;
    })();

    return questions;
  } else {
    const questions = await QuestionRepository.findRandomly(0, book.total, boards, includerFilters, blockerFilters, dependencies);
    const questionsWithTemplate = questions.map(question => templateAnswer({ id: question.id, branchId: question?.questionBranches?.[0]?.id }));

    return questionsWithTemplate;
  }
}

export const templateBook = async (book, folder, includerFilters, blockerFilters, dependencies) => {
  const config = book.config.map(templateBookConfig);
  const questions = await getQuestions(book, includerFilters, blockerFilters, dependencies);

  return {
    ...book,
    folderId: folder.id,
    questions,
    config,
  };
};

export const fillBranchPath = async (branch, dependencies) => {
  const { repositories: { BranchRepository } } = dependencies
  const branchId = branch?.id ?? 0;
  const parentsBranches = await BranchRepository.findParents(branchId);
  const structuredBranches = parentsBranches.reverse().map(branch => ({ ...branch.dataValues, childrens: [] }));

  return { ...branch, path: structuredBranches }
}

export const reponseTemplate = async (book, dependencies) => {
  const { repositories: { QuestionRepository } } = dependencies;
  const questionsOfBook = book?.questions ?? [];
  const questions = await Promise.all(questionsOfBook.map(async question => {
    const questionWithBranch = await QuestionRepository.findByIdWithBranches(question?.id);
    const questionBranches = questionWithBranch?.questionBranches ?? [];
    const questionBranchesWithPath = await Promise.all(questionBranches.map((questionBranch) => fillBranchPath(questionBranch, dependencies)));

    return { ...question, ...questionWithBranch, questionBranches: questionBranchesWithPath.map((q = {}) => ({
      ...(q?.dataValues ?? {}),
      path: q?.path ?? []
    })) };
  }));

  const completeQuestions = questions.map(({ answers, ...question }, index) => {
    const markedsQuestion = question?.markeds ?? [];

    return {
      ...questionsOfBook[index],
      ...question,
      answers: answers.map(((answer, answerIndex) => ({ ...answer, marked: markedsQuestion[answerIndex]?.marked }))),
    }
  });

  return { ...book, questions: completeQuestions };
}

const templateAnswer = ({
  branchId,
  id,
  isCorrect = false,
  markeds = [],
  name = '',
}) => ({
  branchId,
  id,
  isCorrect,
  name,
  markeds,
});

export const templateAnswers = (questions, answers) => questions.map(question => {
  const answer = answers.find(a => a.id === question.id);

  if (!answer) return templateAnswer(question);

  const correctAnswer = question.answers.find(item => item.correct);

  if (!correctAnswer) return templateAnswer({ ...question, isCorrect: false, name: '', markeds: answer.markeds });

  const isCorrect = answer.option === correctAnswer.description;

  return templateAnswer({ ...question, isCorrect, name: answer.option, markeds: answer.markeds });
});

export const isAllowedToManageBooks = async (token, userId, folderId, callback, dependencies) => await showFolder(userId, folderId, token, {
  ...callback,
  onFound: callback.onAuthenticated,
}, dependencies);

export const filters = async (callback, dependencies) => {
  const {
    repositories: {
      QuestionRepository: {
        INCLUDER_FILTERS, BLOCKER_FILTERS
      },
    },
  } = dependencies;
  const includerFilters = Object.keys(INCLUDER_FILTERS);
  const blockerFilters = Object.keys(BLOCKER_FILTERS);

  return callback({ blockerFilters, includerFilters });
}

export const index = async (userId, folderId, token, keyWord = '', page = 0, callback, dependencies) => await isAllowedToManageBooks(token, userId, folderId, {
  ...callback,
  onAuthenticated: async folder => {
    const { repositories: { BookRepository } } = dependencies;
    const books = await BookRepository.searchByFolder(folder.id, keyWord, page);
    const pages = await BookRepository.countPagesByFolder(folder.id);
  
    return callback.onFound(books, pages);
  },
}, dependencies);

export const show = async (userId, folderId, bookId, token, callback, dependencies) => await isAllowedToManageBooks(token, userId, folderId, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { BookRepository } } = dependencies;
    const book = await BookRepository.findById(Number(bookId));

    if (!book) return callback.onNotFound();

    const completeBook = await reponseTemplate(book, dependencies);

    return callback.onFound(completeBook);
  }
}, dependencies);

export const update = async (newProps, userId, folderId, bookId, token, callback, dependencies) => await show(userId, folderId, bookId, token, {
  ...callback,
  onFound: async book => {
    const { repositories: { BookRepository } } = dependencies;
    const bookDTO = BookMapper.toDTO(book);

    bookDTO.addNewProps(newProps);

    return await bookDTO.validate([], [], dependencies, {
      onValidated: async () => await BookRepository.updateById(Number(bookId), newProps, callback),
      onInvalidated: callback.onError
    })
  },
}, dependencies);

export const remove = async (userId, folderId, bookId, token, callback, dependencies) => await show(userId, folderId, bookId, token, {
  ...callback,
  onFound: async book => {
    const { repositories: { BookRepository } } = dependencies;

    return await BookRepository.deleteById(book.id, callback);
  }
}, dependencies);

export const check = async (answers, userId, folderId, bookId, token, callback, dependencies) => await show(userId, folderId, bookId, token, {
  ...callback,
  onFound: async book => {
    const { repositories: { BookRepository } } = dependencies;

    if (!Array.isArray(answers)) return callback.onError([ i18next.t('models.book.messages.errors.invalidAnswers') ]);

    const isValidAnswers = answers.every(answer => book.questions.some(question => question.id === answer.id));

    if (!isValidAnswers) return callback.onError([ i18next.t('models.book.messages.errors.invalidAnswers') ]);

    const answersWithTemplate = templateAnswers(book.questions, answers);
    const newProps = { questions: answersWithTemplate };

    return await BookRepository.updateById(Number(bookId), newProps, callback);
  },
}, dependencies);

export const store = async (userId, folderId, book, includerFilters, blockerFilters, token, callback, dependencies) => await isAllowedToManageBooks(token, userId, folderId, {
  ...callback,
  onAuthenticated: async (folder) => {
    const {
      repositories: { BookRepository },
    } = dependencies;
    const bookDTO = BookMapper.toDTO(book);

    return await bookDTO.validate(includerFilters, blockerFilters, dependencies, {
      onValidated: async () => {
        const preparedBook = await templateBook(BookMapper.toEntity(bookDTO), folder, includerFilters, blockerFilters, dependencies);
        const savedBook = await BookRepository.save(preparedBook);
  
        return callback.onSaved(savedBook);
      },
      onInvalidated: callback.onError
    });
  }
}, dependencies);
