import BadgeMapper from './mappers/BadgeMapper.js';
import { authenticate } from './User.js';

export const isAllowedToManageBadges = async (token, callback, dependencies) => await authenticate(token, callback, dependencies);

export const store = async (badge, token, callback, dependencies) => await isAllowedToManageBadges(token, {
  ...callback,
  onAuthenticated: async () => {
    const {
      repositories: { BadgeRepository },
      services: { Token },
    } = dependencies;
    const badgeDTO = BadgeMapper.toDTO(badge);

    return badgeDTO.validate({
      onValidated: async () => {
        const savedBadge = await BadgeRepository.save(BadgeMapper.toEntity(badgeDTO));

        return callback.onSaved(savedBadge);
      },
      onInvalidated: callback.onError
    });
  }
}, dependencies);

export const index = async (token, callback, dependencies) => await isAllowedToManageBadges(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { BadgeRepository } } = dependencies;
    const badges = await BadgeRepository.all();
  
    return callback.onFound(badges);
  },
}, dependencies);

const show = async (badgeId, token, callback, dependencies) => await isAllowedToManageBadges(token, {
  ...callback,
  onAuthenticated: async () => {
    const { repositories: { BadgeRepository } } = dependencies;
    const badge = await BadgeRepository.findById(Number(badgeId));

    if (!badge) return callback.onNotFound();

    return callback.onFound(badge);
  }
}, dependencies);

export const update = async (newProps, badgeId, token, callback, dependencies) => await show(badgeId, token, {
  ...callback,
  onFound: async badge => {
    const { repositories: { BadgeRepository } } = dependencies;
    const badgeDTO = BadgeMapper.toDTO(badge);

    badgeDTO.addNewProps(newProps);

    return badgeDTO.validate({
      onValidated: async () => await BadgeRepository.updateById(Number(badgeId), newProps, callback),
      onInvalidated: callback.onError
    })
  },
}, dependencies);

export const remove = async (badgeId, token, callback, dependencies) => await show(badgeId, token, {
  ...callback,
  onFound: async badge => {
    const { repositories: { BadgeRepository } } = dependencies;

    return await BadgeRepository.deleteById(badge.id, callback);
  }
}, dependencies);
