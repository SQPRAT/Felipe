import nodemailer from 'nodemailer';
import dotEnv from 'dotenv';

dotEnv.config();

const USER_EMAIL = process.env.MAIL_USERNAME;
const USER_PASSWORD = process.env.MAIL_PASSWORD;

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: USER_EMAIL,
    pass: USER_PASSWORD
  }
});

export const sendEmail = (emailDestination, message, subject) => {
  const mailOptions = {
    from: USER_EMAIL,
    to: emailDestination,
    subject,
    text: message
  };

  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
}
