import Encrypt from './Encrypt.js';
import Token from './Token.js';
import Pages from './Pages.js';
import S3 from './S3.js';
import * as Email from './Email.js';

export default {
  Encrypt,
  Token,
  Pages,
  S3,
  Email,
}
