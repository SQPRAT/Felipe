import AWS_SDK from 'aws-sdk';

const s3Provider = new AWS_SDK.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
})

export default class S3 { 
  static upload(file, fileName) {
    const params = {
      Bucket: process.env.AWS_BUCKET_NAME,
      Key: fileName,
      Body: file.buffer,
    };

    s3Provider.upload(params, (err, data) => {
      if (err) {
        console.log(`Error uploading ${fileName}`);
        return;
      }

      console.log(`File uploaded successfully. ${data.Location}`);
    })
  }
}
