import express from 'express';
import HomeController from '../controllers/HomeController.js';
import AuthController from '../controllers/AuthController.js';
import UserController from '../controllers/UserController.js';
import TestController from '../controllers/TestController.js';
import QuestionController from '../controllers/QuestionController.js';
import BranchController from '../controllers/BranchController.js';
import BookController from '../controllers/BookController.js';
import FolderController from '../controllers/FolderController.js';
import BadgeController from '../controllers/BadgeController.js';
import TestTypeController from '../controllers/TestTypeController.js';
import withFileSupport from '../middlewares/withFileSupport.js';
import withFileUpload from '../middlewares/withFileUpload.js';

const routes = express.Router();

routes.get('/', HomeController.index);

routes.post('/auth', AuthController.login);

routes.post('/recover-password', AuthController.recoverPassword)

routes.get('/user/accesses', UserController.accesses);

routes.post('/user', UserController.store);
routes.get('/user', UserController.index);
routes.get('/user/:id', UserController.show);
routes.patch('/user/:id', UserController.update);
routes.delete('/user/:id', UserController.remove);

routes.get('/user/:id/statistics', UserController.statistics);

routes.get('/user/:id/folder-with-books', UserController.folderWithBooks);

routes.post('/user/:userId/folder', FolderController.store);
routes.get('/user/:userId/folder', FolderController.index);
routes.get('/user/:userId/folder/:id', FolderController.show);
routes.patch('/user/:userId/folder/:id', FolderController.update);
routes.delete('/user/:userId/folder/:id', FolderController.remove);

routes.get('/book-filters', BookController.filters);
routes.post('/user/:userId/folder/:folderId/book', BookController.store);
routes.get('/user/:userId/folder/:folderId/book', BookController.index);
routes.get('/user/:userId/folder/:folderId/book/:id', BookController.show);

// TODO: Fix update route
// routes.patch('/user/:userId/folder/:folderId/book/:id', BookController.update);

routes.delete('/user/:userId/folder/:folderId/book/:id', BookController.remove);
routes.put('/user/:userId/folder/:folderId/book/:id', BookController.check);

routes.post('/test', withFileSupport, withFileUpload, TestController.store);
routes.get('/test', TestController.index);
routes.get('/test/boards', TestController.boards);
routes.get('/test/:id', TestController.show);
routes.patch('/test/:id', withFileSupport, withFileUpload, TestController.update);
routes.delete('/test/:id', TestController.remove);
routes.get('/test/:id/wizzard', TestController.wizzard);

routes.get('/question/:id', QuestionController.showDirectly);

routes.post('/test-type', TestTypeController.store);
routes.get('/test-type', TestTypeController.index);
routes.delete('/test-type/:id', TestTypeController.remove);

routes.post('/test/:testId/question', QuestionController.store);
routes.get('/test/:testId/question', QuestionController.index);
routes.get('/test/:testId/question/:id', QuestionController.show);
routes.patch('/test/:testId/question/:id', QuestionController.update);
routes.delete('/test/:testId/question/:id', QuestionController.remove);

routes.post('/branch', BranchController.store);
routes.get('/branch', BranchController.index);
routes.patch('/branch/:id', BranchController.update);
routes.delete('/branch/:id', BranchController.remove);

routes.post('/badge', BadgeController.store);
routes.get('/badge', BadgeController.index);
routes.patch('/badge/:id', BadgeController.update);
routes.delete('/badge/:id', BadgeController.remove);

export default routes;
