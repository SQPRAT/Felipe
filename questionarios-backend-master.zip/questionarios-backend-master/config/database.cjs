require('dotenv').config();

const commonConfig = {
  dialect: 'postgres',
  host: process.env.DB_HOST,
  username: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: 5432,
  maxConcurrentQueries: 100,
  pool: {
    maxConnections: 5,
    maxIdleTime: 30
  },
  additional: {
    timestamps: true,
    underscored: true
  },
};

const developmentConfig = {
  ...commonConfig,
};

const productionConfig = {
  ...commonConfig,
  dialectOptions: process.env.DB_ENABLE_SSL && {
    ssl: {
      require: true,
      rejectUnauthorized: false,
    },
  },
};

const DEVELOPMENT_CONFIG_KEY = 'development';
const PRODUCTION_CONFIG_KEY = 'production';

const configs = {
  [DEVELOPMENT_CONFIG_KEY]: developmentConfig,
  [PRODUCTION_CONFIG_KEY]: productionConfig,
};

const env = process.env.NODE_ENV || 'development';

module.exports = configs[env];
