export const statusCodes = {
  ERROR: 400,
  CREATED: 201,
  NOT_ALLOWED: 401,
  OK: 200,
  NOT_FOUND: 404,
  UPDATED: 202,
};

export const userTypes = {
  ADMIN: 0,
  QUESTION_RECORDER: 1,
  QUESTION_RECORDER_AND_STUDENT: 2,
};

export const testTypes = {
  EXERCISE_CICLE: 1,
  QUESTION_SYSTEM: 2,
  EMULATION: 3,
}

export const questionTypes = {
  BOOLEAN: 1,
  ALTERNATIVES: 2,
};

export const ITEMS_PER_PAGE = 15;

export const ALLOWED_DOCUMENT_TYPES = [
  'png',
  'jpg',
  'jpeg',
  'pdf',
  'gif',
  'doc',
  'docx',
];
