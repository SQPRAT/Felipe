import Sequelize from 'sequelize';
import databaseConfig from '../config/database.cjs';
import { User } from '../models/repositories/UserRepository.js';
import { Test } from '../models/repositories/TestRepository.js';
import { Question } from '../models/repositories/QuestionRepository.js';
import { Branch } from '../models/repositories/BranchRepository.js';
import { Book } from '../models/repositories/BookRepository.js';
import { Folder } from '../models/repositories/FolderRepository.js';
import { QuestionBranch } from '../models/repositories/QuestionBranchRepository.js';
import { Badge } from '../models/repositories/BadgeRepository.js';
import { QuestionBadge } from '../models/repositories/QuestionBadgeRepository.js';
import { TestFile } from '../models/repositories/TestFileRepository.js';
import { Board } from '../models/repositories/BoardRepository.js';
import { UserAccess } from '../models/repositories/UserAccessRepository.js';
import { TestType } from '../models/repositories/TestTypeRepository.js';

const connection = new Sequelize(databaseConfig);

User.init(connection);
Test.init(connection);
Question.init(connection);
Branch.init(connection);
Book.init(connection);
Folder.init(connection);
QuestionBranch.init(connection);
Badge.init(connection);
QuestionBadge.init(connection);
TestFile.init(connection);
Board.init(connection);
UserAccess.init(connection);
TestType.init(connection);

Test.associate(connection.models);
Question.associate(connection.models);
User.associate(connection.models);
Branch.associate(connection.models);
Book.associate(connection.models);
Folder.associate(connection.models);
QuestionBranch.associate(connection.models);
Badge.associate(connection.models);
QuestionBadge.associate(connection.models);
TestFile.associate(connection.models);
Board.associate(connection.models);
UserAccess.associate(connection.models);
TestType.associate(connection.models);

connection.sync()
  .then(() => console.log('Connected to database'))
  .catch(err => console.log('Connection to database failed', err));
