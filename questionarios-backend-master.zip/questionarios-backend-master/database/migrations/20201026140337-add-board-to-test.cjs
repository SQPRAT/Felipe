'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Tests',
    'board',
    {
      type: Sequelize.STRING,
      allowNull: true,
    }
  ),

  down: async queryInterface => queryInterface.removeColumn('Tests', 'board')
};
