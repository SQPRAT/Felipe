'use strict';

module.exports = {
  up: async queryInterface => queryInterface.removeColumn('Questions', 'type'),

  down: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Questions',
    'type',
    {
      type: Sequelize.INTEGER,
      allowNull: true,
    }
  )
};
