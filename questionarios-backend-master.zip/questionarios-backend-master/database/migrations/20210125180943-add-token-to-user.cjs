'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Users',
    'token',
    {
      type: Sequelize.TEXT,
      allowNull: true,
    }
  ),

  down: async queryInterface => queryInterface.removeColumn('Users', 'token')
};
