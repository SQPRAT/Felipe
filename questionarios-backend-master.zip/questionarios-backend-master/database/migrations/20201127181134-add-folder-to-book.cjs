'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Books',
    'folderId',
    {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: { model: 'Folders', key: 'id' },
      onUpdate: 'CASCADE',
      onDelete: 'CASCADE'
    }
  ),

  down: async queryInterface => queryInterface.removeColumn('Books', 'folderId')
};
