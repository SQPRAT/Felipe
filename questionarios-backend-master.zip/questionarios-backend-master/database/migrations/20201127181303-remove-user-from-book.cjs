'use strict';

module.exports = {
  up: async (queryInterface) => queryInterface.removeColumn('Books', 'user'),

  down: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Books',
    'user',
    {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: { model: 'Users', key: 'id' },
      onUpdate: 'CASCADE',
      onDelete: 'CASCADE'
    }
  )
};
