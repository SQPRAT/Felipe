'use strict';

module.exports = {
  up: async (queryInterface) => queryInterface.removeColumn('Questions', 'year'),

  down: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Questions',
    'year',
    {
      type: Sequelize.STRING,
      allowNull: true,
    }
  )
};
