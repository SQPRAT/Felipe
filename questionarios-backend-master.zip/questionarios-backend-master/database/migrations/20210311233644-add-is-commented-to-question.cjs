'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Questions',
    'isCommented',
    {
      type: Sequelize.BOOLEAN,
      allowNull: true,
    }
  ),

  down: async queryInterface => queryInterface.removeColumn('Questions', 'isCommented')
};
