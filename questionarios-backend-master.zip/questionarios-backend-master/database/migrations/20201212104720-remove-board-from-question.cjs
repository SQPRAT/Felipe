'use strict';

module.exports = {
  up: async (queryInterface) => queryInterface.removeColumn('Questions', 'responsible'),

  down: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Questions',
    'responsible',
    {
      type: Sequelize.STRING,
      allowNull: true,
    }
  )
};
