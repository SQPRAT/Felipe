'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Branches',
    'active',
    {
      type: Sequelize.BOOLEAN,
      allowNull: true,
      default: true,
    }
  ),

  down: async queryInterface => queryInterface.removeColumn('Branches', 'active')
};
