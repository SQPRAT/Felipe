'use strict';

module.exports = {
  up: async queryInterface => queryInterface.removeColumn('Questions', 'status'),

  down: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Questions',
    'status',
    {
      type: Sequelize.STRING,
      allowNull: true,
    }
  )
};
