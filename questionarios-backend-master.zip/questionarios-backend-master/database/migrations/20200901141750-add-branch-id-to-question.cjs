'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Questions',
    'branchId',
    {
      type: Sequelize.INTEGER,
      allowNull: false,
      references: { model: 'Branches', key: 'id' },
      onUpdate: 'CASCADE',
      onDelete: 'CASCADE'
    }
  ),

  down: async queryInterface => queryInterface.removeColumn('Questions', 'branchId')
};
