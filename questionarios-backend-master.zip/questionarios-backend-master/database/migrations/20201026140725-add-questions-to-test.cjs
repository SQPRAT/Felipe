'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Tests',
    'amountOfQuestions',
    {
      type: Sequelize.INTEGER,
      allowNull: true,
    }
  ),

  down: async queryInterface => queryInterface.removeColumn('Tests', 'amountOfQuestions')
};
