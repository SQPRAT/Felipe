'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Tests',
    'questionTypes',
    {
      type: Sequelize.INTEGER,
      allowNull: true,
    }
  ),

  down: async queryInterface => queryInterface.removeColumn('Tests', 'questionTypes')
};
