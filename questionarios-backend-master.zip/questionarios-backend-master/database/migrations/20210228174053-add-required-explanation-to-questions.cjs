'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => queryInterface.changeColumn('Questions', 'explanation', {
    type: Sequelize.TEXT,
    allowNull: false,
    defaultValue: ''
  }),

  down: async (queryInterface, Sequelize) => queryInterface.changeColumn('Questions', 'explanation', {
    type: Sequelize.TEXT,
    allowNull: true,
  }),
};
