'use strict';

module.exports = {
  up: async queryInterface => queryInterface.removeColumn('Tests', 'board'),

  down: async (queryInterface, Sequelize) => queryInterface.addColumn(
    'Tests',
    'board',
    {
      type: Sequelize.STRING,
      allowNull: true,
    }
  )
};
