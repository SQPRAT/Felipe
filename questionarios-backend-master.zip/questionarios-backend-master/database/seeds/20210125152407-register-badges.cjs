'use strict';

require('dotenv').config();

const moment = require('moment');

module.exports = {
  up: async queryInterface => await queryInterface.bulkInsert('Badges', [
    {
      name: 'Desatualizada',
      createdAt: moment().format(),
      updatedAt: moment().format(),
    },
    {
      name: 'Adaptada',
      createdAt: moment().format(),
      updatedAt: moment().format(),
    },
    {
      name: 'Revisar',
      createdAt: moment().format(),
      updatedAt: moment().format(),
    },
    {
      name: 'Anulada',
      createdAt: moment().format(),
      updatedAt: moment().format(),
    },
  ], {}),

  down: async queryInterface => await queryInterface.bulkDelete('Badges', null, {}),
};
