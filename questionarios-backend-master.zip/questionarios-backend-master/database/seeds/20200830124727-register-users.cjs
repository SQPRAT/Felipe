'use strict';

require('dotenv').config();

const CryptoJS = require('crypto-js');
const moment = require('moment');

const CRYPTO_KEY = process.env.CRYPTO_KEY;
const password = CryptoJS.AES.encrypt('Password102030', CRYPTO_KEY).toString();

module.exports = {
  up: async queryInterface => await queryInterface.bulkInsert('Users', [
    {
      name: 'Super administrador',
      email: 'superadmin@admin.com',
      password,
      type: 0,
      createdAt: moment().format(),
      updatedAt: moment().format(),
    },
    {
      name: 'Administrador',
      email: 'admin@admin.com',
      password,
      type: 1,
      createdAt: moment().format(),
      updatedAt: moment().format(),
    },
    {
      name: 'Cadastrador',
      email: 'cadastrador@admin.com',
      password,
      type: 2,
      createdAt: moment().format(),
      updatedAt: moment().format(),
    },
  ], {}),

  down: async queryInterface => await queryInterface.bulkDelete('Users', null, {}),
};
