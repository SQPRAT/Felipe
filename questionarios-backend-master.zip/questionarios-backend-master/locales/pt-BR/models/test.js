export default {
  messages: {
    errors: {
      invalidName: 'Nome da prova precisa ter entre {{ minLength }} e {{ maxLength }} caracteres.',
      invalidBoard: 'Banca da prova precisa ter entre {{ minLength }} e {{ maxLength }} caracteres.',
      invalidYear: 'Formato do ano inválido.',
      invalidType: 'Tipo de prova inválido.',
      invalidQuestions: 'Número de questões precisa ser entre {{min}} e {{max}}.',
      invalidQuestionType: 'Tipo de questões selecionado inválido.',
      hasQuestions: 'Prova tem questões cadastradas.',
      filledQuestions: 'Existem questões já cadastradas depois da posição {{position}}, para editar delete-as.'
    }
  }
}
  