export default {
  messages: {
    errors: {
      invalidName: 'Nome do livro precisa ter entre {{ minLength }} e {{ maxLength }} caracteres.',
      invalidConfig: 'Formato de questões selecionadas inválido.',
      invalidTopic: 'Tópico {{ name }} não possui {{ amount }} questões cadastradas.',
      invalidAnswers: 'Uma das questões respondidas não está no caderno.',
      invalidBoard: 'Banca enviada inválida.',
      invalidTotal: 'Total precisa maior que zero.'
    },
  },
};
