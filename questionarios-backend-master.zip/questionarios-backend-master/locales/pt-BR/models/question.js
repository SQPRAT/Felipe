export default {
  messages: {
    errors: {
      invalidName: 'Nome da prova precisa ter entre {{ minLength }} e {{ maxLength }} caracteres.',
      invalidAnswers: 'Formato de respostas inválido, você precisa selecionar a questão correta e preencher todas alternativas.',
      invalidType: 'Tipo de pergunta não encontrado.',
      invalidExplanation: 'Explicação da pergunta no mínimo {{ minLength }} caracteres.',
      invalidDescription: 'Descrição da pergunta no mínimo {{ minLength }} caracteres.',
      invalidBranches: 'Uma das pastas selecionadas é inexistente.',
      invalidBadges: 'Uma das badges selecionadas é existente.',
      invalidAmount: 'Todas questões dessa prova já foram cadastradas.',
      invalidPosition: 'A questão Nº{{position}} já foi preenchida.',
      overflowedPosition: 'Posição maior do que a quantidade de questões da prova selecionada.',
      requiredBranch: 'É necessário vincular pelo menos uma tag a questão.'
    },
  }
}
