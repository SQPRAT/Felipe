export default {
  messages: {
    errors: {
      invalidName: 'Nome do ramo precisa ter entre {{ minLength }} e {{ maxLength }} caracteres.',
      invalidParent: 'Ramo pai não encontrado.',
      duplicatedName: 'Nome do ramo está duplicado.'
    }
  }
}
