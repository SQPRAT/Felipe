export default {
  messages: {
    errors: {
      invalidEmail: 'Formato de email inválido.',
      duplicatedEmail: 'Email já está em uso.',
      invalidPassword: 'Senha precisa ter entre {{ minLength }} e {{ maxLength }} caraceteres.',
      invalidName: 'Nome precisa ter entre {{ minLength }} e {{ maxLength }} caraceteres.',
      differentPassword: 'Senha e confirmação de senha estão diferente.'
    }
  }
}
