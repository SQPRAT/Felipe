export default {
  messages: {
    errors: {
      invalidName: 'Nome da badge precisa ter entre {{ minLength }} e {{ maxLength }} caracteres.',
    },
  },
};
