export default {
  messages: {
    errors: {
      invalidName: 'Nome da pasta precisa ter entre {{ minLength }} e {{ maxLength }} caracteres.',
    },
  },
};
