import user from './user.js';
import test from './test.js';
import question from './question.js';
import branch from './branch.js';
import book from './book.js';
import folder from './folder.js';
import badge from './badge.js';

export default {
  user,
  test,
  question,
  branch,
  book,
  folder,
  badge,
}
