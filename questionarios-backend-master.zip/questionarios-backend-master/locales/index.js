import ptBR from './pt-BR/index.js';

export default {
  'pt-BR': {
    translation: ptBR
  },
}
