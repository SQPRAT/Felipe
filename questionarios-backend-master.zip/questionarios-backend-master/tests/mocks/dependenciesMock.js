import userFactory from '../factories/userFactory.js';
import services from '../../services/index.js';

export default ({ repositories, services: overrideServices } = {}) => ({
  repositories: {
    UserRepository: {
      findByEmail: jest.fn().mockReturnValue(userFactory()),
      findById: jest.fn().mockReturnValue(userFactory()),
      updateById: jest.fn(),
      deleteById: jest.fn(),
      save: jest.fn().mockReturnValue(userFactory()),
      search: jest.fn().mockReturnValue([ userFactory() ]),
      countPages: jest.fn().mockReturnValue(1),
    },
    QuestionBranchRepository: {
      deleteByQuestion: jest.fn(),
    },
    QuestionBadgeRepository: {
      deleteByQuestion: jest.fn(),
    },
    BoardRepository: {
      find: jest.fn(),
      save: jest.fn().mockReturnValue({ id: 1 }),
    },
    QuestionRepository: {
      findAfterPositionByTest: jest.fn().mockReturnValue([]),
    },
    ...repositories
  },
  services: {
    ...services,
    ...overrideServices,
  }
})
