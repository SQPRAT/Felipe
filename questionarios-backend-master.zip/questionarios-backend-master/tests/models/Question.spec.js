import dependenciesMock from '../mocks/dependenciesMock.js';
import * as Question from '../../models/Question.js';
import userFactory from '../factories/userFactory.js';
import testFactory from '../factories/testFactory.js';
import branchFactory from '../factories/branchFactory.js';
import questionFactory from '../factories/questionFactory.js';
import { userTypes } from '../../config/constants.js';

describe.skip('Question model', () => {
  describe('store', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onError: jest.fn(),
        onSaved: jest.fn(),
        onNotFound: jest.fn(),
      }
    });

    it('has the correct behavior when question can be stored', async () => {
      const token = 'token!';
      const user = userFactory();
      const test = testFactory();
      const question = questionFactory();
      const branch = branchFactory();
      const testId = 1;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
      }
      const fakeQuestion = {
        save: jest.fn().mockReturnValue(question),
        countByTest: jest.fn().mockReturnValue(10),
        findByTest: jest.fn().mockReturnValue(null),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch)
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch,
        },
      });

      await Question.store(question, token, testId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).toHaveBeenCalledWith(question);
    });

    it('has the correct behavior when is duplicated position', async () => {
      const token = 'token!';
      const user = userFactory();
      const test = testFactory();
      const question = questionFactory({ id: null });
      const branch = branchFactory();
      const testId = 1;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
      }
      const fakeQuestion = {
        save: jest.fn().mockReturnValue(question),
        countByTest: jest.fn().mockReturnValue(10),
        findByTest: jest.fn().mockReturnValue([question]),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch)
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch,
        },
      });

      await Question.store(question, token, testId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalled();
    });

    it('has the correct behavior when user does not send the token', async () => {
      const token = 'token!';
      const user = null;
      const test = testFactory();
      const question = questionFactory();
      const branch = branchFactory();
      const testId = 1;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch)
      };
      const fakeQuestion = {
        save: jest.fn().mockReturnValue(question),
        countByTest: jest.fn().mockReturnValue(10),
        findByTest: jest.fn().mockReturnValue(null),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch,
        },
      });

      await Question.store(question, token, testId, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalled();
    });

    it('has the correct behavior when test does not exist', async () => {
      const token = 'token!';
      const user = userFactory();
      const branch = branchFactory();
      const test = null;
      const question = questionFactory();
      const testId = 1;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch)
      };
      const fakeQuestion = {
        save: jest.fn().mockReturnValue(question),
        countByTest: jest.fn().mockReturnValue(10),
        findByTest: jest.fn().mockReturnValue(null),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch,
        },
      });

      await Question.store(question, token, testId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onNotFound).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalled();
    });

    it('has the correct behavior when all questions of test is already stored', async () => {
      const amountOfQuestions = 10;
      const token = 'token!';
      const user = userFactory();
      const test = testFactory({ amountOfQuestions });
      const question = questionFactory();
      const branch = branchFactory();
      const testId = 1;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
      }
      const fakeQuestion = {
        save: jest.fn().mockReturnValue(question),
        countByTest: jest.fn().mockReturnValue(amountOfQuestions),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch)
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch,
        },
      });

      await Question.store(question, token, testId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalled();
    });
  });

  describe('update', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onError: jest.fn(),
        onUpdated: jest.fn(),
        onNotFound: jest.fn(),
      }
    });

    it('has the correct behavior when question can be updated', async () => {
      const token = 'token!';
      const user = userFactory();
      const test = testFactory();
      const branch = branchFactory();
      const question = questionFactory({ testId: test.id });
      const testId = test.id;
      const questionId = question.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch)
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
      };
      const fakeQuestion = {
        findById: jest.fn().mockReturnValue(question),
        updateById: (_, __, callback) => callback.onUpdated(),
        countByTest: jest.fn().mockReturnValue(10),
        findByTest: jest.fn().mockReturnValue(null),
      };
      const newProps = {};
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch,
        },
      });

      await Question.update(newProps, token, testId, questionId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onUpdated).toHaveBeenCalled();
    });

    it('has the correct behavior when user does not send token', async () => {
      const token = 'token!';
      const user = null;
      const branch = branchFactory();
      const test = testFactory();
      const question = questionFactory({ testId: test.id });
      const testId = test.id;
      const questionId = question.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
        countByTest: jest.fn().mockReturnValue(10),
        findByTest: jest.fn().mockReturnValue(null),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch),
      };
      const fakeQuestion = {
        findById: jest.fn().mockReturnValue(question),
        updateById: (_, __, callback) => callback.onUpdated(),
      };
      const newProps = {};
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch
        },
      });

      await Question.update(newProps, token, testId, questionId, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onUpdated).not.toHaveBeenCalled();
    });

    it('has the correct behavior when user is not admin and question is not from he', async () => {
      const token = 'token!';
      const user = userFactory({ type: userTypes.QUESTION_RECORDER_AND_STUDENT });
      const test = testFactory();
      const branch = branchFactory();
      const question = questionFactory({ testId: test.id });
      const testId = test.id;
      const questionId = question.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch),
      };
      const fakeQuestion = {
        findById: jest.fn().mockReturnValue(question),
        countByTest: jest.fn().mockReturnValue(10),
        findByTest: jest.fn().mockReturnValue(null),
        updateById: (_, __, callback) => callback.onUpdated(),
      };
      const newProps = {};
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch,
        },
      });

      await Question.update(newProps, token, testId, questionId, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onUpdated).not.toHaveBeenCalled();
    });

    it('has the correct behavior when user is not admin and question is from he', async () => {
      const token = 'token!';
      const user = userFactory({ type: userTypes.QUESTION_RECORDER_AND_STUDENT });
      const test = testFactory();
      const branch = branchFactory();
      const question = questionFactory({ testId: test.id, createdBy: user.id });
      const testId = test.id;
      const questionId = question.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        findById: jest.fn().mockReturnValue(test),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch),
      };
      const fakeQuestion = {
        findById: jest.fn().mockReturnValue(question),
        countByTest: jest.fn().mockReturnValue(10),
        findByTest: jest.fn().mockReturnValue(null),
        updateById: (_, __, callback) => callback.onUpdated(),
      };
      const newProps = {};
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          TestRepository: fakeTest,
          QuestionRepository: fakeQuestion,
          BranchRepository: fakeBranch,
        },
      });

      await Question.update(newProps, token, testId, questionId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onUpdated).toHaveBeenCalled();
    });
  });
});
