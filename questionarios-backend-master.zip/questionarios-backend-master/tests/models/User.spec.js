import dependenciesMock from '../mocks/dependenciesMock.js';
import * as User from '../../models/User.js';
import userFactory from '../factories/userFactory.js';
import { userTypes } from '../../config/constants.js';

describe.skip('User model', () => {
  describe('login', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onAllowed: jest.fn(),
        onNotAllowed: jest.fn(),
      }
    });

    it('has the correct behavior when user does not send email or password', async () => {
      const dependencies = dependenciesMock();
      const email = null;
      const password = null;

      await User.login(email, password, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onAllowed).not.toHaveBeenCalled();
    });

    it('has the correct behavior when email does not exist ou our database', async () => {
      const fakeUserRepository = {
        findByEmail: jest.fn().mockReturnValue(null),
        updateById: jest.fn(),
      };
      const dependencies = dependenciesMock({ repositories: { UserRepository: fakeUserRepository } });
      const email = 'email@email.com';
      const password = 'Password10#';

      await User.login(email, password, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onAllowed).not.toHaveBeenCalled();
    });

    it('has the correct behavior when the pasword is different', async () => {
      const password = 'Password10#';
      const wrongPassword = 'foo-bar';
      const user = userFactory({ password });
      const fakeUserRepository = {
        findByEmail: jest.fn().mockReturnValue(user),
        updateById: jest.fn(),
      };
      const dependencies = dependenciesMock({ repositories: { UserRepository: fakeUserRepository } });
      const email = 'email@email.com';

      await User.login(email, wrongPassword, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onAllowed).not.toHaveBeenCalled();
    });

    it('has the correct bevaior when are valid credentials', async () => {
      const password = 'Password10#';
      const email = 'email@email.com';
      const token = 'token!';
      const user = userFactory({ email, password });
      const fakeUserRepository = {
        findByEmail: jest.fn().mockReturnValue(user),
        updateById: jest.fn(),
      };
      const fakeEncrypt = {
        decrypt: jest.fn().mockReturnValue(password),
      };
      const fakeToken = {
        create: jest.fn().mockReturnValue(token),
      }
      const dependencies = dependenciesMock({
        repositories: { UserRepository: fakeUserRepository },
        services: { Encrypt: fakeEncrypt, Token: fakeToken }
      });

      await User.login(email, password, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onAllowed).toHaveBeenCalledWith(user, token);
    });
  });

  describe('store', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onError: jest.fn(),
        onSaved: jest.fn(),
      }
    });

    it('has the correct behavior when user can be stored', async () => {
      const token = 'token!';
      const user = userFactory();
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeUser = {
        findByEmail: jest.fn().mockReturnValue(null),
        save: jest.fn().mockReturnValue(user),
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { UserRepository: fakeUser }
      });

      await User.store(user, token, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onSaved).toHaveBeenCalledWith(user);
    });

    it('has the correct behavior when user does not send token', async () => {
      const dependencies = dependenciesMock();
      const token = null;
      const user = userFactory();

      await User.store(user, token, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalled();
    });
  });

  describe('index', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onFound: jest.fn(),
      }
    });

    it('has the correct behavior when user is admin', async () => {
      const token = 'token!';
      const user = userFactory();
      const keyword = '';
      const page = 0;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
      });

      await User.index(token, keyword, page, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onFound).toHaveBeenCalled();
    });

    it('has the correct behavior when user is not admin', async () => {
      const token = 'token!';
      const user = userFactory({ type: userTypes.QUESTION_RECORDER });
      const keyword = '';
      const page = 0;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
      });

      await User.index(token, keyword, page, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onFound).not.toHaveBeenCalled();
    });
  })
  
  describe('show', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onFound: jest.fn(),
        onNotFound: jest.fn(),
      }
    });

    it('has the correct behavior when user of token is admin', async () => {
      const token = 'token!';
      const user = userFactory();
      const userId = 1;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
      });

      await User.show(token, userId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onFound).toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
    });

    it('has the correct behavior when is same user', async () => {
      const token = 'token!';
      const user = userFactory({ type: userTypes.QUESTION_RECORDER });
      const userId = 1;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeUserRepository = {
        findById: jest.fn().mockReturnValue(user),
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { UserRepository: fakeUserRepository },
      });

      await User.show(token, userId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onFound).toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
    });

    it('has the correct behavior when is not same user and is not admin', async () => {
      const token = 'token!';
      const user = userFactory({ type: userTypes.QUESTION_RECORDER });
      const anotherUser = userFactory({ ...user, id: user.id + 1 });
      const userId = 1;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(anotherUser),
      };
      const fakeUserRepository = {
        findById: jest.fn().mockReturnValue(user),
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { UserRepository: fakeUserRepository },
      });

      await User.show(token, userId, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onFound).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
    });
  });
});
