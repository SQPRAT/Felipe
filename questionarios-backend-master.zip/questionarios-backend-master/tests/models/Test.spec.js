import dependenciesMock from '../mocks/dependenciesMock.js';
import * as Test from '../../models/Test.js';
import userFactory from '../factories/userFactory.js';
import testFactory from '../factories/testFactory.js';
import { userTypes } from '../../config/constants.js';

describe.skip('Test model', () => {
  describe('store', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onError: jest.fn(),
        onSaved: jest.fn(),
      }
    });

    it('has the correct behavior when test can be stored', async () => {
      const token = 'token!';
      const user = userFactory();
      const test = testFactory();
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeTest = {
        save: jest.fn().mockReturnValue(test),
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { TestRepository: fakeTest }
      });

      await Test.store(test, [], token, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onSaved).toHaveBeenCalledWith(test);
    });

    it('has the correct behavior when the user of token can not register test', async () => {
      const token = 'token!';
      const user = userFactory({ type: userTypes.QUESTION_RECORDER_AND_STUDENT });
      const test = testFactory();
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
      });
  
      await Test.store(test, [], token, callback, dependencies);
  
      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalledWith();
    });

    it('has the correct behavior when the user does not send a token', async () => {
      const token = null;
      const test = testFactory();
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(token),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
      });
  
      await Test.store(test, [], token, callback, dependencies);
  
      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalledWith();
    });
  });
});
