import dependenciesMock from '../mocks/dependenciesMock.js';
import * as Book from '../../models/Book.js';
import userFactory from '../factories/userFactory.js';
import branchFactory from '../factories/branchFactory.js';
import questionFactory from '../factories/questionFactory.js';
import bookFactory from '../factories/bookFactory.js';
import folderFactory from '../factories/folderFactory.js';

describe.skip('Book model', () => {
  describe('store', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onError: jest.fn(),
        onSaved: jest.fn(),
        onNotFound: jest.fn(),
      }
    });

    it('has the correct behavior when branch can be stored', async () => {
      const token = 'token!';
      const user = userFactory();
      const branch = branchFactory();
      const book = bookFactory();
      const folder = folderFactory();
      const questions = Array(3).fill(questionFactory());
      const userId = user.id;
      const folderId = folder.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeBook = {
        save: jest.fn().mockReturnValue(book),
      };
      const fakeFolder = {
        findById: jest.fn().mockReturnValue(folder),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch),
      };
      const fakeQuestions = {
        findRandomly: jest.fn().mockReturnValue(questions),
        countByBranch: jest.fn().mockReturnValue(questions.length),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          BookRepository: fakeBook,
          QuestionRepository: fakeQuestions,
          BranchRepository: fakeBranch,
          FolderRepository: fakeFolder,
        },
      });

      await Book.store(userId, folderId, book, [], [], token, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).toHaveBeenCalledWith(book);
    });

    it('has the correct behavior when user does not send token', async () => {
      const token = null;
      const user = null;
      const branch = branchFactory();
      const book = bookFactory();
      const folder = folderFactory();
      const questions = Array(3).fill(questionFactory());
      const userId = null;
      const folderId = folder.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeFolder = {
        findById: jest.fn().mockReturnValue(folder),
      };
      const fakeBook = {
        save: jest.fn().mockReturnValue(book),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch),
      };
      const fakeQuestions = {
        findRandomly: jest.fn().mockReturnValue(questions),
        countByBranch: jest.fn().mockReturnValue(questions.length),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: {
          BookRepository: fakeBook,
          QuestionRepository: fakeQuestions,
          BranchRepository: fakeBranch,
          FolderRepository: fakeFolder,
        },
      });

      await Book.store(userId, folderId, book, [], [], token, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalled();
    });
  });
});
