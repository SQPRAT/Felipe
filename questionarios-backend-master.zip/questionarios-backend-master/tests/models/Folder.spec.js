import dependenciesMock from '../mocks/dependenciesMock.js';
import * as Folder from '../../models/Folder.js';
import userFactory from '../factories/userFactory.js';
import folderFactory from '../factories/folderFactory.js';

describe.skip('Branch model', () => {
  describe('store', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onError: jest.fn(),
        onSaved: jest.fn(),
        onNotFound: jest.fn(),
      }
    });

    it('has the correct behavior when branch can be stored', async () => {
      const token = 'token!';
      const user = userFactory();
      const folder = folderFactory();
      const userId = user.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeFolder = {
        save: jest.fn().mockReturnValue(folder),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { FolderRepository: fakeFolder },
      });

      await Folder.store(userId, folder, token, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).toHaveBeenCalledWith(folder);
    });

    it('has the correct behavior when user does not send token', async () => {
      const token = null;
      const user = null;
      const folder = folderFactory();
      const userId = null;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeFolder = {
        save: jest.fn().mockReturnValue(folder),
      };
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { FolderRepository: fakeFolder },
      });

      await Folder.store(userId, folder, token, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalled();
    });
  });
});
