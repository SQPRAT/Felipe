import dependenciesMock from '../mocks/dependenciesMock.js';
import * as Branch from '../../models/Branch.js';
import userFactory from '../factories/userFactory.js';
import branchFactory from '../factories/branchFactory.js';
import { userTypes } from '../../config/constants.js';

describe.skip('Branch model', () => {
  describe('store', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onError: jest.fn(),
        onSaved: jest.fn(),
        onNotFound: jest.fn(),
      }
    });

    it('has the correct behavior when branch can be stored', async () => {
      const token = 'token!';
      const user = userFactory();
      const branch = branchFactory();
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeBranch = {
        save: jest.fn().mockReturnValue(branch),
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { BranchRepository: fakeBranch },
      });

      await Branch.store(branch, token, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).toHaveBeenCalledWith(branch);
    });

    it('has the correct behavior when user does not send token', async () => {
      const token = null;
      const user = null;
      const branch = branchFactory();
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeBranch = {
        save: jest.fn().mockReturnValue(branch),
      }
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { BranchRepository: fakeBranch },
      });

      await Branch.store(branch, token, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onNotFound).not.toHaveBeenCalled();
      expect(callback.onSaved).not.toHaveBeenCalled();
    });
  });

  describe('update', () => {
    let callback;

    beforeEach(() => {
      callback = {
        onNotAllowed: jest.fn(),
        onError: jest.fn(),
        onUpdated: jest.fn(),
        onNotFound: jest.fn(),
      }
    });

    it('has the correct behavior when branch can be updated', async () => {
      const token = 'token!';
      const user = userFactory({ type: userTypes.QUESTION_RECORDER_AND_STUDENT });
      const branch = branchFactory({ createdBy: user.id });
      const branchId = branch.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch),
        updateById: (_, __, callback) => callback.onUpdated(),
      };
      const newProps = {};
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { BranchRepository: fakeBranch },
      });

      await Branch.update(newProps, token, branchId, callback, dependencies);

      expect(callback.onNotAllowed).not.toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onUpdated).toHaveBeenCalled();
    });

    it('has the correct behavior when user is not allowed to manage this branch', async () => {
      const token = 'token!';
      const user = userFactory({ type: userTypes.QUESTION_RECORDER_AND_STUDENT });
      const branch = branchFactory({ createdBy: user.id + 1 });
      const branchId = branch.id;
      const fakeToken = {
        decrypt: jest.fn().mockReturnValue(user),
      };
      const fakeBranch = {
        findById: jest.fn().mockReturnValue(branch),
        updateById: (_, __, callback) => callback.onUpdated(),
      };
      const newProps = {};
      const dependencies = dependenciesMock({
        services: { Token: fakeToken },
        repositories: { BranchRepository: fakeBranch },
      });

      await Branch.update(newProps, token, branchId, callback, dependencies);

      expect(callback.onNotAllowed).toHaveBeenCalled();
      expect(callback.onError).not.toHaveBeenCalled();
      expect(callback.onUpdated).not.toHaveBeenCalled();
    });
  });
});
