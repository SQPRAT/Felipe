import { questionTypes } from "../../config/constants.js";

export default (overrideProps) => ({
	id: 5,
	answers: [
		{
			correct: true,
			description: 'Alternativa aqui'
		},
		{
			correct: false,
			description: 'Alternativa aqiu'
		},
	],
	position: 1,
	type: questionTypes.BOOLEAN,
	explanation: 'bacana aqui',
	description: 'dsasdadsadsa',
	branches: [],
	badges: [],
  ...overrideProps
});
