export default (overrideProps) => ({
  name: 'Direito do trabalhador zika',
	config: [
		{
			topic: 1,
			amount: 2
		}
	],
  ...overrideProps
});
