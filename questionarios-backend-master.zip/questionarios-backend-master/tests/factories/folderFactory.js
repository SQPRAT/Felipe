export default (overrideProps) => ({
  name: 'Nome da pasta aqui!',
  id: 5,
  user: 5,
  ...overrideProps
});
