import { userTypes } from "../../config/constants";

export default (overrideProps) => ({
  id: 5,
  email: 'fake@email.com',
  password: 'Password10#',
  name: 'Eduardo Moreira',
  type: userTypes.ADMIN,
  confirmPassword: 'Password10#',
  token: 'token!',
  ...overrideProps
});
