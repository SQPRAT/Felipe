import { questionTypes } from '../../config/constants';

export default (overrideProps) => ({
  id: 5,
  name: 'Nome da prova',
  year: 2020,
  board: 'Nome da banca',
  amountOfQuestions: 50,
  questionTypes: questionTypes.BOOLEAN,
  ...overrideProps
});
