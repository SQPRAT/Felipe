export default (overrideProps) => ({
  id: 5,
  createdBy: 5,
  name: 'Matemática',
  ...overrideProps
});
