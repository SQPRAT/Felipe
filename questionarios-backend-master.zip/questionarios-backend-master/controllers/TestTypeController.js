import Controller from './Controller.js';
import { store, index, remove } from '../models/TestType.js';

export default class BranchController extends Controller {
  static async store(req, res) {
    const testType = req?.body ?? {};
    const token = Controller.getToken(req);

    return await store(testType, token, Controller.authenticatedStoreCallback(res, 'testType'), Controller.dependencies);
  }

  static async index(req, res) {
    const token = Controller.getToken(req);

    return await index(token, Controller.authenticatedSearchCallback(res, 'testTypes', 'total'), Controller.dependencies);
  }

  static async remove(req, res) {
    const testTypeId = req?.params?.id;
    const token = Controller.getToken(req);

    return await remove(token, testTypeId, Controller.authenticatedRemoveCallback(res), Controller.dependencies);
  }
}
