import Controller from './Controller.js';
import { store, index, show, update, remove, showDirectly } from '../models/Question.js';

export default class QuestionController extends Controller {
  static async store(req, res) {
    const question = req?.body ?? {};
    const testId = req?.params?.testId;
    const token = Controller.getToken(req);

    return await store(question, token, testId, Controller.authenticatedStoreCallback(res, 'question'), Controller.dependencies);
  }

  static async index(req, res) {
    const testId = req?.params?.testId;
    const token = Controller.getToken(req);
    const keyWord = req?.query?.keyword ?? '';
    const page = req?.query?.page ?? 0;

    return await index(token, testId, keyWord, page, Controller.authenticatedSearchCallback(res, 'questions'), Controller.dependencies);
  }

  static async show(req, res) {
    const testId = req?.params?.testId;
    const questionId = req?.params?.id;
    const token = Controller.getToken(req);

    return await show(token, testId, questionId, Controller.authenticatedFindCallback(res, 'question'), Controller.dependencies);
  }

  static async showDirectly(req, res) {
    const questionId = req?.params?.id;
    const token = Controller.getToken(req);

    return await showDirectly(token, questionId, Controller.authenticatedFindCallback(res, 'question'), Controller.dependencies);
  }

  static async update(req, res) {
    const testId = req?.params?.testId;
    const questionId = req?.params?.id;
    const token = Controller.getToken(req);
    const newProps = req?.body ?? {};

    return await update(newProps, token, testId, questionId, Controller.authenticatedUpdateCallback(res), Controller.dependencies);
  }

  static async remove(req, res) {
    const testId = req?.params?.testId;
    const questionId = req?.params?.id;
    const token = Controller.getToken(req);

    return await remove(token, testId, questionId, Controller.authenticatedRemoveCallback(res), Controller.dependencies);
  }
}
