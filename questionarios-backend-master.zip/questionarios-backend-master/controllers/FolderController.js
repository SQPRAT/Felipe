import Controller from './Controller.js';
import { store, index, show, update, remove } from '../models/Folder.js';

export default class FolderController extends Controller {
  static async store(req, res) {
    const folder = req?.body ?? {};
    const token = Controller.getToken(req);
    const userId = req?.params?.userId ?? 0;

    return await store(userId, folder, token, Controller.authenticatedStoreCallback(res, 'folder'), Controller.dependencies);
  }

  static async index(req, res) {
    const userId = req?.params?.userId ?? 0;
    const token = Controller.getToken(req);
    const keyWord = req?.query?.keyword ?? '';
    const page = req?.query?.page ?? 0;

    return await index(userId, token, keyWord, page, Controller.authenticatedSearchCallback(res, 'folders'), Controller.dependencies);
  }

  static async show(req, res) {
    const userId = req?.params?.userId ?? 0;
    const folderId = req?.params?.id ?? 0;
    const token = Controller.getToken(req);

    return await show(userId, folderId, token, Controller.authenticatedFindCallback(res, 'folder'), Controller.dependencies);
  }

  static async update(req, res) {
    const userId = req?.params?.userId ?? 0;
    const folderId = req?.params?.id ?? 0;
    const token = Controller.getToken(req);
    const newProps = req?.body ?? {};

    return await update(newProps, userId, folderId, token, Controller.authenticatedUpdateCallback(res), Controller.dependencies);
  }

  static async remove(req, res) {
    const userId = req?.params?.userId ?? 0;
    const folderId = req?.params?.id ?? 0;
    const token = Controller.getToken(req);

    return await remove(userId, folderId, token, Controller.authenticatedRemoveCallback(res), Controller.dependencies);
  }
}
