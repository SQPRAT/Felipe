import Controller from './Controller.js';
import { store, index, show, update, remove, folderWithBooks, statistics, accesses } from '../models/User.js';
import { statusCodes } from '../config/constants.js';

export default class UserController extends Controller {
  static async store(req, res) {
    const user = req?.body ?? {};
    const token = Controller.getToken(req);

    return await store(user, token, Controller.authenticatedStoreCallback(res, 'user'), Controller.dependencies);
  }

  static async index(req, res) {
    const keyWord = req?.query?.keyword ?? '';
    const page = req?.query?.page ?? 0;
    const token = Controller.getToken(req);

    return await index(token, keyWord, page, Controller.authenticatedSearchCallback(res, 'users'), Controller.dependencies);
  }

  static async accesses(req, res) {
    const keyWord = req?.query?.keyword ?? '';
    const page = req?.query?.page ?? 0;
    const token = Controller.getToken(req);

    return await accesses(token, keyWord, page, Controller.authenticatedSearchCallback(res, 'accesses'), Controller.dependencies);
  }

  static async show(req, res) {
    const userId = req?.params?.id;
    const token = Controller.getToken(req);

    return await show(token, userId, Controller.authenticatedFindCallback(res, 'user'), Controller.dependencies);
  }

  static async statistics(req, res) {
    const userId = req?.params?.id;
    const token =  Controller.getToken(req);

    return await statistics(token, userId, Controller.authenticatedFindCallback(res, 'status'), Controller.dependencies);
  }

  static async update(req, res) {
    const userId = req?.params?.id;
    const token = Controller.getToken(req);
    const newProps = req?.body ?? {};

    return await update(token, userId, newProps, Controller.authenticatedUpdateCallback(res), Controller.dependencies);
  }

  static async remove(req, res) {
    const userId = req?.params?.id;
    const token = Controller.getToken(req);

    return await remove(token, userId, Controller.authenticatedRemoveCallback(res), Controller.dependencies);
  }

  static async folderWithBooks(req, res) {
    const userId = req?.params?.id;
    const token = Controller.getToken(req);

    return await folderWithBooks(token, userId, Controller.authenticatedSearchCallback(res, 'folders'), {
      ...Controller.dependencies,
      onFound: (folders) => res.status(statusCodes.OK).send({
        ok: true,
        folders,
      }),
    });
  }
}
