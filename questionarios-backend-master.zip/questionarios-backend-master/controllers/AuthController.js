import { login, recoverPassword } from '../models/User.js';
import { statusCodes } from '../config/constants.js';
import Controller from './Controller.js';
import i18next from 'i18next';

export default class AuthController extends Controller {
  static async login(req, res) {
    const email = req?.body?.email ?? '';
    const password = req?.body?.password ?? '';

    return await login(email, password, { 
      onAllowed: (user, token) => res.status(statusCodes.OK).send({ 
        ok: true,
        user,
        token,
      }),
      onNotAllowed: () => res.status(statusCodes.NOT_ALLOWED).send({
        ok: false,
        errors: [
          i18next.t('common.invalidAuth')
        ]
      }),
    }, Controller.dependencies);
  }

  static async recoverPassword(req, res) {
    const email = req?.body?.email ?? '';

    return await recoverPassword(email, { 
      onSuccess: () => res.status(statusCodes.OK).send({ 
        ok: true,
      }),
      onError: () => res.status(statusCodes.ERROR).send({
        ok: false,
      }),
    }, Controller.dependencies);
  } 
}
