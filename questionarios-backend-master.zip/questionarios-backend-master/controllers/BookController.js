import Controller from './Controller.js';
import { store, index, show, update, remove, check, filters } from '../models/Book.js';
import { statusCodes } from '../config/constants.js';
export default class BookController extends Controller {
  static async filters(_, res) {
    return await filters(({ blockerFilters, includerFilters }) => res.status(statusCodes.OK).send({
      ok: true,
      includerFilters,
      blockerFilters,
    }), Controller.dependencies);
  }

  static async store(req, res) {
    const book = req?.body ?? {};
    const token = Controller.getToken(req);
    const userId = req?.params?.userId ?? 0;
    const folderId = req?.params?.folderId ?? 0;
    const includerFilters = req?.body?.includerFilters ?? [];
    const blockerFilters = req?.body?.blockerFilters ?? [];

    return await store(userId, folderId, book, includerFilters, blockerFilters, token, Controller.authenticatedStoreCallback(res, 'book'), Controller.dependencies);
  }

  static async index(req, res) {
    const userId = req?.params?.userId ?? 0;
    const folderId = req?.params?.folderId ?? 0;
    const token = Controller.getToken(req);
    const keyWord = req?.query?.keyword ?? '';
    const page = req?.query?.page ?? 0;

    return await index(userId, folderId, token, keyWord, page, Controller.authenticatedSearchCallback(res, 'books'), Controller.dependencies);
  }

  static async show(req, res) {
    const userId = req?.params?.userId ?? 0;
    const folderId = req?.params?.folderId ?? 0;
    const bookId = req?.params?.id ?? 0;
    const token = Controller.getToken(req);

    return await show(userId, folderId, bookId, token, Controller.authenticatedFindCallback(res, 'book'), Controller.dependencies);
  }

  static async update(req, res) {
    const userId = req?.params?.userId ?? 0;
    const bookId = req?.params?.id ?? 0;
    const folderId = req?.params?.folderId ?? 0;
    const token = Controller.getToken(req);
    const newProps = req?.body ?? {};

    return await update(newProps, userId, folderId, bookId, token, Controller.authenticatedUpdateCallback(res), Controller.dependencies);
  }

  static async remove(req, res) {
    const userId = req?.params?.userId ?? 0;
    const folderId = req?.params?.folderId ?? 0;
    const bookId = req?.params?.id ?? 0;
    const token = Controller.getToken(req);

    return await remove(userId, folderId, bookId, token, Controller.authenticatedRemoveCallback(res), Controller.dependencies);
  }

  static async check(req, res) {
    const userId = req?.params?.userId ?? 0;
    const bookId = req?.params?.id ?? 0;
    const folderId = req?.params?.folderId ?? 0;
    const answers = req?.body ?? [];
    const token = Controller.getToken(req);

    return await check(answers, userId, folderId, bookId, token, Controller.authenticatedUpdateCallback(res), Controller.dependencies);
  }
}
