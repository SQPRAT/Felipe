import Controller from './Controller.js';
import { store, index,update, remove } from '../models/Badge.js';

export default class BadgeController extends Controller {
  static async store(req, res) {
    const badge = req?.body ?? {};
    const token = Controller.getToken(req);

    return await store(badge, token, Controller.authenticatedStoreCallback(res, 'badge'), Controller.dependencies);
  }

  static async index(req, res) {
    const token = Controller.getToken(req);

    return await index(token, Controller.authenticatedSearchCallback(res, 'badges'), Controller.dependencies);
  }

  static async update(req, res) {
    const badgeId = req?.params?.id;
    const token = Controller.getToken(req);
    const newProps = req?.body ?? {};

    return await update(newProps, badgeId, token, Controller.authenticatedUpdateCallback(res), Controller.dependencies);
  }

  static async remove(req, res) {
    const badgeId = req?.params?.id;
    const token = Controller.getToken(req);

    return await remove(badgeId, token, Controller.authenticatedRemoveCallback(res), Controller.dependencies);
  }
}
