import Controller from './Controller.js';
import { store, index, update, remove } from '../models/Branch.js';

export default class BranchController extends Controller {
  static async store(req, res) {
    const branch = req?.body ?? {};
    const token = Controller.getToken(req);

    return await store(branch, token, Controller.authenticatedStoreCallback(res, 'branch'), Controller.dependencies);
  }

  static async index(req, res) {
    const token = Controller.getToken(req);
    const includerFilters = JSON.parse(req?.query?.includerFilters ?? '[]');
    const blockerFilters = JSON.parse(req?.query?.blockerFilters ?? '[]');
    const boards = JSON.parse(req?.query?.boards ?? '[]');

    return await index(includerFilters, blockerFilters, boards, token, Controller.authenticatedSearchCallback(res, 'branches', 'total'), Controller.dependencies);
  }

  static async update(req, res) {
    const branchId = req?.params?.id;
    const token = Controller.getToken(req);
    const newProps = req?.body ?? {};

    return await update(newProps, token, branchId, Controller.authenticatedUpdateCallback(res), Controller.dependencies);
  }

  static async remove(req, res) {
    const branchId = req?.params?.id;
    const token = Controller.getToken(req);

    return await remove(token, branchId, Controller.authenticatedRemoveCallback(res), Controller.dependencies);
  }
}
