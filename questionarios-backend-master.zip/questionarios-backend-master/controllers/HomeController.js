import Controller from './Controller.js';

export default class HomeController extends Controller {
  static async index(_, res) {
    return res.send('Online api!');
  }
}
