import Controller from './Controller.js';
import {
  store,
  index,
  show,
  update,
  remove,
  boards,
  wizzard,
} from '../models/Test.js';

export default class TestController extends Controller {
  static async boards(req, res) {
    const keyWord = req?.query?.keyword ?? '';
    const token = Controller.getToken(req);

    return await boards(keyWord, token, Controller.authenticatedSearchCallback(res, 'boards'), Controller.dependencies);
  }

  static async wizzard(req, res) {
    const testId = req?.params?.id;
    const token = Controller.getToken(req);

    return await wizzard(token, testId, Controller.authenticatedFindCallback(res, 'wizzard'), Controller.dependencies);
  }

  static async store(req, res) {
    const test = req?.body ?? {};
    const token = Controller.getToken(req);
    const fileNames = req?.fileNames ?? [];

    return await store(test, fileNames, token, Controller.authenticatedStoreCallback(res, 'test'), Controller.dependencies);
  }

  static async index(req, res) {
    const keyWord = req?.query?.keyword ?? '';
    const type = req?.query?.type ?? null;
    const year = req?.query?.year ?? null;
    const page = req?.query?.page ?? 0;
    const board = req?.query?.board ?? '';
    const token = Controller.getToken(req);

    return await index(token, keyWord, type, year, board, page, Controller.authenticatedSearchCallback(res, 'tests'), Controller.dependencies);
  }

  static async show(req, res) {
    const testId = req?.params?.id;
    const token = Controller.getToken(req);

    return await show(token, testId, Controller.authenticatedFindCallback(res, 'test'), Controller.dependencies);
  }

  static async update(req, res) {
    const testId = req?.params?.id;
    const token = Controller.getToken(req);
    const newProps = req?.body ?? {};
    const fileNames = req?.fileNames ?? [];

    return await update(newProps, fileNames, token, testId, Controller.authenticatedUpdateCallback(res), Controller.dependencies);
  }

  static async remove(req, res) {
    const testId = req?.params?.id;
    const token = Controller.getToken(req);

    return await remove(token, testId, Controller.authenticatedRemoveCallback(res), Controller.dependencies);
  }
}
