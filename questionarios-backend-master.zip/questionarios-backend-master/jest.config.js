export default {
  transform: {
    "^.+\\.jsx?$": "babel-jest"
  }
}
