import multer from 'multer';

const withFileSupport = (req, res, next) => {
  const uploader = multer();

  return uploader.array('files')(req, res, next);
};

export default withFileSupport;
