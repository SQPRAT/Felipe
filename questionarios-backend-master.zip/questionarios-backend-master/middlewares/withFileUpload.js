import i18next from 'i18next';
import S3 from '../services/S3.js';
import { ALLOWED_DOCUMENT_TYPES, statusCodes } from '../config/constants.js';

const withFileUpload = (req, res, next) => {
  const files = req?.files ?? [];
  const hasSomeInvalidFile = files.some((file) => (
    ALLOWED_DOCUMENT_TYPES.every(documentType => !file.originalname.endsWith(documentType))
  ));

  if (hasSomeInvalidFile) return res.status(statusCodes.ERROR).send({
    ok: false,
    errors: [i18next.t('common.somethingWrong')],
  });

  const fileNames = [];

  files.forEach((file) => {
    const fileName = `test-file/${new Date().getTime()}-${file.originalname.trim()}`;

    fileNames.push(fileName);

    S3.upload(file, fileName);
  });

  req.fileNames = fileNames;

  next();
};

export default withFileUpload;
