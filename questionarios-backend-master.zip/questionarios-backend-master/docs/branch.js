export default {
  '/branch': {
    post: {
      summary: 'API Endpoint for register branch',
      tags: [ 'Branch' ],
      parameters: [
        {
          in: 'body',
          name: 'branch',
          schema: {
            type: 'object',
            properties: {
              name: {
                type: 'string',
              },
              parentBranch: {
                type: 'integer',
              },
            },
          },
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        200: {
          description: 'Registered'
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        }
      }
    },
    get: {
      summary: 'API Endpoint for find branches',
      tags: [ 'Branch' ],
      parameters: [
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
      }
    }
  },
  '/branch/{branchId}': {
    patch: {
      summary: 'API Endpoint for update branch',
      tags: [ 'Branch' ],
      parameters: [
        {
          in: 'path',
          name: 'branchId',
          description: 'id of branch',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'body',
          name: 'branch',
          schema: {
            type: 'object',
            properties: {
              name: {
                type: 'string',
              },
              parentBranch: {
                type: 'integer',
              },
            },
          },
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        202: {
          description: 'Updated',
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        },
        404: {
          description: 'Not found'
        }
      }
    },
    delete: {
      summary: 'API Endpoint for delete branch',
      tags: [ 'Branch' ],
      parameters: [
        {
          in: 'path',
          name: 'branchId',
          description: 'id of branch',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        400: {
          description: 'Error',
        },
        200: {
          description: 'Deleted'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    }
  }
}
