export default {
  '/auth': {
    post: {
      summary: 'API Endpoint for authentication',
      description : 'Authentication',
      tags: [ 'Authentication' ],
      parameters: [
        {
          in: 'body',
          name: 'user',
          schema: {
            type: 'object',
            required: [ 'email', 'password' ],
            properties: {
              email: {
                type: 'string',
              },
              password: {
                type: 'string',
              }
            }
          }
        }
      ],
      responses:{
        200: {
          description : 'Authenticated'
        },
        401: {
          description : 'Not allowed'
        }
      }
    }
  },
  '/user': {
    post: {
      summary: 'API Endpoint for register user',
      tags: [ 'User' ],
      parameters: [
        {
          in: 'body',
          name: 'user',
          schema: {
            type: 'object',
            properties: {
              email: {
                type: 'string',
              },
              password: {
                type: 'string',
              },
              type: {
                type: 'string',
              }
            }
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        200: {
          description: 'Registered'
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        }
      }
    },
    get: {
      summary: 'API Endpoint for find users',
      tags: [ 'User' ],
      parameters: [
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
        {
          in: 'query',
          name: 'page',
          schema: {
            type: 'integer'
          },
        },
        {
          in: 'query',
          name: 'keyword',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
      }
    }
  },
  '/user/{userId}': {
    patch: {
      summary: 'API Endpoint for update user',
      tags: [ 'User' ],
      parameters: [
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'body',
          name: 'newProps',
          schema: {
            type: 'object',
            properties: {
              email: {
                type: 'string',
              },
              password: {
                type: 'string',
              },
              type: {
                type: 'string',
              }
            }
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        202: {
          description: 'Updated',
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        },
        404: {
          description: 'Not found'
        }
      }
    },
    get: {
      summary: 'API Endpoint for search users',
      tags: [ 'User' ],
      parameters: [
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    },
    delete: {
      summary: 'API Endpoint for delete users',
      tags: [ 'User' ],
      parameters: [
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        400: {
          description: 'Error',
        },
        200: {
          description: 'Deleted'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    }
  },
  '/user/{userId}/folder-with-books': {
    get: {
      summary: 'API Endpoint for search all folders with books',
      tags: [ 'User' ],
      parameters: [
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    },
  },
  '/user/{userId}/statistics': {
    get: {
      summary: 'API Endpoint for get user statistcs',
      tags: [ 'User' ],
      parameters: [
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    },
  }
}
