import user from './user.js';
import test from './test.js';
import question from './question.js';
import branch from './branch.js';
import book from './book.js';
import folder from './folder.js';
import badge from './badge.js';
import dotEnv from 'dotenv';

dotEnv.config();

export default {
  swagger: '2.0',
  title : 'Concursos API - Documentation',
  description : 'Concursos API',
  version: '1.0.0',
  host: process.env.APP_URL,
  basePath: '/',
  schemes: [ 'http', 'https' ],
  consumes: [ 'application/json' ],
  produces: [ 'application/json' ],
  paths: {
    ...user,
    ...test,
    ...question,
    ...badge,
    ...branch,
    ...book,
    ...folder,
  }
}
