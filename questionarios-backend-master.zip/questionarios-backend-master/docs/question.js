export default {
  '/test/{testId}/question': {
    post: {
      summary: 'API Endpoint for register question',
      tags: [ 'Question' ],
      parameters: [
        {
          in: 'body',
          name: 'question',
          schema: {
            type: 'object',
            properties: {
              name: {
                type: 'string',
              },
              answers: {
                type: 'object',
                example: [
                  {
                    correct: true,
                    description: 'Contexto'
                  },
                  {
                    correct: false,
                    description: 'Contexto'
                  }
                ],
              },
              explanation: {
                type: 'string',
              },
              description: {
                type: 'string',
              },
            },
          },
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
        {
          in: 'path',
          name: 'testId',
          description: 'id of test',
          schema: {
            type: 'integer'
          }
        },
      ],
      responses:{
        200: {
          description: 'Registered'
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        },
        404: {
          description: 'Not found'
        }
      }
    },
    get: {
      summary: 'API Endpoint for find questions',
      tags: [ 'Question' ],
      parameters: [
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
        {
          in: 'query',
          name: 'page',
          schema: {
            type: 'integer'
          },
        },
        {
          in: 'query',
          name: 'keyword',
          schema: {
            type: 'string',
          },
        },
        {
          in: 'path',
          name: 'testId',
          description: 'id of test',
          schema: {
            type: 'integer'
          }
        },
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    }
  },
  '/test/{testId}/question/{questionId}': {
    patch: {
      summary: 'API Endpoint for update question',
      tags: [ 'Question' ],
      parameters: [
        {
          in: 'path',
          name: 'testId',
          description: 'id of test',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'path',
          name: 'questionId',
          description: 'id of question',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'body',
          name: 'newProps',
          schema: {
            type: 'object',
            properties: {
              name: {
                type: 'integer',
              },
              answers: {
                type: 'object',
                example: [
                  {
                    correct: true,
                    description: 'Contexto'
                  },
                  {
                    correct: false,
                    description: 'Contexto'
                  }
                ],
              },
              explanation: {
                type: 'string',
              },
              description: {
                type: 'string',
              },
            },
          },
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        202: {
          description: 'Updated',
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        },
        404: {
          description: 'Not found'
        }
      }
    },
    get: {
      summary: 'API Endpoint for get a question',
      tags: [ 'Question' ],
      parameters: [
        {
          in: 'path',
          name: 'testId',
          description: 'id of test',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'path',
          name: 'questionId',
          description: 'id of question',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        },
      },
    },
    delete: {
      summary: 'API Endpoint for delete question',
      tags: [ 'Question' ],
      parameters: [
        {
          in: 'path',
          name: 'testId',
          description: 'id of test',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'path',
          name: 'questionId',
          description: 'id of question',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        400: {
          description: 'Error',
        },
        200: {
          description: 'Deleted'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    }
  }
}
