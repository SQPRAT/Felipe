export default {
  '/badge': {
    post: {
      summary: 'API Endpoint for register badge',
      tags: [ 'Badge' ],
      parameters: [
        {
          in: 'body',
          name: 'badge',
          schema: {
            type: 'object',
            properties: {
              name: {
                type: 'string',
              },
            }
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        200: {
          description: 'Registered'
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        }
      }
    },
    get: {
      summary: 'API Endpoint for find badges',
      tags: [ 'Badge' ],
      parameters: [
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
      }
    }
  },
  '/badge/{badgeId}': {
    patch: {
      summary: 'API Endpoint for update badge',
      tags: [ 'Badge' ],
      parameters: [
        {
          in: 'path',
          name: 'badgeId',
          description: 'id of badge',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'body',
          name: 'newProps',
          schema: {
            type: 'object',
            properties: {
              name: {
                type: 'string',
              },
            }
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        202: {
          description: 'Updated',
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        },
        404: {
          description: 'Not found'
        }
      }
    },
    delete: {
      summary: 'API Endpoint for delete badges',
      tags: [ 'Badge' ],
      parameters: [
        {
          in: 'path',
          name: 'badgeId',
          description: 'id of badge',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        400: {
          description: 'Error',
        },
        200: {
          description: 'Deleted'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    }
  },
}
