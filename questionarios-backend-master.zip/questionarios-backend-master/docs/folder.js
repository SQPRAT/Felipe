export default {
  '/user/{userId}/folder': {
    post: {
      summary: 'API Endpoint for register folder',
      tags: [ 'Folder' ],
      parameters: [
        {
          in: 'body',
          name: 'folder',
          schema: {
            type: 'object',
            properties: {
              name: {
                type: 'string',
              },
            },
          },
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
      ],
      responses:{
        200: {
          description: 'Registered'
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        },
        404: {
          description: 'Not found'
        }
      }
    },
    get: {
      summary: 'API Endpoint for find folders',
      tags: [ 'Folder' ],
      parameters: [
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
        {
          in: 'query',
          name: 'page',
          schema: {
            type: 'integer'
          },
        },
        {
          in: 'query',
          name: 'keyword',
          schema: {
            type: 'string',
          },
        },
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
      ],
      responses: {
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    }
  },
  '/user/{userId}/folder/{folderId}': {
    patch: {
      summary: 'API Endpoint for update folder',
      tags: [ 'Folder' ],
      parameters: [
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'path',
          name: 'folderId',
          description: 'id of folder',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'body',
          name: 'folder',
          schema: {
            type: 'object',
            properties: {
              name: {
                type: 'string',
              },
            },
          },
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        },
      ],
      responses:{
        202: {
          description: 'Updated',
        },
        401: {
          description: 'Not allowed'
        },
        400: {
          description: 'Error'
        },
        404: {
          description: 'Not found'
        }
      }
    },
    get: {
      summary: 'API Endpoint for get a folder',
      tags: [ 'Folder' ],
      parameters: [
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'path',
          name: 'folderId',
          description: 'id of folder',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        200: {
          description: 'Found'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        },
      },
    },
    delete: {
      summary: 'API Endpoint for delete folder',
      tags: [ 'Folder' ],
      parameters: [
        {
          in: 'path',
          name: 'userId',
          description: 'id of user',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'path',
          name: 'folderId',
          description: 'id of folder',
          schema: {
            type: 'integer'
          }
        },
        {
          in: 'header',
          name: 'Authorization',
          schema: {
            type: 'string',
          },
        }
      ],
      responses:{
        400: {
          description: 'Error',
        },
        200: {
          description: 'Deleted'
        },
        401: {
          description: 'Not allowed'
        },
        404: {
          description: 'Not found'
        }
      }
    }
  }
}
