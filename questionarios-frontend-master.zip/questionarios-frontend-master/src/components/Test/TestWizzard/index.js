import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';
import { AiFillCheckCircle } from 'react-icons/ai';

import { BADGE_COLORS } from '../../../config/constants';

import './index.scss';

const TestWizzard = ({ items, onClick }) => (
  
  <ol className="TestWizzard">
    {items.map((item, index) => (
      <li
        onClick={() => onClick(index)}
        className={
          className(
            'TestWizzard__item',
            {

              [`TestWizzard__item--${BADGE_COLORS[item?.badges[0]?.name?.toUpperCase() ?? '']}`]: !item.available && Boolean(item.badges.length),
              'TestWizzard__item--disabled': item.available,
              'TestWizzard__item--draft': item.isDraft
            },
          )
        }
        // eslint-disable-next-line react/no-array-index-key
        key={`${item?.name ?? ''}-${item?.id ?? ''}-${index}`}
      >
        {item.isCommented && (
          <AiFillCheckCircle className="TestWizzard__icon" />
        )}
        {item.position}
      </li>
    ))}
  </ol>
);

TestWizzard.propTypes = {
  items: PropTypes.arrayOf(PropTypes.shape({
    available: PropTypes.bool,
    badges: PropTypes.arrayOf(PropTypes.shape({
      id: PropTypes.number,
      name: PropTypes.string,
    })),
    id: PropTypes.number,
    position: PropTypes.number,
  })).isRequired,
  onClick: PropTypes.func.isRequired,
};

export default TestWizzard;
