import React from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';

import './index.scss';

const TestInfo = ({ label, value }) => (
  <div className="TestInfo">
    <p className="TestInfo__label">{label}</p>
    <p className="TestInfo__value">{value}</p>
  </div>
);

TestInfo.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
};

const TestPreview = ({
  name,
  year,
  board,
  typeName,
  amountOfQuestions,
  files,
}) => {
  const { t } = useTranslation(['test']);

  return (
    <div className="TestPreview">
      <div className="TestPreview__header">
        <p className="TestPreview__name">{name}</p>
        <div className="TestPreview__info TestPreview__info--big">
          <TestInfo label={t('test:attributes.board')} value={board} />
        </div>
        <div className="TestPreview__info">
          <TestInfo label={t('test:attributes.year')} value={year} />
        </div>
        <div className="TestPreview__info TestPreview__info--big">
          <TestInfo label={t('test:attributes.type')} value={typeName} />
        </div>
        <div className="TestPreview__info">
          <TestInfo label={t('test:attributes.amountOfQuestions')} value={amountOfQuestions} />
        </div>
      </div>
      {files.length > 0 ? (
        <>
          <p className="TestPreview__files-title">{[t('test:attributes.files'), ':'].join('')}</p>
          <ul className="TestPreview__files">
            {files.map((file) => (
              <li className="TestPreview__file" key={`file-${file.id}`}>
                <a className="TestPreview__file-link" href={[process.env.REACT_APP_S3_BUCKET_URL, file.path].join('')} target="_blank" rel="noopener noreferrer">
                  {file.description}
                  <span className="TestPreview__file-name">{file.path}</span>
                </a>
              </li>
            ))}
          </ul>
        </>
      ) : null}
    </div>
  );
};

TestPreview.propTypes = {
  name: PropTypes.string.isRequired,
  year: PropTypes.number.isRequired,
  board: PropTypes.string.isRequired,
  typeName: PropTypes.number.isRequired,
  amountOfQuestions: PropTypes.number.isRequired,
  files: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    path: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
  })),
};

TestPreview.defaultProps = {
  files: [],
};

export default TestPreview;
