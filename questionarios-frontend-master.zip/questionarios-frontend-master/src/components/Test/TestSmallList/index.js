import React from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';

import './index.scss';

const TestSmallList = ({ tests }) => {
  const { t } = useTranslation(['test']);

  return (
    <div className="TestSmallList">
      <p className="TestSmallList__title">{t('test:lastRegistered')}</p>
      <ul className="TestSmallList__tests">
        {tests.map((test) => (
          <div className="TestSmallList__test" key={test.name}>
            <p className="TestSmallList__test-name">{test.name}</p>
            <p className="TestSmallList__test-days">{t('test:daysOnPast', { days: test.daysOnPast })}</p>
          </div>
        ))}
      </ul>
    </div>
  );
};

TestSmallList.propTypes = {
  tests: PropTypes.arrayOf(PropTypes.shape({
    name: PropTypes.string.isRequired,
    daysOnPast: PropTypes.number.isRequired,
  })).isRequired,
};

export default TestSmallList;
