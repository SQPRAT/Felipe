import React from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';

import './index.scss';

const QuestionStatus = ({ answered, correct }) => {
  const { t } = useTranslation(['question']);

  return (
    <div className="QuestionStatus">
      <div className="QuestionStatus__area QuestionStatus__area--answered">
        <p className="QuestionStatus__area-title">{t('question:answereds')}</p>
        <p className="QuestionStatus__area-number">{answered}</p>
      </div>
      <div className="QuestionStatus__area QuestionStatus__area--correct">
        <p className="QuestionStatus__area-title">{t('question:corrects')}</p>
        <p className="QuestionStatus__area-number">{correct}</p>
      </div>
    </div>
  );
};

QuestionStatus.propTypes = {
  answered: PropTypes.number.isRequired,
  correct: PropTypes.number.isRequired,
};

export default QuestionStatus;
