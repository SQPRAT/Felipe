import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';
import { BADGE_COLORS } from '../../../config/constants';

import './index.scss';

const QuestionBadge = ({ name, isSelected }) => (
  <div
    className={
      className(
        'QuestionBadge',
        `QuestionBadge--${BADGE_COLORS[name.toUpperCase()]}`,
        {
          'QuestionBadge--selected': isSelected,
        },
      )
    }
  >
    {name}
  </div>
);

QuestionBadge.propTypes = {
  name: PropTypes.string.isRequired,
  isSelected: PropTypes.bool.isRequired,
};

export default QuestionBadge;
