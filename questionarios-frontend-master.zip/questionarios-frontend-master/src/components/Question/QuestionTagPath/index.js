import React from 'react';
import PropTypes from 'prop-types';
import { BsArrowRight } from 'react-icons/bs';
import QuestionTag from '../QuestionTag';

import './index.scss';

const QuestionTagPath = ({ path }) => (
  <div className="QuestionTagPath">
    {path.map((tag, index) => (
      <div className="QuestionTagPath__tag">
        <QuestionTag>
          {tag?.name ?? ''}
        </QuestionTag>
        {path.length > 1 && index !== path.length - 1 && (
          <BsArrowRight className="QuestionTagPath__arrow-right" />
        )}
      </div>
    ))}
  </div>
);

QuestionTagPath.propTypes = {
  path: PropTypes.arrayOf(PropTypes.shape({
    name: PropTypes.string.isRequired,
  })).isRequired,
};

export default QuestionTagPath;
