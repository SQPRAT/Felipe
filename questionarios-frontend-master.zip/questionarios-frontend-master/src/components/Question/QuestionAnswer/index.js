/* eslint-disable react/no-danger */
import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';
import { useTranslation } from 'react-i18next';

import './index.scss';

const QuestionAnswer = ({
  explanation,
  description,
  isSelected,
  letter,
  isMarked,
  showExplanation,
  showAnswer,
  isCorrect,
  isCancelled,
}) => {
  const { t } = useTranslation(['question']);

  return (
    <div
      className={
        className('QuestionAnswer', {
          'QuestionAnswer--focus': isSelected && !showAnswer && !showExplanation,
          'QuestionAnswer--show': showExplanation,
          'QuestionAnswer--correct': isCorrect && showAnswer && !isCancelled,
          'QuestionAnswer--wrong': !isCorrect && isSelected && showAnswer && !isCancelled,
          'QuestionAnswer--marked': isMarked,
          'QuestionAnswer--empty-explanation': showExplanation && !explanation,
        })
      }
    >
      <div className="QuestionAnswer__content">
        <p className="QuestionAnswer__explanation">
          <span className="QuestionAnswer__explanation--letter">{[letter, ')', ' '].join('')}</span>
          <p dangerouslySetInnerHTML={{ __html: description }} />
        </p>
        {Boolean(showExplanation && explanation) && (
          <div className="QuestionAnswer__explanation">
            <b>{[t('question:attributes.explanation'), ':', ' '].join('')}</b>
            <p dangerouslySetInnerHTML={{ __html: explanation }} />
          </div>
        )}
      </div>
    </div>
  );
};

QuestionAnswer.defaultProps = {
  isMarked: false,
};

QuestionAnswer.propTypes = {
  explanation: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  isSelected: PropTypes.bool.isRequired,
  letter: PropTypes.string.isRequired,
  showExplanation: PropTypes.bool.isRequired,
  showAnswer: PropTypes.bool.isRequired,
  isCorrect: PropTypes.bool.isRequired,
  isMarked: PropTypes.bool,
  isCancelled: PropTypes.bool.isRequired,
};

export default QuestionAnswer;
