import React from 'react';
import PropTypes from 'prop-types';

import './index.scss';

const QuestionTag = ({ children }) => (
  <div className="QuestionTag">{children}</div>
);

QuestionTag.propTypes = {
  children: PropTypes.node.isRequired,
};

export default QuestionTag;
