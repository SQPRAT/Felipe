import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';

import './index.scss';
import { BADGE_COLORS } from '../../../config/constants';

const QuestionBadgeSubtitle = ({ name }) => (
  <div className="QuestionBadgeSubtitle">
    <span
      className={
        className(
          'QuestionBadgeSubtitle__color',
          `QuestionBadgeSubtitle__color--${BADGE_COLORS[name.toUpperCase()]}`,
        )
      }
    />
    <p className="QuestionBadgeSubtitle__name">{name}</p>
  </div>
);

QuestionBadgeSubtitle.propTypes = {
  name: PropTypes.string.isRequired,
};

export default QuestionBadgeSubtitle;
