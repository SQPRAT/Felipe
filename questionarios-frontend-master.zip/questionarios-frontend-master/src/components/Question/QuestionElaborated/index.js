/* eslint-disable react/no-danger */
import React from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';
import { AiOutlineLink } from 'react-icons/ai';
import { useHistory } from 'react-router-dom';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import QuestionAnswer from '../QuestionAnswer';
import { privateRoutes } from '../../../config/constants';

import './index.scss';

const LETTERS = ['A', 'B', 'C', 'D', 'E'];

const QuestionElaborated = ({
  id,
  readOnly,
  test,
  description,
  answers,
  onSelectAnswer,
  selected,
  showExplanation,
  onMarkAnswer,
  explanation,
  showAnswer,
  isCancelledQuestion,
  selectedAnswerIndex,
  testId,
}) => {
  const history = useHistory();
  const { t } = useTranslation(['question']);

  const handleClickQuestionId = () => history.push(privateRoutes.EDIT_QUESTION.path(testId, id));
  const handleCopyLink = () => toast.success('Copiado!');

  return (
    <div className="QuestionElaborated">
      <ToastContainer />
      <div className="QuestionElaborated__title">
        {!readOnly ? (
          <CopyToClipboard text={`${window.location.origin}${privateRoutes.EDIT_QUESTION_DIRECTLY.path(id)}`} onCopy={handleCopyLink}>
            <AiOutlineLink className="QuestionElaborated__copy-link" />
          </CopyToClipboard>
        ) : (
          <CopyToClipboard text={`${window.location.origin}${privateRoutes.VIEW_QUESTION.path(id)}`} onCopy={handleCopyLink}>
            <AiOutlineLink className="QuestionElaborated__copy-link" />
          </CopyToClipboard>
        )}

        <button className="QuestionElaborated__title--blue" onClick={handleClickQuestionId}>{['#', id].join('')}</button>
        {test}
      </div>
      {isCancelledQuestion && showAnswer && (
        <span className="QuestionElaborated__warning">
          {t('question:cancelledWarning')}
        </span>
      )}
      <p className="QuestionElaborated__description" dangerouslySetInnerHTML={{ __html: description }} />
      {Boolean(showExplanation && explanation) && (
        <div className="QuestionElaborated__explanation">
          <b>{[t('question:attributes.explanation'), ':', ' '].join('')}</b>
          <div dangerouslySetInnerHTML={{ __html: explanation }} />
        </div>
      )}
      <ul className="QuestionElaborated__answers">
        {answers.map((answer, index) => (
          <li
            onDoubleClick={() => onMarkAnswer(id, index)}
            className="QuestionElaborated__answer"
            key={`${answer.explanation}-${answer.description}-${LETTERS[index]}`}
            onClick={() => onSelectAnswer(answer, index)}
          >
            <QuestionAnswer
              explanation={answer.explanation}
              description={answer.description}
              isSelected={selected === answer.description && index === selectedAnswerIndex}
              isMarked={answer.marked}
              isCorrect={answer.correct}
              letter={LETTERS[index]}
              showExplanation={showExplanation}
              showAnswer={showAnswer}
              isCancelled={isCancelledQuestion}
            />
          </li>
        ))}
      </ul>
    </div>
  );
};

QuestionElaborated.propTypes = {
  id: PropTypes.number.isRequired,
  readOnly: PropTypes.bool.isRequired,
  explanation: PropTypes.string.isRequired,
  test: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  onSelectAnswer: PropTypes.func.isRequired,
  answers: PropTypes.arrayOf(PropTypes.shape({
    explanation: PropTypes.string.isRequired,
  })).isRequired,
  selected: PropTypes.string.isRequired,
  selectedAnswerIndex: PropTypes.number.isRequired,
  onMarkAnswer: PropTypes.func.isRequired,
  showExplanation: PropTypes.bool.isRequired,
  showAnswer: PropTypes.bool.isRequired,
  isCancelledQuestion: PropTypes.bool.isRequired,
  testId: PropTypes.number.isRequired,
};

export default QuestionElaborated;
