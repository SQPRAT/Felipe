import React from 'react';
import { useTranslation } from 'react-i18next';
import PropTypes from 'prop-types';
import className from 'classnames';

import './index.scss';

const QuestionFeedback = ({
  correct,
  onToggleExplanation,
  isCancelledQuestion,
  isCommented,
}) => {
  const { t } = useTranslation(['question', 'common']);

  return (
    <p className="QuestionFeedback">
      {!isCancelledQuestion && (
        <>
          {`${t('question:alternative')} `}
          <span
            className={
              className({
                'QuestionFeedback__alternative--correct': correct,
                'QuestionFeedback__alternative--incorrect': !correct,
              })
            }
          >
            {correct ? t('common:correct') : t('common:incorrect')}
          </span>
          {'! '}
        </>
      )}
      {isCommented ? (
        <>
          {`${t('common:seeThe')} `}
          <button onClick={onToggleExplanation} className="QuestionFeedback__link">{t('question:teacherExplanation')}</button>
        </>
      ) : t('question:emptyComment')}
    </p>
  );
};

QuestionFeedback.propTypes = {
  correct: PropTypes.bool.isRequired,
  onToggleExplanation: PropTypes.func.isRequired,
  isCancelledQuestion: PropTypes.bool.isRequired,
  isCommented: PropTypes.bool.isRequired,
};

export default QuestionFeedback;
