import React, { useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';
import { IoMdClose, IoMdAdd } from 'react-icons/io';
import { AiFillDelete, AiFillEdit } from 'react-icons/ai';
import useService from '../../../hooks/useService';
import BoxOptions from '../../ui/BoxOptions';

const BranchOptions = ({
  onClose, onCreate, onDelete, onUpdate,
}) => {
  const { t } = useTranslation(['common', 'branch']);
  const Alert = useService('Alert');

  const handleCreateBranch = useCallback(() => {
    Alert.withInput({
      title: t('branch:nameSentence'),
    }, onCreate);
  }, [Alert, onCreate, t]);

  const handleUpdateBranch = useCallback(() => {
    Alert.withInput({
      title: t('branch:nameSentence'),
    }, onUpdate);
  }, [Alert, onUpdate, t]);

  const options = useMemo(() => ([
    {
      icon: IoMdClose,
      onClick: onClose,
      text: t('common:close'),
      focus: true,
    },
    {
      icon: IoMdAdd,
      onClick: handleCreateBranch,
      text: t('branch:create'),
      focus: false,
    },
    {
      icon: AiFillDelete,
      onClick: onDelete,
      text: t('common:delete'),
      focus: false,
    },
    {
      icon: AiFillEdit,
      onClick: handleUpdateBranch,
      text: t('common:edit'),
      focus: false,
    },
  ]), [onClose, onDelete, handleCreateBranch, t, handleUpdateBranch]);

  return <BoxOptions options={options} />;
};

BranchOptions.propTypes = {
  onClose: PropTypes.func.isRequired,
  onCreate: PropTypes.func.isRequired,
  onDelete: PropTypes.func.isRequired,
  onUpdate: PropTypes.func.isRequired,
};

export default BranchOptions;
