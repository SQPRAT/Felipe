/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
} from 'react';
import { useTranslation } from 'react-i18next';
import PropTypes from 'prop-types';
import Input from '../ui/Input';
import Button from '../ui/Button';
import TextEditor from '../ui/TextEditor';
import Tree from '../ui/Tree';
import Autocomplete from '../ui/Autocomplete';
import QuestionBadge from '../Question/QuestionBadge';
import { questionTypes, QUESTION_LETTERS } from '../../config/constants';
import useApi from '../../hooks/useApi';
import useModel from '../../hooks/useModel';
import useService from '../../hooks/useService';
import { filterFields } from '../../utils/form';
import { getParentBranches, getChildBranches, addCheckPropToBranches } from '../../selectors/branch';
import { treeBranchesFormat } from '../../formatters/branch';

import './index.scss';

const EMPTY_QUESTION = {
  answers: [],
  description: '',
  explanation: '',
  branches: [],
  badges: [],
  test: {},
  position: '',
};

const QuestionForm = ({
  onSubmitAndNavigateToNextQuestion,
  onSubmit,
  initialValues,
  hide,
}) => {
  const TestAPI = useApi('test');
  const TestModel = useModel('test');
  const [tests, setTests] = useState([]);
  const BranchAPI = useApi('branch');
  const BranchModel = useModel('branch');
  const BadgeAPI = useApi('badge');
  const BadgeModel = useModel('badge');
  const [branches, setBranches] = useState([]);
  const [badges, setBadges] = useState([]);
  const [question, setQuestion] = useState({ ...EMPTY_QUESTION, ...initialValues });
  const [testKeyword, setTestKeyword] = useState('');
  const [showTestAutocompleteOptions, toggleTestAutocompleteOptions] = useState(false);
  const { t } = useTranslation(['question', 'common', 'branch']);
  const Alert = useService('Alert');
  const isEditing = Boolean(initialValues?.test?.id);

  const fetchBranches = useCallback(async () => {
    BranchModel.search({}, {
      onSuccess: (pureBranches) => setBranches(treeBranchesFormat(pureBranches)),
      onError: Alert.error,
    }, BranchAPI);
  }, [Alert.error, BranchAPI, BranchModel]);

  const fetchBadges = useCallback(async () => {
    BadgeModel.all({
      onError: Alert.error,
      onSuccess: ({ badges: data }) => setBadges(data),
    }, BadgeAPI);
  }, [Alert.error, BadgeAPI, BadgeModel]);

  const questionTestOptions = tests.map((test) => ({
    value: JSON.stringify({ id: test.id, questionTypes: test.questionTypes }),
    label: test.name,
  }));

  const treeItems = useMemo(() => {
    const configs = question?.branches?.map((branch) => ({ topic: branch.branchId }));

    return addCheckPropToBranches(branches, configs);
  }, [branches, question]);

  const handleChangeValue = (key, value) => setQuestion((prevQuestion) => ({
    ...prevQuestion,
    [key]: value,
  }));

  const handleChangeAnswer = (answerIndex, key, value) => {
    setQuestion((prevQuestion) => ({
      ...prevQuestion,
      answers: (prevQuestion?.answers ?? []).map((a, index) => {
        if (index === answerIndex) return { ...a, [key]: value };

        return { ...a };
      }),
    }));
  };

  const handleChangeCorrectAnswer = (answerIndex, correct) => {
    const answers = question.answers.map((a, index) => {
      const correctItem = index === answerIndex ? correct : !correct;

      return { ...a, correct: correctItem };
    });

    handleChangeValue('answers', answers);
  };

  const handleSubmit = (e, navigateToNextQuestion = false) => {
    e.preventDefault();

    const questionObject = filterFields(hide, question);
    const questionBadges = questionObject?.badges ?? [];
    const callback = navigateToNextQuestion ? onSubmitAndNavigateToNextQuestion : onSubmit;

    callback({ ...questionObject, questionBadges, position: Number(questionObject.position) });
  };

  const handleChangeType = (newType) => {
    const amountOfAnswers = (() => {
      switch (newType) {
        case questionTypes.ALTERNATIVES: return 5;
        case questionTypes.BOOLEAN: return 2;
        default: return 2;
      }
    })();

    const newDescriptions = newType === questionTypes.BOOLEAN ? ['Verdadeiro', 'Falso'] : Array(amountOfAnswers).fill('');

    const newAnswers = initialValues?.answers?.length
      ? initialValues.answers.slice(0, amountOfAnswers).map((answer) => ({
        ...answer,
        hasExplanation: Boolean(answer.explanation),
      })) : Array(amountOfAnswers).fill({}).map((_, index) => ({
        correct: false,
        description: newDescriptions[index],
        explanation: '',
        key: index,
        hasExplanation: false,
      }));

    handleChangeValue('answers', newAnswers);
  };

  const handleToggleBadge = (badgeId) => {
    const alreadyIsSelected = question.badges.some((badge) => badgeId === badge.badgeId);
    const newBadges = alreadyIsSelected
      ? question.badges.filter((badge) => badge.badgeId !== badgeId)
      : [...question.badges, { badgeId }];

    handleChangeValue('badges', newBadges);
  };

  const handleSelectTest = (newValue) => {
    const parsedTest = JSON.parse(newValue.value);

    handleChangeValue('test', { ...parsedTest, name: newValue.label });
    setTestKeyword(newValue?.label ?? '');
    handleChangeType(parsedTest?.questionTypes ?? questionTypes.BOOLEAN);
  };

  const handleSelectBranch = (id, parentBranchId) => {
    const branch = { id, parentBranch: parentBranchId, branchId: id };
    const parentBranches = getParentBranches(branches, branch);
    const branchesFromQuestion = question?.branches ?? [];
    const someParentIsChecked = parentBranches.some((parentBranch) => (
      branchesFromQuestion.some((item) => item.branchId === parentBranch.id)
    ));

    if (someParentIsChecked) return;

    const alreadyIsSelected = branchesFromQuestion.some((b) => b.branchId === id);

    if (alreadyIsSelected) {
      setQuestion((prevQuestion) => ({
        ...prevQuestion,
        branches: branchesFromQuestion.filter((b) => b.branchId !== id),
      }));
    } else {
      const childBranches = getChildBranches(branches, branch);

      setQuestion((prevQuestion) => ({
        ...prevQuestion,
        branches: [...branchesFromQuestion, branch].filter((item) => (
          childBranches.every((b) => b.id !== item.branchId)
        )),
      }));
    }
  };

  const handleToggleExplanation = (index) => {
    const hasExplanation = question?.answers[index]?.hasExplanation ?? false;

    handleChangeAnswer(index, 'hasExplanation', !hasExplanation);
  };

  useEffect(() => {
    fetchBadges();
  }, [fetchBadges]);

  useEffect(() => {
    const testInitialValue = initialValues?.test?.name ?? '';
    const hasTestNameInitialValue = Boolean(testInitialValue);

    if (hasTestNameInitialValue) {
      setTestKeyword(testInitialValue);
    }

    const fetchTests = async () => {
      if (isEditing) {
        const testId = initialValues?.test?.id;

        TestModel.find(testId, {
          onError: () => t('common:notFound'),
          onSuccess: (test) => {
            handleChangeValue('test', { id: test.id, questionTypes: test.questionTypes });
            handleChangeType(test.questionTypes);
            setTests([test]);
          },
        }, TestAPI);
      } else {
        const searchParams = { keyword: testKeyword, page: 0 };

        TestModel.search(searchParams, {
          onSuccess: (newTests) => {
            const selectedTest = newTests[0] ?? {};

            if (initialValues?.test?.name && selectedTest.name !== initialValues?.test?.name) {
              return;
            }

            handleChangeValue('test', { id: selectedTest.id, questionTypes: selectedTest.questionTypes });
            handleChangeType(selectedTest.questionTypes);
            setTests(newTests);
          },
          onError: Alert.error,
        }, TestAPI);
      }
    };

    fetchTests();

    // eslint-disable-next-line
  }, [testKeyword, TestModel, TestAPI, Alert, initialValues?.test?.name]);

  useEffect(() => {
    fetchBranches();
  }, [BranchModel, BranchAPI, Alert, fetchBranches]);

  return (
    <form className="Form" onSubmit={handleSubmit}>
      {!hide.description && <TextEditor placeholder={t('question:attributes.enunciated')} variant="Form__field Form__field--big" value={question.description} onChange={(newValue) => handleChangeValue('description', newValue)} />}
      {!hide.explanation && <TextEditor placeholder={t('question:attributes.explanation')} variant="Form__field Form__field--big" value={question.explanation} onChange={(newValue) => handleChangeValue('explanation', newValue)} />}
      {!hide.position && <Input required placeholder={t('question:attributes.position')} variant="Form__field" value={question.position} onChange={(newValue) => handleChangeValue('position', newValue)} />}
      {!hide.test && (
        <Autocomplete
          showOptions={showTestAutocompleteOptions}
          variant="Form__field"
          options={questionTestOptions}
          onSelect={handleSelectTest}
          value={testKeyword}
          onChange={setTestKeyword}
          placeholder={t('question:attributes.test')}
          onFocus={() => toggleTestAutocompleteOptions(true)}
          onBlur={() => setTimeout(() => toggleTestAutocompleteOptions(false), 100)}
        />
      )}
      {!hide.badges && (
        <div className="QuestionForm__badges">
          {badges.map((badge) => (
            <span
              className="QuestionForm__badge"
              key={badge.name}
              onClick={() => handleToggleBadge(badge.id)}
            >
              <QuestionBadge
                name={badge.name}
                isSelected={question.badges.some(({ badgeId }) => badgeId === badge.id)}
              />
            </span>
          ))}
        </div>
      )}
      {question.answers.map((answer, index) => (
        <div className="QuestionForm__answer" key={answer.key}>
          <p className="QuestionForm__answer-letter">{QUESTION_LETTERS[index]}</p>
          <p className="QuestionForm__answer-correct-toggle">{t('question:correct')}</p>
          <Input required variant="QuestionForm__answer-correct" checked={answer.correct} onChange={() => handleChangeCorrectAnswer(index, !answer.correct)} type="radio" />
          <TextEditor variant="QuestionForm__answer-description" value={answer.description} onChange={(newDescription) => handleChangeAnswer(index, 'description', newDescription)} />
          {answer?.hasExplanation && (
            <TextEditor variant="QuestionForm__answer-explanation" value={answer.explanation} onChange={(newExplanation) => handleChangeAnswer(index, 'explanation', newExplanation)} placeholder={t('question:attributes.answer-explanation', { option: QUESTION_LETTERS[index] })} />
          )}
          <Button variant="QuestionForm__answer-toggle-explanation" onClick={() => handleToggleExplanation(index)}>
            {answer?.hasExplanation ? t('question:removeExplanation') : t('question:addExplanation')}
          </Button>
        </div>
      ))}
      {!hide.branches && (
        <div className="QuestionForm__branches">
          <div className="QuestionForm__branches-title">
            <p>{t('question:attributes.branch')}</p>
          </div>
          <Tree
            items={treeItems}
            onClick={({ id, parentBranch }) => handleSelectBranch(id, parentBranch)}
          />
        </div>
      )}
      <Button type="submit" variant="Form__button" onClick={handleSubmit}>
        {t('common:save')}
      </Button>
      {onSubmitAndNavigateToNextQuestion && (
        <Button type="submit" variant="Form__button" onClick={(e) => handleSubmit(e, true)}>
          {t('question:saveAndNavigate')}
        </Button>
      )}
    </form>
  );
};

QuestionForm.propTypes = {
  onSubmitAndNavigateToNextQuestion: PropTypes.func,
  onSubmit: PropTypes.func.isRequired,
  initialValues: PropTypes.shape({
    description: PropTypes.string,
    explanation: PropTypes.string,
    answers: PropTypes.arrayOf(PropTypes.shape({
      correct: PropTypes.bool,
      description: PropTypes.string,
      explanation: PropTypes.string,
    })),
    type: PropTypes.number,
    branches: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.number,
        name: PropTypes.string,
      }),
    ),
    test: PropTypes.shape({
      id: PropTypes.number,
      name: PropTypes.string,
    }),
    position: '',
  }),
  hide: PropTypes.shape({
    description: PropTypes.bool,
    position: PropTypes.bool,
    branches: PropTypes.bool,
    explanation: PropTypes.bool,
    answers: PropTypes.bool,
    type: PropTypes.bool,
    test: PropTypes.bool,
    badges: PropTypes.bool,
  }),
};

QuestionForm.defaultProps = {
  onSubmitAndNavigateToNextQuestion: null,
  initialValues: {
    test: {
      id: 0,
    },
    branches: [],
  },
  hide: {
    description: false,
    branches: false,
    test: false,
    explanation: false,
    answers: false,
    type: false,
    badges: false,
    position: false,
  },
};

export default QuestionForm;
