import React, { useState, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { FaSearch } from 'react-icons/fa';
import PropTypes from 'prop-types';
import Input from '../ui/Input';
import Tabs from '../ui/Tabs';
import Tree from '../ui/Tree';
import Box from '../ui/Box';
import Button from '../ui/Button';
import useApi from '../../hooks/useApi';
import useModel from '../../hooks/useModel';
import useService from '../../hooks/useService';
import { filterFields } from '../../utils/form';
import {
  addCheckPropToBranches,
  filterPerKeyword,
  getChildBranches,
  getParentBranches,
} from '../../selectors/branch';
import { changeFilterValue, filterValidFilters, getAmountOfQuestions } from '../../selectors/book';
import { treeBranchesFormat } from '../../formatters/branch';
import BookFilters from '../Book/BookFilters';
import BookBoardFilter from '../Book/BookBoardFilter';

import './index.scss';

const EMPTY_BOOK = {
  config: [],
  tags: [],
  name: '',
};

const BookForm = ({ onSubmit, initialValues, hide }) => {
  const BranchAPI = useApi('branch');
  const BookAPI = useApi('book');
  const BranchModel = useModel('branch');
  const BookModel = useModel('book');
  const [boards, setBoards] = useState([]);
  const [branches, setBranches] = useState([]);
  const [searchedBranches, setSearchedBranches] = useState([]);
  const [book, setBook] = useState({ ...EMPTY_BOOK, ...initialValues });
  const [branchKeyword, setBranchKeyword] = useState('');
  const [includerFilters, setIncluderFilters] = useState([]);
  const [blockerFilters, setBlockerFilters] = useState([]);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const { t } = useTranslation(['book', 'common']);
  const Alert = useService('Alert');
  const isSearching = Boolean(branchKeyword);

  const bookBoardsConfig = boards.filter((board) => board.checked);
  const bookBranchesConfig = book?.config;
  const bookBlockFiltersConfig = blockerFilters.filter((filter) => filter.value);
  const bookIncluderFiltersConfig = includerFilters.filter((filter) => filter.value);
  const hasBranchesFiilter = Boolean(bookBranchesConfig?.length);
  const hasAppliedFilter = (
    hasBranchesFiilter
      || Boolean(bookIncluderFiltersConfig.length)
      || Boolean(bookBlockFiltersConfig.length)
      || Boolean(bookBoardsConfig.length)
  );

  const handleChangeValue = (key, value) => setBook((prevBook) => ({
    ...prevBook,
    [key]: value,
  }));

  const handleClickBranch = (branch) => {
    const parentBranches = getParentBranches(branches, branch);
    const parentBranchesIds = parentBranches.map((b) => b.id);
    const bookConfig = book.config.filter((item) => !parentBranchesIds.includes(item.topic));
    const alreadyIsChecked = bookConfig.some((item) => item.topic === branch.id);

    if (alreadyIsChecked) {
      const newConfig = bookConfig.filter((item) => item.topic !== branch.id);

      handleChangeValue('config', newConfig);
    } else {
      const childBranches = getChildBranches(branches, branch);

      const newConfig = [
        ...bookConfig,
        { amount: branch.questions, topic: branch.id, data: branch },
      ].filter((item) => (
        childBranches.every((b) => b.id !== item.topic)
      ));

      handleChangeValue('config', newConfig);
    }
  };

  const handleChangeAmountOfQuestionsFromBranch = (index, newAmount) => {
    const branch = book.config[index];

    if ((branch?.data?.questions ?? 0) < newAmount) return;

    const newConfig = book.config.map((item, itemIndex) => (itemIndex === index
      ? ({ ...item, amount: Number(newAmount) })
      : ({ ...item })));

    handleChangeValue('config', newConfig);
  };

  useEffect(() => {
    const fetchFilters = async () => {
      BookModel.getFilters({
        onSuccess: (arrayIncluderFilters, arrayBlockerFilters) => {
          const dateFilters = ['createdAtBefore', 'createdAtAfter'];
          const selectFilters = ['type', 'questionTypes'];
          const numberFilters = ['year'];

          const createFilters = (filters) => filters.map((filter) => {
            const isDateFilter = dateFilters.includes(filter);
            const isSelectFilter = selectFilters.includes(filter);
            const isNumberFilter = numberFilters.includes(filter);
            const filterType = (() => {
              if (isDateFilter) return 'date';
              if (isSelectFilter) return 'select';
              if (isNumberFilter) return 'number';
              return 'boolean';
            })();

            return {
              key: filter,
              value: isDateFilter || isSelectFilter || isNumberFilter ? '' : false,
              type: filterType,
            };
          });

          setIncluderFilters(createFilters(arrayIncluderFilters));
          setBlockerFilters(createFilters(arrayBlockerFilters));
        },
        onError: Alert.error,
      }, BookAPI);
    };

    fetchFilters();
  }, [BookModel, BookAPI, Alert.error]);

  useEffect(() => {
    const fetchBranches = async () => {
      BranchModel.search({
        includerFilters: JSON.stringify(filterValidFilters(includerFilters)),
        blockerFilters: JSON.stringify(filterValidFilters(blockerFilters)),
        boards: JSON.stringify(book.tags.map(({ key }) => key)),
      }, {
        onSuccess: (pureBranches, total) => {
          setTotalQuestions(total);

          const branchesArray = treeBranchesFormat(pureBranches);
          const newConfig = book.config.map((item) => {
            const configBranchId = item.data.id;
            const selectedBranch = branchesArray.find((branch) => branch.id === configBranchId);
            const newAmount = selectedBranch.questions;

            return { ...item, amount: newAmount, data: selectedBranch };
          });

          setBranches(branchesArray);
          handleChangeValue('config', newConfig);
        },
        onError: Alert.error,
      }, BranchAPI);
    };

    fetchBranches();
    // eslint-disable-next-line
  }, [branchKeyword, BranchModel, BranchAPI, Alert, includerFilters, blockerFilters, book.tags]);

  useEffect(() => {
    if (isSearching) {
      const relatedBranches = filterPerKeyword(branchKeyword, branches);

      setSearchedBranches(relatedBranches);
    }
  }, [branchKeyword, branches, isSearching, BranchModel]);

  useEffect(() => {
    const fetchTags = async () => {
      BookModel.searchBoards('', {
        onSuccess: (boardsResponse) => setBoards(() => boardsResponse
          .map((board) => ({ key: board, label: board }))),
        onError: Alert.error,
      }, BookAPI);
    };

    fetchTags();
  }, [BookModel, Alert.error, BookAPI]);

  const total = useMemo(() => {
    if (!hasAppliedFilter) return 0;
    if (!hasBranchesFiilter) return totalQuestions;

    return getAmountOfQuestions(book);
  }, [book, totalQuestions, hasBranchesFiilter, hasAppliedFilter]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const bookObject = filterFields(hide, book);

    onSubmit({
      ...bookObject,
      boards: bookObject.tags.map(({ key }) => key),
      includerFilters: filterValidFilters(includerFilters),
      blockerFilters: filterValidFilters(blockerFilters),
      total,
    });
  };

  const handleToggleBoard = (board) => {
    const isRemovingBoard = book.tags.some((tag) => (
      tag.key === board.key && board.label === tag.label
    ));

    const newTags = isRemovingBoard ? book.tags.filter((tag) => (
      tag.key !== board.key && board.label !== tag.label
    )) : [...book.tags, board];

    const newBoards = boards.map((tag) => {
      const isSameTag = tag.key === board.key && board.label === tag.label;

      if (!isSameTag) return { ...tag };

      return {
        ...tag,
        checked: isRemovingBoard ? false : isSameTag,
      };
    });

    handleChangeValue('tags', newTags);
    setBoards(newBoards);
  };

  const handleChangeTotal = (newTotal) => {
    const totalQuestionsOfBranches = book.config.reduce((accumulator, config) => (
      accumulator + (config?.data?.questions ?? 0)
    ), 0);

    if (totalQuestionsOfBranches < newTotal) return;

    const itemsPerBranch = newTotal / book.config.length;
    const isPerfectDivistionBetweenTopics = !(
      Number(itemsPerBranch) === itemsPerBranch && itemsPerBranch % 1 !== 0
    );

    const newConfig = book.config.map((item, itemIndex) => {
      const branch = branches.find((b) => b.id === item.topic);
      const needsToRemoveOneItem = itemIndex !== 0 && !isPerfectDivistionBetweenTopics;
      const itemsInThisBranch = Math.ceil(
        needsToRemoveOneItem ? itemsPerBranch - 1 : itemsPerBranch,
      );
      const maxAmount = branch.questions;
      const amount = itemsInThisBranch > maxAmount ? maxAmount : itemsInThisBranch;

      return { ...item, amount };
    });

    const newTotalQuestions = getAmountOfQuestions({ ...book, config: newConfig });

    if (newTotalQuestions !== newTotal) {
      newConfig.forEach((item, index) => {
        const remainingQuestions = newTotal - getAmountOfQuestions({ ...book, config: newConfig });

        if (!remainingQuestions) return;

        const maxAmount = item.data.questions;
        const amountWithRemainingQuestions = item.amount + remainingQuestions;
        const newAmount = (
          amountWithRemainingQuestions > maxAmount ? maxAmount : amountWithRemainingQuestions
        );

        newConfig[index].amount = newAmount;
      });
    }

    handleChangeValue('config', newConfig);
  };

  const handleChangeBlockerFilterValue = (key, value) => {
    const newFilters = changeFilterValue(blockerFilters, key, value);

    setBlockerFilters(newFilters);
  };

  const handleChangeIncluderFilterValue = (key, value) => {
    const newFilters = changeFilterValue(includerFilters, key, value);

    setIncluderFilters(newFilters);
  };

  const treeItems = useMemo(() => {
    const pureItems = isSearching ? searchedBranches : branches;

    return addCheckPropToBranches(pureItems, book.config);
  }, [isSearching, searchedBranches, branches, book.config]);

  return (
    <form className="Form" onSubmit={handleSubmit}>
      {!hide.name && <Input required variant="Form__field" value={book.name} onChange={(newValue) => handleChangeValue('name', newValue)} type="text" placeholder="Estudar amanhã" />}
      <Tabs
        childrens={[
          hide.config ? null : ({
            title: t('book:publish'),
            content: (
              <>
                <div className="BookForm__config">
                  <FaSearch className="BookForm__config-search-icon" />
                  <Input type="search" variant="BookForm__config-search" value={branchKeyword} onChange={setBranchKeyword} />
                  <div className="BookForm__config-branches">
                    <Tree items={treeItems} onClick={handleClickBranch} />
                  </div>
                </div>
                <div className="BookForm__config-table">
                  <div className="BookForm__config-item">
                    <p>{t('book:attributes.branch')}</p>
                    <p>{t('book:attributes.amountOfQuestions')}</p>
                  </div>
                  {book.config.map((item, index) => (
                    <div className="BookForm__config-item" key={JSON.stringify(item.data)}>
                      <p>{item?.data?.name}</p>
                      <Input onChange={(newValue) => handleChangeAmountOfQuestionsFromBranch(index, newValue)} type="number" variant="BookForm__config-item--input" value={item.amount} />
                    </div>
                  ))}
                </div>
              </>
            ),
          }),
          {
            title: t('book:filters.title'),
            content: (
              <>
                <Box>
                  <BookFilters onSelectFilter={handleChangeIncluderFilterValue} title={t('book:filters.selectJust')} filters={includerFilters} />
                </Box>
                <Box>
                  <BookFilters onSelectFilter={handleChangeBlockerFilterValue} title={t('book:filters.deleteQuestions')} filters={blockerFilters} />
                </Box>
              </>
            ),
          },
          hide.board ? null : ({
            title: t('book:board'),
            content: (
              <BookBoardFilter
                boards={boards}
                onToggleBoard={handleToggleBoard}
              />
            ),
          }),
        ].filter(Boolean)}
      />
      <div className="BookForm__config-item BookForm__config-item--total">
        <p>{t('book:attributes.total')}</p>
        <Input
          disabled={!hasAppliedFilter}
          onChange={handleChangeTotal}
          type="number"
          variant="BookForm__config-item--input"
          value={total}
        />
      </div>
      <Button type="submit" variant="Form__button" onClick={handleSubmit}>
        {t('common:save')}
      </Button>
    </form>
  );
};

BookForm.propTypes = {
  onSubmit: PropTypes.func.isRequired,
  initialValues: PropTypes.shape({
    name: PropTypes.string,
    config: PropTypes.arrayOf(PropTypes.shape({
      topic: PropTypes.string,
      amount: PropTypes.number,
    })),
  }),
  hide: PropTypes.shape({
    name: PropTypes.bool,
    config: PropTypes.bool,
    board: PropTypes.bool,
  }),
};

BookForm.defaultProps = {
  initialValues: {
    name: '',
    config: [],
  },
  hide: {
    name: false,
    config: false,
    board: true,
  },
};

export default BookForm;
