import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import PropTypes from 'prop-types';
import Input from '../ui/Input';
import Button from '../ui/Button';
import Select from '../ui/Select';
import File from '../ui/File';
import { questionTypes } from '../../config/constants';
import { filterFields } from '../../utils/form';
import { getExtension, getName } from '../../selectors/file';
import useModel from '../../hooks/useModel';
import useApi from '../../hooks/useApi';
import useService from '../../hooks/useService';
import Autocomplete from '../ui/Autocomplete';

import './index.scss';
import useTestTypeOptions from '../../hooks/useTestTypeOptions';

export const EMPTY_TEST = {
  name: '',
  board: '',
  year: '',
  questionTypes: questionTypes.ALTERNATIVES,
  type: '',
  amountOfQuestions: '',
  files: [],
};

const TestForm = ({ onSubmit, initialValues, hide }) => {
  const [test, setTest] = useState({ ...EMPTY_TEST, ...initialValues });
  const [boards, setBoards] = useState([]);
  const [showBoards, setShowBoards] = useState(false);
  const testOptions = useTestTypeOptions();
  const { t } = useTranslation(['test', 'common', 'question']);
  const TestModel = useModel('test');
  const TestAPI = useApi('test');
  const Alert = useService('Alert');

  const testBoardsOptions = boards.map((board) => ({
    value: board,
    label: board,
  }));

  const handleChangeValue = (key, value) => setTest((prevTest) => ({
    ...prevTest,
    [key]: value,
  }));

  const handleSubmit = (e) => {
    e.preventDefault();

    const testObject = filterFields(hide, test);
    const files = test?.files?.map((file) => file.pure).filter(Boolean) ?? [];
    const originalFiles = test?.files?.filter((file) => !file.pure);
    const filesDescriptions = test?.files?.map((file) => file.description) ?? [];

    onSubmit({
      ...testObject,
      files,
      filesDescriptions,
      originalFiles,
    });
  };

  const questionOptions = Object.values(questionTypes).map((questionType) => ({
    value: questionType,
    label: t(`question:types.${questionType}`),
  }));

  const handleAddFile = (file) => {
    if (!file) return;

    const idOfCurrentFile = test?.files?.length ?? 0;

    setTest((prevTest) => ({
      ...prevTest,
      files: [
        ...prevTest.files,
        {
          id: idOfCurrentFile,
          pure: file,
          extension: getExtension(file),
          name: getName(file),
          description: '',
        },
      ],
    }));
  };

  const handleRemoveFile = (file) => {
    setTest((prevTest) => ({
      ...prevTest,
      files: prevTest.files.filter((item) => item.id !== file.id),
    }));
  };

  const handleChangeFileDescription = (newValue, index) => {
    setTest((prevTest) => ({
      ...prevTest,
      files: prevTest.files.map((prevFile, fileIndex) => (fileIndex === index ? ({
        ...prevFile,
        description: newValue,
      }) : ({ ...prevFile }))),
    }));
  };

  useEffect(() => {
    const boardInitialValue = initialValues?.board?.name ?? '';
    const hasBoardNameInitialValue = Boolean(boardInitialValue);

    if (hasBoardNameInitialValue) {
      setTest({ ...test, board: boardInitialValue });
    }

    const fetchBoards = async () => {
      const boardKeyword = test.board;

      TestModel.searchBoards(boardKeyword, {
        onError: () => t('common:notFound'),
        onSuccess: setBoards,
      }, TestAPI);
    };

    fetchBoards();

    // eslint-disable-next-line
  }, [TestModel, TestAPI, Alert, initialValues?.test?.name, test.board]);

  return (
    <form className="Form" onSubmit={handleSubmit}>
      {!hide.name && <Input required variant="Form__field" value={test.name} onChange={(newValue) => handleChangeValue('name', newValue)} type="text" placeholder={t('test:attributes.name')} />}
      {!hide.board && (
        <Autocomplete
          onFocus={() => setShowBoards(true)}
          onBlur={() => setTimeout(() => setShowBoards(false), 100)}
          showOptions={showBoards}
          variant="Form__field"
          onSelect={({ value }) => handleChangeValue('board', value)}
          options={testBoardsOptions}
          onChange={(newValue) => handleChangeValue('board', newValue)}
          value={test.board}
          placeholder={t('test:attributes.board')}
        />
      )}
      {!hide.year && <Input required variant="Form__field" value={test.year} onChange={(newValue) => handleChangeValue('year', Number(newValue))} type="number" placeholder={t('test:attributes.year')} />}
      {!hide.amountOfQuestions && <Input required variant="Form__field" value={test.amountOfQuestions} onChange={(newValue) => handleChangeValue('amountOfQuestions', newValue)} type="number" placeholder={t('test:attributes.questions')} />}
      {!hide.type && <Select required variant="Form__field" value={test.type} onChange={(newValue) => handleChangeValue('type', Number(newValue))} options={testOptions} />}
      {!hide.questionTypes && <Select required variant="Form__field" value={test.questionTypes} onChange={(newValue) => handleChangeValue('questionTypes', Number(newValue))} options={questionOptions} />}
      <div className="Form__field Form__field--file">
        <File
          onRemove={handleRemoveFile}
          files={test.files}
          onChangeDescription={handleChangeFileDescription}
          onUpload={(e) => handleAddFile(e.target.files[0])}
        />
      </div>
      <Button type="submit" variant="Form__button" onClick={handleSubmit}>
        {t('common:save')}
      </Button>
    </form>
  );
};

TestForm.propTypes = {
  onSubmit: PropTypes.func.isRequired,
  initialValues: PropTypes.shape({
    name: PropTypes.string,
    type: PropTypes.number,
    board: PropTypes.string,
    year: PropTypes.number,
    questionTypes: PropTypes.number,
    amountOfQuestions: PropTypes.number,
  }),
  hide: PropTypes.shape({
    name: PropTypes.bool,
    type: PropTypes.bool,
    questionTypes: PropTypes.bool,
    board: PropTypes.bool,
    year: PropTypes.bool,
    amountOfQuestions: PropTypes.bool,
  }),
};

TestForm.defaultProps = {
  initialValues: {},
  hide: {
    name: false,
    type: false,
    board: false,
    questionTypes: false,
    year: false,
    amountOfQuestions: false,
  },
};

export default TestForm;
