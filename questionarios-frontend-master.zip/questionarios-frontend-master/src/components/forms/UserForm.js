import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import PropTypes from 'prop-types';
import Input from '../ui/Input';
import Button from '../ui/Button';
import Select from '../ui/Select';
import { userTypes } from '../../config/constants';

import './index.scss';
import { filterFields } from '../../utils/form';

const EMPTY_USER = {
  email: '',
  password: '',
  confirmPassword: '',
  name: '',
  type: userTypes.ADMIN,
};

const UserForm = ({ onSubmit, initialValues, hide }) => {
  const [user, setUser] = useState({ ...EMPTY_USER, ...initialValues });
  const { t } = useTranslation(['user', 'common']);

  const handleChangeValue = (key, value) => setUser((prevUser) => ({
    ...prevUser,
    [key]: value,
  }));

  const handleSubmit = (e) => {
    e.preventDefault();

    const userObject = filterFields(hide, user);

    onSubmit(userObject);
  };

  const userOptions = Object.values(userTypes).map((userType) => ({
    value: userType,
    label: t(`user:types.${userType}`),
  }));

  return (
    <form className="Form" onSubmit={handleSubmit}>
      {!hide.email && <Input required variant="Form__field" value={user.email} onChange={(newValue) => handleChangeValue('email', newValue)} type="email" placeholder="email@email.com" />}
      {!hide.name && <Input required variant="Form__field" value={user.name} onChange={(newValue) => handleChangeValue('name', newValue)} type="text" placeholder={t('user:attributes.name')} />}
      {!hide.password && <Input required variant="Form__field" value={user.password} onChange={(newValue) => handleChangeValue('password', newValue)} type="password" placeholder={t('user:attributes.password')} />}
      {!hide.confirmPassword && <Input required variant="Form__field" value={user.confirmPassword} onChange={(newValue) => handleChangeValue('confirmPassword', newValue)} type="password" placeholder={t('user:attributes.confirmPassword')} />}
      {!hide.type && <Select required variant="Form__field" value={user.type} onChange={(newValue) => handleChangeValue('type', Number(newValue))} options={userOptions} />}
      <Button type="submit" variant="Form__button" onClick={handleSubmit}>
        {t('common:save')}
      </Button>
    </form>
  );
};

UserForm.propTypes = {
  onSubmit: PropTypes.func.isRequired,
  initialValues: PropTypes.shape({
    email: PropTypes.string,
    type: PropTypes.number,
  }),
  hide: PropTypes.shape({
    password: PropTypes.bool,
    email: PropTypes.bool,
    confirmPassword: PropTypes.bool,
    type: PropTypes.bool,
    name: PropTypes.bool,
  }),
};

UserForm.defaultProps = {
  initialValues: {},
  hide: {
    password: false,
    confirmPassword: false,
    email: false,
    type: false,
    name: false,
  },
};

export default UserForm;
