import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';

import './index.scss';

const BookControl = ({
  title, onClick, children, variant,
}) => (
  <button title={title} onClick={onClick} className={className('BookControl', variant)}>
    {children}
  </button>
);

BookControl.propTypes = {
  onClick: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
  variant: PropTypes.string,
  title: PropTypes.string,
};

BookControl.defaultProps = {
  variant: '',
  title: '',
};

export default BookControl;
