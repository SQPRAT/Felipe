import React from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';
import {
  BsArrowRight,
  BsArrowLeft,
  BsChevronDoubleRight,
} from 'react-icons/bs';
import { TiArrowShuffle } from 'react-icons/ti';
import BookControl from '../BookControl';
import BookMenuPage from '../BookMenuPage';
import CapIcon from '../../../static/images/icons/cap.svg';

import './index.scss';

const BookControllers = ({
  onPaginate,
  currentPage,
  total,
  onSeeExplanation,
  onPaginateToNextQuestionNotAnswered,
  onPaginateToNextRandomQuestionNotAnswered,
  onTogglePageMenu,
  showPageMenu,
}) => {
  const { t } = useTranslation(['book']);

  const handlePaginate = (newPage) => {
    if (newPage < 0 || newPage >= total) return;

    onPaginate(newPage);
  };

  return (
    <div className="BookControllers">
      {showPageMenu && (
        <div className="BookControllers__menu-page">
          <BookMenuPage selectedPage={currentPage} pages={total} onSelectPage={handlePaginate} />
        </div>
      )}
      <BookControl title="Questão aleatória não respondida" onClick={onPaginateToNextRandomQuestionNotAnswered}>
        <TiArrowShuffle />
      </BookControl>
      <BookControl title="Ver todas questões" onClick={onTogglePageMenu} variant="BookControllers__go-to">
        {t('book:goTo')}
      </BookControl>
      <BookControl title="Questão anterior" onClick={() => handlePaginate(currentPage - 1)}>
        <BsArrowLeft />
      </BookControl>
      <BookControl title="Próxima questão" onClick={() => handlePaginate(currentPage + 1)}>
        <BsArrowRight />
      </BookControl>
      <BookControl title="Próxima questão não respondida" onClick={onPaginateToNextQuestionNotAnswered}>
        <BsChevronDoubleRight />
      </BookControl>
      <BookControl title="Ver/ocultar explicação do professor" onClick={onSeeExplanation}>
        <img alt="cap button" src={CapIcon} />
      </BookControl>
    </div>
  );
};

BookControllers.propTypes = {
  onPaginate: PropTypes.func.isRequired,
  onSeeExplanation: PropTypes.func.isRequired,
  currentPage: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired,
  onPaginateToNextQuestionNotAnswered: PropTypes.func.isRequired,
  onPaginateToNextRandomQuestionNotAnswered: PropTypes.func.isRequired,
  showPageMenu: PropTypes.bool.isRequired,
  onTogglePageMenu: PropTypes.func.isRequired,
};

export default BookControllers;
