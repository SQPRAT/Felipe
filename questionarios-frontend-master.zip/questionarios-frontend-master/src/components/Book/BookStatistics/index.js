import React from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';
import EyeButton from '../../ui/EyeButton';

import './index.scss';

const BookStatistics = ({
  correct,
  incorrect,
  current,
  resolveds,
  total,
  showDetails,
  onToggleDetails,
}) => {
  const { t } = useTranslation(['book', 'common']);

  return (
    <div className="BookStatistics">
      <p className="BookStatistics__question-counter">{t('book:questionCounter', { current: current + 1, total })}</p>
      {showDetails && (
        <p className="BookStatistics__question-details">
          (
          <span className="BookStatistics__question-details--resolveds">{t('book:resolveds', { amount: resolveds })}</span>
          {[',', ''].join(' ')}
          <span className="BookStatistics__question-details--correct">{t('book:correct', { amount: correct })}</span>
          {['', t('common:and'), ''].join(' ')}
          <span className="BookStatistics__question-details--incorrect">{t('book:incorrect', { amount: incorrect })}</span>
          ).
        </p>
      )}
      <EyeButton onClick={onToggleDetails} isOpened={showDetails} />
    </div>
  );
};

BookStatistics.propTypes = {
  onToggleDetails: PropTypes.func.isRequired,
  correct: PropTypes.number,
  incorrect: PropTypes.number,
  current: PropTypes.number,
  total: PropTypes.number,
  showDetails: PropTypes.bool,
  resolveds: PropTypes.number,
};

BookStatistics.defaultProps = {
  showDetails: false,
  correct: 0,
  incorrect: 0,
  current: 0,
  total: 0,
  resolveds: 0,
};

export default BookStatistics;
