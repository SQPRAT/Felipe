import React from 'react';
import PropTypes from 'prop-types';

import './index.scss';

const BookProgressBar = ({ correctAnswersPercentage, incorrectAnswersPercentage }) => (
  <div className="BookProgressBar">
    <span className="BookProgressBar--correct" style={{ width: `${correctAnswersPercentage}%` }} />
    <span className="BookProgressBar--incorrect" style={{ width: `${incorrectAnswersPercentage}%` }} />
  </div>
);

BookProgressBar.propTypes = {
  correctAnswersPercentage: PropTypes.number.isRequired,
  incorrectAnswersPercentage: PropTypes.number.isRequired,
};

export default BookProgressBar;
