import React from 'react';
import className from 'classnames';
import { useTranslation } from 'react-i18next';
import { Link, useHistory } from 'react-router-dom';
import PropTypes from 'prop-types';
import { BiRightArrow } from 'react-icons/bi';
import FolderIcon from '../../../static/images/icons/folder.svg';
import ExpandIcon from '../../../static/images/icons/expand.svg';
import RemoveIcon from '../../../static/images/icons/delete.svg';
import { privateRoutes } from '../../../config/constants';
import BookProgressBar from '../BookProgressBar';
import BookOptions from '../BookOptions';
import { getBookQuestionAvg, getBookQuestionNumbers } from '../../../selectors/book';

import './index.scss';

const BookFolder = ({
  name,
  onToggleOptions,
  isOpened,
  books,
  onDeleteBook,
  onDeleteFolder,
  onEdit,
  id,
  onExpandFolder,
  isExpanded,
}) => {
  const { t } = useTranslation(['book']);
  const history = useHistory();

  const handleNavigateToBookPage = (folderId) => history.push(
    privateRoutes.NEW_BOOK.path(folderId),
  );

  return (
    <div className="BookFolder">
      <div className="BookFolder__header">
        <img src={FolderIcon} alt="folder icon" />
        <p className="BookFolder__title">{name}</p>
      </div>
      <button onClick={onExpandFolder} className={className('BookFolder__expand', 'BookFolder__expand--left', { 'BookFolder__expand--opened': isExpanded })}>
        <BiRightArrow />
      </button>
      <button
        onClick={onToggleOptions}
        className={className('BookFolder__expand', { 'BookFolder__expand--opened': isOpened })}
      >
        <img alt="expand icon" src={ExpandIcon} />
      </button>
      {isOpened && (
        <div className="BookFolder__options">
          <BookOptions
            onDelete={() => onDeleteFolder(id)}
            onEdit={() => onEdit(id)}
            onNavigateToBookPage={() => handleNavigateToBookPage(id)}
          />
        </div>
      )}
      {isExpanded && (
        <ul className="BookFolder__books">
          {books.map((book) => {
            const { total, answered, notAnswered } = getBookQuestionNumbers(book);
            const {
              correctAnswersPercentage,
              incorrectAnswersPercentage,
            } = getBookQuestionAvg(book);

            return (
              <div className="BookFolder__book" key={book.id}>
                <Link to={privateRoutes.SHOW_BOOK.path(id, book.id)}>
                  <div className="BookFolder__book-texts">
                    <p className="BookFolder__book-name">{book.name}</p>
                    <p className="BookFolder__book-statistics">
                      {[
                        t('book:questions', { amount: total }),
                        t('book:questionsAnswered', { amount: answered }),
                        t('book:questionsNotAnswered', { amount: notAnswered })]
                        .join(' - ')}
                    </p>
                  </div>
                </Link>
                <div className="BookFolder__book-pill">
                  <BookProgressBar
                    correctAnswersPercentage={correctAnswersPercentage}
                    incorrectAnswersPercentage={incorrectAnswersPercentage}
                  />
                  <p>{`${correctAnswersPercentage + incorrectAnswersPercentage}%`}</p>
                </div>
                <div className="BookFolder__book-actions">
                  <img src={RemoveIcon} alt="remove" onClick={() => onDeleteBook(book)} />
                </div>
              </div>
            );
          })}
        </ul>
      )}
    </div>
  );
};

BookFolder.propTypes = {
  name: PropTypes.string.isRequired,
  onToggleOptions: PropTypes.func.isRequired,
  isOpened: PropTypes.bool.isRequired,
  books: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
  })).isRequired,
  onDeleteBook: PropTypes.func.isRequired,
  onEdit: PropTypes.func.isRequired,
  id: PropTypes.number.isRequired,
  onDeleteFolder: PropTypes.func.isRequired,
  isExpanded: PropTypes.bool,
  onExpandFolder: PropTypes.func.isRequired,
};

BookFolder.defaultProps = {
  isExpanded: false,
};

export default BookFolder;
