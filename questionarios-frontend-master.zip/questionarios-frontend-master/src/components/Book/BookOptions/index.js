import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';
import { AiFillDelete, AiFillEdit } from 'react-icons/ai';
import { FaBook } from 'react-icons/fa';
import BoxOptions from '../../ui/BoxOptions';

const BookOptions = ({ onDelete, onEdit, onNavigateToBookPage }) => {
  const { t } = useTranslation(['common', 'book']);

  const options = useMemo(() => ([
    {
      icon: AiFillDelete,
      onClick: onDelete,
      text: t('common:delete'),
      focus: false,
    },
    {
      icon: FaBook,
      onClick: onNavigateToBookPage,
      text: t('book:create'),
      focus: false,
    },
    {
      icon: AiFillEdit,
      onClick: onEdit,
      text: t('common:edit'),
      focus: false,
    },
  ]), [onNavigateToBookPage, onDelete, onEdit, t]);

  return <BoxOptions options={options} />;
};

BookOptions.propTypes = {
  onDelete: PropTypes.func.isRequired,
  onEdit: PropTypes.func.isRequired,
  onNavigateToBookPage: PropTypes.func.isRequired,
};

export default BookOptions;
