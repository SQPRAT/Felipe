import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';
import { useTranslation } from 'react-i18next';
import Input from '../../ui/Input';
import Select from '../../ui/Select';

import './index.scss';

const bookFilterPropTypes = {
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]).isRequired,
  onChange: PropTypes.func.isRequired,
};

const BookFilterBoolean = ({ value, onChange }) => (
  <Input variant="BookFilters__filter-radio" checked={Boolean(value)} onChange={() => onChange(!value)} type="radio" />
);

const BookFilterNumber = ({ value, onChange, placeholder }) => (
  <Input variant="BookFilters__filter-number" placeholder={placeholder} value={value} onChange={onChange} type="number" />
);

const BookFilterDate = ({ value, onChange }) => (
  <Input variant="BookFilters__filter-radio" value={value} onChange={onChange} type="date" />
);

const BookFilterSelect = ({
  value, onChange, options, placeholder,
}) => (
  <Select variant="BookFilters__filter-select" value={value} placeholder={placeholder} onChange={onChange} options={options} />
);

BookFilterBoolean.propTypes = bookFilterPropTypes;
BookFilterDate.propTypes = bookFilterPropTypes;
BookFilterNumber.propTypes = {
  ...bookFilterPropTypes,
  placeholder: PropTypes.string.isRequired,
};
BookFilterSelect.propTypes = {
  ...bookFilterPropTypes,
  options: PropTypes.arrayOf(PropTypes.shape({
    value: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
  })).isRequired,
  placeholder: PropTypes.string.isRequired,
};

const bookFiltersTypes = {
  boolean: BookFilterBoolean,
  date: BookFilterDate,
  select: BookFilterSelect,
  number: BookFilterNumber,
};

const selectFilterOptions = {
  type: [
    {
      value: 1,
      label: 'Ciclo de exercícios',
    },
    {
      value: 2,
      label: 'Sistema de questões',
    },
    {
      value: 3,
      label: 'Simulado',
    },
  ],
  questionTypes: [
    {
      value: 1,
      label: 'Verdadeiro e Falso',
    },
    {
      value: 2,
      label: 'Alternativas',
    },
  ],
};

const selectFilterPlaceholders = {
  type: 'Tipo de prova',
  questionTypes: 'Tipos de questão',
};

const numberFilterPlaceholders = {
  year: 'Ano da questão',
};

const BookFilters = ({ filters, title, onSelectFilter }) => {
  const { t } = useTranslation(['book']);

  return (
    <div className="BookFilters">
      <p className="BookFilters__title">{title}</p>
      <ul className="BookFilters__list">
        {filters.map((item) => {
          const handleSelectFilter = (value) => onSelectFilter(item.key, value);

          const CurrentFilter = bookFiltersTypes[item.type];
          const aditionalProps = {
            boolean: {
              onClick: () => handleSelectFilter(!item.value),
            },
            select: {
              options: selectFilterOptions[item.key],
              placeholder: selectFilterPlaceholders[item.key],
            },
            date: {},
            number: {
              placeholder: numberFilterPlaceholders[item.key],
            },
          };

          const currentFilterAditionalProps = aditionalProps[item.type];

          return (
            <li
              className={
                className('BookFilters__filter', {
                  'BookFilters__filter--date': item.type === 'date',
                })
              }
              key={item.key}
              {...currentFilterAditionalProps}
            >
              <CurrentFilter
                {...currentFilterAditionalProps}
                value={item.value}
                onChange={handleSelectFilter}
              />
              {(item.type !== 'select' && item.type !== 'number') && <p className="BookFilters__filter-name">{t(`book:filters.${item.key}`)}</p>}
            </li>
          );
        })}
      </ul>
    </div>
  );
};

BookFilters.propTypes = {
  title: PropTypes.string.isRequired,
  filters: PropTypes.arrayOf(PropTypes.shape({
    key: PropTypes.string.isRequired,
    value: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]).isRequired,
  })).isRequired,
  onSelectFilter: PropTypes.func.isRequired,
};

export default BookFilters;
