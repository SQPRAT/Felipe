import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';

import './index.scss';

const BookMenuPage = ({ pages, onSelectPage, selectedPage }) => (
  <div className="BookMenuPage">
    {Array(pages).fill({}).map((_, index) => ({ key: index, number: index + 1 })).map((item) => (
      <button
        className={className('BookMenuPage__number', { 'BookMenuPage__number--selected': selectedPage === item.key })}
        onClick={() => onSelectPage(item.key)}
        key={item.key}
      >
        {item.number}
      </button>
    ))}
  </div>
);

BookMenuPage.propTypes = {
  pages: PropTypes.number.isRequired,
  onSelectPage: PropTypes.func.isRequired,
  selectedPage: PropTypes.number.isRequired,
};

export default BookMenuPage;
