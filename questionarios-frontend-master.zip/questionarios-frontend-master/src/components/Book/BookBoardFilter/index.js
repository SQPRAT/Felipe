import React from 'react';
import PropTypes from 'prop-types';

import Input from '../../ui/Input';

import './index.scss';

const BookBoardFilter = ({ boards, onToggleBoard }) => (
  <ul className="BookBoardFilter">
    {boards.map((board) => (
      <li className="BookBoardFilter__board" key={board.key} onClick={() => onToggleBoard(board)}>
        <Input variant="BookBoardFilter__board-input" checked={board.checked} onChange={() => onToggleBoard(board)} type="radio" />
        <p className="BookBoardFilter__board-label">{board.label}</p>
      </li>
    ))}
  </ul>
);

BookBoardFilter.propTypes = {
  boards: PropTypes.arrayOf(PropTypes.shape({
    key: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    checked: PropTypes.bool.isRequired,
  })),
  onToggleBoard: PropTypes.func.isRequired,
};

BookBoardFilter.defaultProps = {
  boards: [],
};

export default BookBoardFilter;
