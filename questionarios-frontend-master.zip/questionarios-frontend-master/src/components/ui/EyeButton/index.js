import React from 'react';
import PropTypes from 'prop-types';
import { AiOutlineEye } from 'react-icons/ai';
import OpenedEyeIcon from '../../../static/images/icons/closed-eye.svg';

import './index.scss';

const EyeButton = ({ isOpened, onClick }) => (isOpened ? (
  <img onClick={() => onClick(false)} className="EyeButton" alt="Olho" src={OpenedEyeIcon} />
) : (
  <AiOutlineEye onClick={() => onClick(true)} className="EyeButton" />
));

EyeButton.propTypes = {
  isOpened: PropTypes.bool.isRequired,
  onClick: PropTypes.func.isRequired,
};

export default EyeButton;
