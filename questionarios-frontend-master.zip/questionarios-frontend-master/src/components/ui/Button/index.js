import React from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';

import './index.scss';

const Button = ({
  children,
  variant,
  type,
  onClick,
}) => (
  <button className={classNames('Button', variant)} type={type} onClick={onClick}>
    {children}
  </button>
);

Button.propTypes = {
  children: PropTypes.node.isRequired,
  variant: PropTypes.string,
  type: PropTypes.oneOf(['button', 'submit']),
  onClick: PropTypes.func.isRequired,
};

Button.defaultProps = {
  variant: '',
  type: 'button',
};

export default Button;
