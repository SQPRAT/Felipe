import React from 'react';
import ReactPaginate from 'react-paginate';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';

import './index.scss';

const Paginate = ({ onChange, amountOfPages }) => {
  const { t } = useTranslation('common');

  const handlePaginate = ({ selected }) => onChange(selected);

  return (
    <div className="Paginate">
      <ReactPaginate onPageChange={handlePaginate} pageCount={amountOfPages} nextLabel={t('next')} previousLabel={t('previous')} />
    </div>
  );
};

Paginate.propTypes = {
  onChange: PropTypes.func.isRequired,
  amountOfPages: PropTypes.number.isRequired,
};

export default Paginate;
