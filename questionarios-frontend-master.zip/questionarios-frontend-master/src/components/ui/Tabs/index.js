import React, { useState } from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';

import './index.scss';

const Tabs = ({
  childrens,
}) => {
  const [selectedTabIndex, setSelectedTabIndex] = useState(0);

  return (
    <div className="Tabs">
      <ul className="Tabs__titles">
        {childrens.map((item, index) => (
          <li
            className={
              className('Tabs__title', { 'Tabs__title--selected': index === selectedTabIndex })
            }
            onClick={() => setSelectedTabIndex(index)}
            key={item.title}
          >
            {item.title}
          </li>
        ))}
      </ul>
      <div className="Tabs__content">
        {childrens[selectedTabIndex]?.content ?? null}
      </div>
    </div>
  );
};

Tabs.propTypes = {
  childrens: PropTypes.arrayOf(PropTypes.shape({
    content: PropTypes.node.isRequired,
    title: PropTypes.string.isRequired,
  })).isRequired,
};

export default Tabs;
