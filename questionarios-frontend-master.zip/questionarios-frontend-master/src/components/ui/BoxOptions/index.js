import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';

import './index.scss';

const BoxOptions = ({ options }) => (
  <ul className="BoxOptions">
    {options.map((option) => (
      <li
        onClick={option.onClick}
        className={className('BoxOptions__option', { 'BoxOptions__option--focus': option.focus })}
        key={option.text}
      >
        <option.icon className="BoxOptions__icon" />
        <p className="BoxOptions__text">{option.text}</p>
      </li>
    ))}
  </ul>
);

BoxOptions.propTypes = {
  options: PropTypes.arrayOf(PropTypes.shape({
    icon: PropTypes.elementType.isRequired,
    onClick: PropTypes.func.isRequired,
    text: PropTypes.string.isRequired,
    focus: PropTypes.bool.isRequired,
  })),
};

BoxOptions.defaultProps = {
  options: [],
};

export default BoxOptions;
