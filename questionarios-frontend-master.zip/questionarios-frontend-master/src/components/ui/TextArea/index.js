import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

import './index.scss';

const TextArea = ({
  onChange,
  value,
  required,
  variant,
  placeholder,
}) => {
  const handleChange = (e) => {
    onChange(e.target.value);
  };

  return (
    <textarea placeholder={placeholder} className={classNames('TextArea', variant)} required={required} value={value} onChange={handleChange} />
  );
};

TextArea.propTypes = {
  onChange: PropTypes.func.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  required: PropTypes.bool,
  variant: PropTypes.string,
  placeholder: PropTypes.string,
};

TextArea.defaultProps = {
  required: false,
  variant: '',
  placeholder: '',
};

export default TextArea;
