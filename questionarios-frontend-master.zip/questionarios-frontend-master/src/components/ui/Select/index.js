import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';

import './index.scss';

const Select = ({
  options,
  variant,
  value,
  required,
  placeholder,
  onChange,
}) => (
  <select onChange={(e) => onChange(e.target.value)} value={value} className={className('Select', variant)} required={required}>
    {placeholder && (
      <option value="">{placeholder}</option>
    )}
    {options.map((option) => (
      <option key={option.value} value={option.value}>{option.label}</option>
    ))}
  </select>
);

Select.propTypes = {
  variant: PropTypes.string,
  placeholder: PropTypes.string,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  onChange: PropTypes.func.isRequired,
  required: PropTypes.bool,
  options: PropTypes.arrayOf(PropTypes.shape({
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    label: PropTypes.string.isRequired,
  })).isRequired,
};

Select.defaultProps = {
  variant: '',
  placeholder: '',
  required: false,
};

export default Select;
