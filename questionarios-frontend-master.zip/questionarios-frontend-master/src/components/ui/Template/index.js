import React from 'react';
import PropTypes from 'prop-types';
import Header from '../Header';

import './index.scss';

const Template = ({ children }) => (
  <div className="Template">
    <Header />
    {children}
  </div>
);

Template.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Template;
