import React from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import LogoImage from '../../../static/images/logo.png';
import WhiteLogoImage from '../../../static/images/logo-white.png';

import './index.scss';

const Logo = ({ variant, white }) => (
  <figure className="Logo">
    <img src={white ? WhiteLogoImage : LogoImage} alt="Logo" className={classNames('Logo__image', variant)} />
  </figure>
);

Logo.propTypes = {
  variant: PropTypes.string,
  white: PropTypes.bool,
};

Logo.defaultProps = {
  variant: '',
  white: false,
};

export default Logo;
