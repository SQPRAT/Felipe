import React, { useState, Component } from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';
import { FaCheck } from 'react-icons/fa';
import { AiOutlinePlus, AiOutlineMinus } from 'react-icons/ai';
import SortableTree from 'react-sortable-tree';

import 'react-sortable-tree/style.css';
import './index.scss';

const TreeNode = ({
  name,
  childrens,
  onClick,
  payload,
  isChecked,
  onRightClick,
  id,
  onToggleExpand,
  expandedItems,
}) => (
  <div className="TreeNode">
    {childrens?.length ? (
      <button className="TreeNode__expand" onClick={(e) => onToggleExpand(e, id)}>
        {expandedItems?.includes(id) ? (
          <AiOutlineMinus />
        ) : (
          <AiOutlinePlus />
        )}
      </button>
    ) : null}
    <p
      className={className('TreeNode__name', { 'TreeNode__name--checked': isChecked })}
      onClick={() => onClick(payload)}
      onContextMenu={(e) => onRightClick(e, { id, name })}
    >
      {name}
      {isChecked && <FaCheck className="TreeNode__check" />}
    </p>
    <div className="TreeNode__childrens-wrapper">
      <div
        className={
          className('TreeNode__childrens', { 'TreeNode__childrens--show': expandedItems?.includes(id) })
        }
      >
        {childrens.map((node) => (
          <TreeNode
            onClick={onClick}
            payload={node}
            key={`${node.name}-${node.id}`}
            name={node.name}
            id={node.id}
            onRightClick={onRightClick}
            childrens={node.childrens}
            isChecked={node?.isChecked}
            onToggleExpand={onToggleExpand}
            expandedItems={expandedItems}
          />
        ))}
      </div>
    </div>
  </div>
);

class DraggableTree extends Component {
  static formatItem(item, expandedItems) {
    return {
      id: item.id,
      title: item.name,
      expanded: expandedItems.includes(item.id),
      parentId: item.parentBranch,
      children: item.childrens.map((i) => DraggableTree.formatItem(i, expandedItems)),
    };
  }

  static formatTree(items, expandedItems) {
    return items.map((item) => DraggableTree.formatItem(item, expandedItems));
  }

  render() {
    const {
      items,
      expandedItems,
      onToggleItem,
      onRightClick,
      onUpdate,
      canDrag,
    } = this.props;
    const formattedItems = DraggableTree.formatTree(items, expandedItems);

    return (
      <div style={{ height: '70vh' }}>
        <SortableTree
          treeData={formattedItems}
          getNodeKey={({ node }) => node.id}
          onChange={() => {}}
          onMoveNode={onUpdate}
          canDrag={canDrag}
          generateNodeProps={(rowInfo) => {
            const itemId = rowInfo?.node?.id;
            const itemName = rowInfo?.node?.name;

            return {
              onClick: (e) => onToggleItem(e, itemId),
              onContextMenu: (e) => onRightClick(e, { id: itemId, name: itemName }),
            };
          }}
        />
      </div>
    );
  }
}

const Tree = ({
  items,
  onClick,
  onRightClick,
  isDragAndDropEnabled,
  onUpdate,
  canDrag,
}) => {
  const [expandedItems, setExpandedItems] = useState([]);

  const handleToggleExpand = (e, itemId) => {
    e.stopPropagation();
    e.preventDefault();

    setExpandedItems((prevItems) => (
      prevItems.includes(itemId)
        ? prevItems.filter((item) => item !== itemId)
        : [...prevItems, itemId]
    ));
  };

  if (isDragAndDropEnabled) {
    return (
      <DraggableTree
        onToggleItem={handleToggleExpand}
        expandedItems={expandedItems}
        items={items}
        onRightClick={onRightClick}
        onUpdate={onUpdate}
        canDrag={canDrag}
      />
    );
  }

  return (
    <div className="Tree">
      {items.map((itemNode) => (
        <TreeNode
          key={`${itemNode.name}-${itemNode.id}`}
          payload={itemNode}
          name={itemNode.name}
          onClick={onClick}
          id={itemNode.id}
          onRightClick={onRightClick}
          isChecked={itemNode?.isChecked}
          childrens={itemNode.childrens}
          expandedItems={expandedItems}
          onToggleExpand={handleToggleExpand}
        />
      ))}
    </div>
  );
};

const treeNodePropType = PropTypes.shape({
  name: PropTypes.string.isRequired,
  childrens: PropTypes.arrayOf(PropTypes.object),
});

TreeNode.propTypes = {
  name: PropTypes.string.isRequired,
  childrens: PropTypes.arrayOf(PropTypes.object),
  onClick: PropTypes.func.isRequired,
  onRightClick: PropTypes.func,
  onToggleExpand: PropTypes.func,
  id: PropTypes.number.isRequired,
  // eslint-disable-next-line react/forbid-prop-types
  payload: PropTypes.object.isRequired,
  isChecked: PropTypes.bool,
  expandedItems: PropTypes.arrayOf(PropTypes.number.isRequired).isRequired,
};

TreeNode.defaultProps = {
  childrens: [],
  isChecked: false,
  onRightClick: () => {},
  onToggleExpand: () => {},
};

Tree.propTypes = {
  items: PropTypes.arrayOf(treeNodePropType),
  onClick: PropTypes.func.isRequired,
  isDragAndDropEnabled: PropTypes.bool,
  onRightClick: PropTypes.func,
  onUpdate: PropTypes.func,
  canDrag: PropTypes.bool,
};

DraggableTree.propTypes = {
  items: PropTypes.arrayOf(treeNodePropType),
  expandedItems: PropTypes.arrayOf(PropTypes.number.isRequired).isRequired,
  onToggleItem: PropTypes.func.isRequired,
  onRightClick: PropTypes.func.isRequired,
  onUpdate: PropTypes.func.isRequired,
  canDrag: PropTypes.bool.isRequired,
};

Tree.defaultProps = {
  items: [],
  onRightClick: () => {},
  isDragAndDropEnabled: false,
  onUpdate: () => {},
  canDrag: true,
};

DraggableTree.defaultProps = {
  items: [],
};

export default Tree;
