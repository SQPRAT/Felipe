import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';
import Input from '../Input';

import './index.scss';

const Autocomplete = ({
  value,
  options,
  onSelect,
  onChange,
  onFocus,
  onBlur,
  placeholder,
  showOptions,
  variant,
}) => (
  <div className={className('Autocomplete', variant)}>
    <Input onFocus={onFocus} onBlur={onBlur} variant="Autocomplete__input" value={value} onChange={onChange} type="search" placeholder={placeholder} />
    {options.length > 0 && showOptions && (
      <ul className="Autocomplete__options">
        {options.map((option) => (
          <li key={option.label} className="Autocomplete__option" onClick={() => onSelect(option)}>
            {option?.label ?? ''}
          </li>
        ))}
      </ul>
    )}
  </div>
);

Autocomplete.propTypes = {
  value: PropTypes.string.isRequired,
  showOptions: PropTypes.bool,
  variant: PropTypes.string.isRequired,
  options: PropTypes.arrayOf(PropTypes.shape({
    label: PropTypes.string.isRequired,
  })).isRequired,
  onSelect: PropTypes.func.isRequired,
  placeholder: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  onBlur: PropTypes.func.isRequired,
  onFocus: PropTypes.func.isRequired,
};

Autocomplete.defaultProps = {
  showOptions: false,
};

export default Autocomplete;
