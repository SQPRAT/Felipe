import React, { useCallback, useEffect, useState } from 'react';
import { useHistory, Link } from 'react-router-dom';
import classNames from 'classnames';
import { FaPowerOff } from 'react-icons/fa';
import DefaultUserImage from '../../../static/images/default-user.png';
import DownArrow from '../../../static/images/icons/down-arrow.svg';
import Logo from '../Logo';
import Menu from '../Menu';
import useUser from '../../../hooks/useUser';
import useService from '../../../hooks/useService';
import { privateRoutes } from '../../../config/constants';

import './index.scss';

const Header = () => {
  const user = useUser();
  const LocalStorage = useService('LocalStorage');
  const [isOpened, toggle] = useState(false);
  const history = useHistory();

  const handleLogout = () => {
    LocalStorage.clear();
    history.push('/');
  };

  const handleCloseOptions = useCallback(() => {
    if (isOpened) toggle(false);
  }, [isOpened]);

  useEffect(() => {
    window.addEventListener('click', handleCloseOptions);

    return () => {
      window.removeEventListener('click', handleCloseOptions);
    };
  }, [handleCloseOptions]);

  return (
    <header className="Header">
      {isOpened && (
        <ul className="Header__options">
          <li className="Header__option" onClick={handleLogout}>Sair</li>
          <li className="Header__option" onClick={() => history.push(privateRoutes.EDIT_PASSWORD.path)}>Editar senha</li>
        </ul>
      )}
      <div className="Header__logo">
        <Link to={privateRoutes.HOME.path}>
          <Logo white />
        </Link>
      </div>
      <div className="Header__main" />
      <div className="Header__user-info">
        <figure className="Header__user-info-image">
          <img alt={user?.email ?? ''} src={DefaultUserImage} />
        </figure>
        <div className="Header__user-info-texts">
          <p className="Header__user-info-email">{user?.email ?? ''}</p>
        </div>
      </div>
      <img onClick={() => toggle(!isOpened)} className="Header__down-arrow" src={DownArrow} alt="down-arrow" />
      <button
        onClick={() => toggle(!isOpened)}
        className={classNames('Header__button', {
          'Header__button--opened': isOpened,
        })}
      />
      <button onClick={handleLogout} className="Header__logout-button">
        <FaPowerOff />
      </button>
      <figure className="Header__user-image">
        <img alt={user?.email ?? ''} src={DefaultUserImage} />
      </figure>
      <div className={classNames('Header__mobile-menu', {
        'Header__mobile-menu--opened': isOpened,
      })}
      >
        <div className="Header__mobile-menu-header">
          <Link to={privateRoutes.HOME.path}>
            <Logo white />
          </Link>
          <p className="Header__mobile-menu-email">{user?.email ?? ''}</p>
        </div>
        <div className="Header__mobile-menu-links">
          <Menu />
        </div>
      </div>
    </header>
  );
};

export default Header;
