import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';
import Menu from '../Menu';
import TestSmallList from '../../Test/TestSmallList';
import useStatus from '../../../hooks/useStatus';

import './index.scss';

const Page = ({
  children,
  showMenu,
  title,
  showStatistics,
  variant,
}) => {
  const status = useStatus();

  return (
    <div className={className('Page', variant)}>
      {showMenu && (
        <div className="Page__menu">
          <Menu />
        </div>
      )}
      <div className="Page__body">
        <div className="Page__wrapper">
          {typeof title === 'string' ? (
            <p className="Page__title">{title}</p>
          ) : title}
          {children}
        </div>
        {showStatistics && (
          <div className="Page__statistics">
            <div className="Page__statistics-tests">
              <TestSmallList
                tests={status?.tests ?? []}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

Page.propTypes = {
  children: PropTypes.node.isRequired,
  variant: PropTypes.string,
  showMenu: PropTypes.bool,
  showStatistics: PropTypes.bool,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
};

Page.defaultProps = {
  showMenu: true,
  showStatistics: false,
  title: '',
  variant: null,
};

export default Page;
