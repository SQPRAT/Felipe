import React from 'react';
import { Link } from 'react-router-dom';
import useUser from '../../../hooks/useUser';
import { getMenuLinks } from '../../../models/user';

import './index.scss';

const Menu = () => {
  const user = useUser();
  const menuLinks = getMenuLinks(user);

  return (
    <ul className="Menu">
      {menuLinks.map(({ title, links, icon: Icon }) => (
        <li className="Menu__topic" key={title}>
          <p className="Menu__topic-title">
            <Icon className="Menu__topic-icon" />
            {title}
          </p>
          <ul className="Menu__topic-items">
            {links.map((link) => (
              <li className="Menu__topic-item" key={link.href}>
                <Link to={link.href}>
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </li>
      ))}
    </ul>
  );
};

export default Menu;
