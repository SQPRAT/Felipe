import React from 'react';
import className from 'classnames';
import PropTypes from 'prop-types';

import './index.scss';

const Input = ({
  disabled,
  variant,
  type,
  placeholder,
  value,
  onChange,
  required,
  checked,
  ...rest
}) => {
  const propsTypes = {
    text: {
      placeholder,
      onChange: (e) => onChange(e.target.value),
      value,
    },
    search: {
      placeholder,
      onChange: (e) => onChange(e.target.value),
      value,
    },
    date: {
      placeholder,
      onChange: (e) => onChange(e.target.value),
      value,
    },
    email: {
      placeholder,
      onChange: (e) => onChange(e.target.value),
      value,
    },
    password: {
      placeholder,
      onChange: (e) => onChange(e.target.value),
      value,
    },
    number: {
      placeholder,
      onChange: (e) => onChange(e.target.value ? Number(e.target.value) : ''),
      value,
    },
    radio: {
      onClick: onChange,
    },
  };

  return (
    <input
      {...propsTypes[type]}
      disabled={disabled}
      required={required}
      type={type}
      className={className('Input', variant)}
      checked={checked}
      {...rest}
    />
  );
};

Input.propTypes = {
  variant: PropTypes.string,
  type: PropTypes.oneOf(['text', 'email', 'password', 'number', 'radio', 'search', 'date']),
  placeholder: PropTypes.string,
  value: PropTypes.oneOfType(PropTypes.string, PropTypes.number),
  onChange: PropTypes.func,
  required: PropTypes.bool,
  checked: PropTypes.bool,
  disabled: PropTypes.bool,
};

Input.defaultProps = {
  variant: '',
  type: 'text',
  value: '',
  onChange: () => {},
  placeholder: '',
  required: false,
  disabled: false,
  checked: false,
};

export default Input;
