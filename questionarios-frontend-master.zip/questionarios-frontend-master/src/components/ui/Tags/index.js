import React from 'react';
import PropTypes from 'prop-types';
import { useTranslation } from 'react-i18next';
import { IoMdClose } from 'react-icons/io';
import Autocomplete from '../Autocomplete';

import './index.scss';

const Tags = ({
  keyword,
  onChange,
  availableTags,
  onRemove,
  tags,
  onSelect,
}) => {
  const { t } = useTranslation(['book']);

  return (
    <div className="Tags">
      <div className="Tags__header">
        <Autocomplete
          value={keyword}
          options={availableTags}
          onSelect={onSelect}
          onChange={onChange}
          placeholder={t('book:searchBoard')}
          showOptions
          variant="Tags__input"
        />
      </div>
      <ul className="Tags__list">
        {tags.map((tag) => (
          <li className="Tags__tag" key={tag.key}>
            {tag.label}
            <IoMdClose onClick={() => onRemove(tag)} className="Tags__close-tag" />
          </li>
        ))}
      </ul>
    </div>
  );
};

Tags.propTypes = {
  keyword: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  onSelect: PropTypes.func.isRequired,
  availableTags: PropTypes.arrayOf(PropTypes.shape({
    key: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
  })).isRequired,
  tags: PropTypes.arrayOf(PropTypes.shape({
    key: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
  })).isRequired,
  onRemove: PropTypes.func.isRequired,
};

export default Tags;
