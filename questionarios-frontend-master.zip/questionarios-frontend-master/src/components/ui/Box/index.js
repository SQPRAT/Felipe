import React from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';

import './index.scss';

const Box = ({
  children,
  variant,
  flexDirection,
  alignItems,
  justifyContent,
}) => (
  <div className={classNames('Box', variant)}>
    <div className={classNames(
      'Box__wrapper',
      `Box__wrapper--${flexDirection}-direction`,
      `Box__wrapper--${alignItems}-alignment`,
      `Box__wrapper--${justifyContent}-justify`,
    )}
    >
      {children}
    </div>
  </div>
);

Box.propTypes = {
  children: PropTypes.node,
  variant: PropTypes.string,
  flexDirection: PropTypes.oneOf(['column', 'row']),
  alignItems: PropTypes.oneOf(['center']),
  justifyContent: PropTypes.oneOf(['center', 'space-between']),
};

Box.defaultProps = {
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  variant: '',
  children: null,
};

export default Box;
