import React from 'react';
import ReactLoading from 'react-loading';

const Loading = () => (
  <ReactLoading
    type="bubbles"
    color="#333"
  />
);

export default Loading;
