import React from 'react';
import PropTypes from 'prop-types';
import className from 'classnames';
import ReactSummernote from 'react-summernote';
import parse from 'html-react-parser';

import 'react-summernote/dist/react-summernote.css';
import 'bootstrap/js/dist/modal';
import 'bootstrap/js/dist/dropdown';
import 'bootstrap/js/dist/tooltip';
import 'bootstrap/dist/css/bootstrap.css';
import './index.scss';

const TextEditor = ({
  value,
  onChange,
  placeholder,
  variant,
}) => {
  const handleUpdateImage = (file) => {
    const reader = new FileReader();

    reader.onloadend = () => {
      onChange(`
        ${value}
        <img src="${reader.result}" />
      `);
    };

    reader.readAsDataURL(file[0]);
  };

  const handleChangeValue = (newValue) => {
    const NULL_ALLOWED_VALUES = ['<p><br></p>'];

    if (NULL_ALLOWED_VALUES.some((v) => newValue === v)) return onChange('');

    return onChange(newValue);
  };

  return (
    <div className={className(variant, 'TextEditor')}>
      <span className="TextEditor__label">{placeholder}</span>
      <ReactSummernote
        onChange={handleChangeValue}
        onImageUpload={handleUpdateImage}
        value={value}
        options={{
          toolbar: [
            ['insert', ['link', 'picture']],
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['font', ['strikethrough', 'superscript', 'subscript', 'bold', 'underline', 'clear']],
            ['fontsize', ['fontsize']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['height', ['height']],
          ],
        }}
      >
        {parse(value)}
      </ReactSummernote>
    </div>
  );
};

TextEditor.defaultProps = {
  placeholder: '',
  value: '',
};

TextEditor.propTypes = {
  value: PropTypes.string,
  variant: PropTypes.string.isRequired,
  placeholder: PropTypes.string,
  onChange: PropTypes.func.isRequired,
};

export default TextEditor;
