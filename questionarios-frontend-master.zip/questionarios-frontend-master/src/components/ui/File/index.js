import React from 'react';
import PropTypes from 'prop-types';
import { AiFillFileImage } from 'react-icons/ai';
import { IoIosDocument } from 'react-icons/io';

import Input from '../Input';

import './index.scss';

const extensionIcons = {
  png: AiFillFileImage,
  jpeg: AiFillFileImage,
  jpg: AiFillFileImage,
  pdf: IoIosDocument,
};

const File = ({
  onUpload,
  files,
  onRemove,
  onChangeDescription,
}) => (
  <div className="File">
    <div className="File__input">
      <input onChange={onUpload} name="file" type="file" className="File__field" />
    </div>
    <ul className="File__files">
      {files.map((file, index) => {
        const Icon = extensionIcons[file.extension] || IoIosDocument;

        return (
          <li className="File__file" key={file.name}>
            <Icon className="File__file-icon" />
            <p className="File__file-name">{file.name}</p>
            <button className="File__file-remove" onClick={() => onRemove(file)}>X</button>
            <Input
              variant="File__description"
              value={file.description}
              onChange={(newValue) => onChangeDescription(newValue, index)}
              placeholder="Descrição..."
            />
          </li>
        );
      })}
    </ul>
  </div>
);

File.propTypes = {
  onRemove: PropTypes.func.isRequired,
  onUpload: PropTypes.func.isRequired,
  onChangeDescription: PropTypes.func.isRequired,
  files: PropTypes.arrayOf(PropTypes.shape({
    name: PropTypes.string.isRequired,
    extension: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
  })).isRequired,
};

export default File;
