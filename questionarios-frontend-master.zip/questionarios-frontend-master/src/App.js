import React from 'react';
import $ from 'jquery';
import MainContainer from './containers/Main';
import withI18Next from './wrappers/withI18Next';
import Routes from './routes';
import 'bootstrap';

window.jQuery = $;
window.$ = $;

const App = () => (
  <MainContainer>
    <Routes />
  </MainContainer>
);

export default withI18Next(App);
