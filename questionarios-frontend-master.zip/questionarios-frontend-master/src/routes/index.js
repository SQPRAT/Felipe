import React from 'react';
import { Switch, BrowserRouter } from 'react-router-dom';

import PublicRoute from './PublicRoute';
import PrivateRoute from './PrivateRoute';

import Login from '../pages/public/Login';

import NewUser from '../pages/private/Users/New';
import ListUsers from '../pages/private/Users/List';
import EditUser from '../pages/private/Users/Edit';
import NewTest from '../pages/private/Tests/New';
import ListTests from '../pages/private/Tests/List';
import EditTest from '../pages/private/Tests/Edit';
import NewQuestion from '../pages/private/Questions/New';
import ListQuestions from '../pages/private/Questions/List';
import EditQuestion from '../pages/private/Questions/Edit';
import ViewQuestion from '../pages/private/Questions/View';
import EditImportQuestion from '../pages/private/Questions/EditImport';
import NewBook from '../pages/private/Books/New';
import ListBooks from '../pages/private/Books/List';
import ShowBook from '../pages/private/Books/Show';
import Tags from '../pages/private/Tags';
import Wizzard from '../pages/private/Tests/Wizzard';
import ShowTest from '../pages/private/Tests/Show';
import TestTypes from '../pages/private/Tests/Types';
import Accesses from '../pages/private/Users/Accesses';
import EditPassword from '../pages/private/Users/EditPassword';

import { publicRoutes, privateRoutes } from '../config/constants';
import ImportWizzardPage from '../pages/private/Tests/ImportWizzard';

const Routes = () => (
  <BrowserRouter>
    <Switch>
      <PublicRoute exact path="/" component={Login} />
      <PublicRoute exact path={publicRoutes.LOGIN} component={Login} />

      <PrivateRoute
        exact
        path={privateRoutes.HOME.path}
        component={ListBooks}
        roles={privateRoutes.HOME.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.NEW_USER.path}
        component={NewUser}
        roles={privateRoutes.NEW_USER.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.LIST_USERS.path}
        component={ListUsers}
        roles={privateRoutes.LIST_USERS.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.EDIT_USER.path(':userId')}
        component={EditUser}
        roles={privateRoutes.EDIT_USER.roles}
      />

      <PrivateRoute
        exact
        path={privateRoutes.NEW_TEST.path}
        component={NewTest}
        roles={privateRoutes.NEW_TEST.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.LIST_TESTS.path}
        component={ListTests}
        roles={privateRoutes.LIST_TESTS.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.SHOW_TEST.path(':testId')}
        component={ShowTest}
        roles={privateRoutes.SHOW_TEST.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.EDIT_TEST.path(':testId')}
        component={EditTest}
        roles={privateRoutes.EDIT_TEST.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.TEST_WIZZARD.path(':testId')}
        component={Wizzard}
        roles={privateRoutes.TEST_WIZZARD.roles}
      />

      <PrivateRoute
        exact
        path={privateRoutes.NEW_QUESTION.path}
        component={NewQuestion}
        roles={privateRoutes.NEW_QUESTION.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.LIST_QUESTIONS.path(':testId')}
        component={ListQuestions}
        roles={privateRoutes.LIST_QUESTIONS.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.IMPORT_WIZZARD.path(':testId')}
        component={ImportWizzardPage}
        roles={privateRoutes.IMPORT_WIZZARD.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.EDIT_QUESTION.path(':testId', ':questionId')}
        component={EditQuestion}
        roles={privateRoutes.EDIT_QUESTION.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.VIEW_QUESTION.path(':questionId')}
        component={ViewQuestion}
        roles={privateRoutes.VIEW_QUESTION.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.EDIT_IMPORT_QUESTION.path(':testId', ':position')}
        component={EditImportQuestion}
        roles={privateRoutes.EDIT_IMPORT_QUESTION.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.EDIT_QUESTION_DIRECTLY.path(':questionId')}
        component={EditQuestion}
        roles={privateRoutes.EDIT_QUESTION_DIRECTLY.roles}
      />

      <PrivateRoute
        exact
        path={privateRoutes.NEW_BOOK.path(':folderId')}
        component={NewBook}
        roles={privateRoutes.NEW_BOOK.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.LIST_BOOKS.path}
        component={ListBooks}
        roles={privateRoutes.LIST_BOOKS.roles}
      />
      <PrivateRoute
        exact
        path={privateRoutes.SHOW_BOOK.path(':folderId', ':bookId')}
        component={ShowBook}
        roles={privateRoutes.SHOW_BOOK.roles}
      />

      <PrivateRoute
        exact
        path={privateRoutes.TAGS.path}
        component={Tags}
        roles={privateRoutes.TAGS.roles}
      />

      <PrivateRoute
        exact
        path={privateRoutes.LIST_ACCESSES.path}
        component={Accesses}
        roles={privateRoutes.LIST_ACCESSES.roles}
      />

      <PrivateRoute
        exact
        path={privateRoutes.TEST_TYPES.path}
        component={TestTypes}
        roles={privateRoutes.TEST_TYPES.roles}
      />

      <PrivateRoute
        exact
        path={privateRoutes.EDIT_PASSWORD.path}
        component={EditPassword}
        roles={privateRoutes.EDIT_PASSWORD.roles}
      />
    </Switch>
  </BrowserRouter>
);

export default Routes;
