import React from 'react';
import PropTypes from 'prop-types';
import { Redirect, Route } from 'react-router-dom';
import useModel from '../hooks/useModel';
import useUser from '../hooks/useUser';

const PublicRoute = ({ component: Component, ...rest }) => {
  const UserModel = useModel('user');
  const user = useUser();
  const renderChildren = (props) => (!UserModel.isAuthenticated()
    ? <Component {...props} />
    : <Redirect to={UserModel.getMainRoute(user)} />
  );

  return (<Route {...rest} render={renderChildren} />);
};

PublicRoute.propTypes = {
  component: PropTypes.func.isRequired,
};

export default PublicRoute;
