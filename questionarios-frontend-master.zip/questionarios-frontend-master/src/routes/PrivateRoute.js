import React from 'react';
import PropTypes from 'prop-types';
import { Redirect, Route } from 'react-router-dom';
import withTemplate from '../wrappers/withTemplate';
import withAdminContext from '../wrappers/withAdminContext';
import useModel from '../hooks/useModel';
import useUser from '../hooks/useUser';
import { isAllowed } from '../selectors/user';

const PrivateRoute = ({ roles, component: Component, ...rest }) => {
  const UserModel = useModel('user');
  const user = useUser();
  const renderChildren = (props) => ((UserModel.isAuthenticated() && isAllowed(user, roles))
    ? withTemplate(<Component {...props} />)
    : <Redirect to={UserModel.getMainRoute(user)} />
  );

  return (<Route {...rest} render={withAdminContext(renderChildren)} />);
};

PrivateRoute.propTypes = {
  component: PropTypes.func.isRequired,
  roles: PropTypes.arrayOf(PropTypes.number.isRequired).isRequired,
};

export default PrivateRoute;
