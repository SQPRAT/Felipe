import * as Api from './Api';
import * as Alert from './Alert';
import * as LocalStorage from './LocalStorage';

export default {
  Api,
  Alert,
  LocalStorage,
};
