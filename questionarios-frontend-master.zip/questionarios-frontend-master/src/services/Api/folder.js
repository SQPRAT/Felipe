import RootAPI from './root';
import i18n from '../../config/i18n';

export const remove = async (userId, id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.delete(`/user/${userId}/folder/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const update = async (userId, id, folder) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.patch(`/user/${userId}/folder/${id}`, folder);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const register = async (userId, folder) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.post(`/user/${userId}/folder/`, folder);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};
