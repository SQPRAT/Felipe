import RootAPI from './root';
import i18n from '../../config/i18n';

export const login = async (email, password) => {
  try {
    const { data } = await RootAPI.post('/auth', { email, password });

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const recoverPassword = async (email) => {
  try {
    const { data } = await RootAPI.post('/recover-password', { email });

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const register = async (user) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.post('/user', user);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const search = async (page) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/user?page=${page}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const accesses = async (keyword, page) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/user/accesses?${keyword && `keyword=${keyword}`}${page && `page=${page}`}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const statistics = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/user/${id}/statistics`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const remove = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.delete(`/user/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const find = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/user/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const update = async (id, user) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.patch(`/user/${id}`, user);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};
