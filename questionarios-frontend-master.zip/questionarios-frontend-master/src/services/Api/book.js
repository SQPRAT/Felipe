import RootAPI from './root';
import i18n from '../../config/i18n';

export const searchBoards = async (keyword) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/test/boards?keyword=${keyword}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const getFilters = async () => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get('/book-filters');

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const register = async (userId, folderId, book) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.post(`/user/${userId}/folder/${folderId}/book`, book);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const all = async (userId) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/user/${userId}/folder-with-books`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const remove = async (userId, folderId, id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.delete(`/user/${userId}/folder/${folderId}/book/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const find = async (userId, folderId, id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/user/${userId}/folder/${folderId}/book/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const check = async (userId, folderId, id, answers) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.put(`/user/${userId}/folder/${folderId}/book/${id}`, answers);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};
