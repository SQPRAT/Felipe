import RootAPI from './root';
import i18n from '../../config/i18n';

export const search = async (params) => {
  try {
    const serializedParams = RootAPI.serializeQuery(params);

    RootAPI.setToken();

    const { data } = await RootAPI.get(`/branch?${serializedParams}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const remove = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.delete(`/branch/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const update = async (newProps, id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.patch(`/branch/${id}`, newProps);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const register = async (branch) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.post('/branch', branch);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};
