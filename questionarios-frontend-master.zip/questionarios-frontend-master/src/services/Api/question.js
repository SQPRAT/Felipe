import RootAPI from './root';
import i18n from '../../config/i18n';

export const register = async (testId, question) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.post(`/test/${testId}/question`, question);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const search = async (testId, page) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/test/${testId}/question?page=${page}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const remove = async (testId, id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.delete(`/test/${testId}/question/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const find = async (testId, id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/test/${testId}/question/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const findDirectly = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/question/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const update = async (testId, id, question) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.patch(`/test/${testId}/question/${id}`, question);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};
