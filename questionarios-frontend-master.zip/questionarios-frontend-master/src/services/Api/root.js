import axios from 'axios';
import { getToken } from '../LocalStorage';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,PATCH',
  },
});

// eslint-disable-next-line func-names
api.setFormDataHeader = function () {
  this.defaults.headers['Content-Type'] = 'multipart/form-data';
};

// eslint-disable-next-line func-names
api.setJsonDataHeader = function () {
  this.defaults.headers['Content-Type'] = 'application/json';
};

// eslint-disable-next-line func-names
api.setToken = function () {
  this.defaults.headers.common.Authorization = getToken();
  this.setJsonDataHeader();
};

// eslint-disable-next-line func-names
api.serializeQuery = function (objectQuery) {
  const serializedParams = Object.entries(objectQuery).filter(([, value]) => value).map(([key, value]) => `${key}=${value}`).join('&');

  return serializedParams;
};

export default api;
