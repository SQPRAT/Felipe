import * as user from './user';
import * as test from './test';
import * as question from './question';
import * as branch from './branch';
import * as book from './book';
import * as badge from './badge';
import * as folder from './folder';

export default {
  user,
  test,
  question,
  branch,
  book,
  badge,
  folder,
};
