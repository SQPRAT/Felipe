import RootAPI from './root';
import i18n from '../../config/i18n';

export const register = async (badge) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.post('/badge', badge);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const all = async () => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get('/badge');

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const remove = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.delete(`/badge/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const update = async (id, badge) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.patch(`/badge/${id}`, badge);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};
