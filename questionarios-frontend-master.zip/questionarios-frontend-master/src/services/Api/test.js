import RootAPI from './root';
import i18n from '../../config/i18n';
import { toFormData } from '../../utils/form';

export const register = async (test) => {
  try {
    RootAPI.setToken();
    RootAPI.setFormDataHeader();

    const { data } = await RootAPI.post('/test', toFormData(test));

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const searchBoards = async (keyword) => {
  try {
    const serializedParams = RootAPI.serializeQuery({ keyword });

    RootAPI.setToken();

    const { data } = await RootAPI.get(`/test/boards?${serializedParams}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const search = async (queryParams) => {
  try {
    const serializedParams = RootAPI.serializeQuery(queryParams);

    RootAPI.setToken();

    const { data } = await RootAPI.get(`/test?${serializedParams}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const wizzard = async (testId) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/test/${testId}/wizzard`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const remove = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.delete(`/test/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const registerType = async (testType) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.post('/test-type', testType);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const findAllTypes = async () => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get('/test-type');

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const removeTestType = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.delete(`/test-type/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const find = async (id) => {
  try {
    RootAPI.setToken();

    const { data } = await RootAPI.get(`/test/${id}`);

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};

export const update = async (id, test) => {
  try {
    RootAPI.setToken();
    RootAPI.setFormDataHeader();

    const { data } = await RootAPI.patch(`/test/${id}`, toFormData(test));

    return data;
  } catch (error) {
    const errors = error?.response?.data?.errors ?? [i18n.t('common:somethingWrong')];

    return {
      ok: false,
      errors,
    };
  }
};
