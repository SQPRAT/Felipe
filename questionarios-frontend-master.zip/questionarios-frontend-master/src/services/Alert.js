import Swal from 'sweetalert2';
import i18n from '../config/i18n';

export const error = (errorMessage) => Swal.fire(
  i18n.t('common:ops'),
  errorMessage,
  'error',
);

export const success = (successMessage, callback) => Swal.fire(
  i18n.t('common:nice'),
  successMessage,
  'success',
).then((value) => {
  if (value && callback) {
    callback();
  }
});

export const info = (infoMessage, confirmedCallback, notConfirmedCallback) => Swal.fire({
  title: i18n.t('common:confirm'),
  text: infoMessage,
  icon: 'warning',
  showCancelButton: true,
}).then((result) => {
  if (result.value && confirmedCallback) {
    confirmedCallback();
  } else if (notConfirmedCallback) {
    notConfirmedCallback();
  }
});

export const withInput = async ({
  title,
  // eslint-disable-next-line consistent-return
}, callback) => {
  const { value } = await Swal.fire({
    title,
    input: 'text',
    inputValue: '',
    showCancelButton: true,
    inputValidator: (string) => {
      if (!string) return i18n.t('common:emptyError');

      return null;
    },
  });

  if (value) return callback(value);
};
