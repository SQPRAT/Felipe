import React, { useState, createContext, useEffect } from 'react';
import PropTypes from 'prop-types';
import useService from '../hooks/useService';
import useUser from '../hooks/useUser';
import useStatus from '../hooks/useStatus';

const INITIAL_STATE = {
  user: {},
};

export const AdminContext = createContext();

const AdminContainer = ({ children }) => {
  const LocalStorage = useService('LocalStorage');
  const [state, setState] = useState(INITIAL_STATE);
  const user = useUser();
  const status = useStatus();

  useEffect(() => {
    setState((prevState) => ({ ...prevState, user, status }));
    // eslint-disable-next-line
  }, [LocalStorage]);

  return (
    <AdminContext.Provider value={[state, setState]}>
      {children}
    </AdminContext.Provider>
  );
};

AdminContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

export default AdminContainer;
