import React, { createContext } from 'react';
import PropTypes from 'prop-types';
import dependencies from '../config/dependencies';

export const MainContext = createContext();

const MainContainer = ({ children }) => (
  <MainContext.Provider value={dependencies}>
    {children}
  </MainContext.Provider>
);

MainContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

export default MainContainer;
