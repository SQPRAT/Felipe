import { TiDocument } from 'react-icons/ti';
import {
  FaUsers,
  FaBookOpen,
  FaTags,
} from 'react-icons/fa';

import i18next from '../config/i18n';
import { privateRoutes, userTypes } from '../config/constants';

export const MENU_LINKS = [
  {
    title: 'Usuários',
    icon: FaUsers,
    links: [
      {
        label: i18next.t('menu:newUser'),
        href: privateRoutes.NEW_USER.path,
      },
      {
        label: i18next.t('menu:listUsers'),
        href: privateRoutes.LIST_USERS.path,
      },
    ],
    roles: privateRoutes.NEW_USER.roles,
  },
  {
    title: 'Acessos',
    icon: FaUsers,
    links: [
      {
        label: i18next.t('menu:listAccesses'),
        href: privateRoutes.LIST_ACCESSES.path,
      },
    ],
    roles: privateRoutes.LIST_ACCESSES.roles,
  },
  {
    title: 'Provas',
    icon: TiDocument,
    links: [
      {
        label: i18next.t('menu:newTest'),
        href: privateRoutes.NEW_TEST.path,
      },
      {
        label: i18next.t('menu:listTests'),
        href: privateRoutes.LIST_TESTS.path,
      },
    ],
    roles: privateRoutes.NEW_TEST.roles,
  },
  {
    title: 'Cadernos',
    icon: FaBookOpen,
    links: [
      {
        label: i18next.t('menu:listBooks'),
        href: privateRoutes.LIST_BOOKS.path,
      },
    ],
    roles: privateRoutes.LIST_BOOKS.roles,
  },
  {
    title: 'Tags',
    icon: FaTags,
    links: [
      {
        label: i18next.t('menu:listTags'),
        href: privateRoutes.TAGS.path,
      },
    ],
    roles: privateRoutes.TAGS.roles,
  },
  {
    title: 'Tipos de prova',
    icon: TiDocument,
    links: [
      {
        label: i18next.t('testTypes:list'),
        href: privateRoutes.TEST_TYPES.path,
      },
    ],
    roles: privateRoutes.TAGS.roles,
  },
];

export const isSuperAdmin = (user) => user?.type === userTypes.ADMIN;
export const isAdmin = (user) => user?.type === userTypes.QUESTION_RECORDER;
export const isStudent = (user) => user?.type === userTypes.QUESTION_RECORDER_AND_STUDENT;

export const isAllowed = (user, roles) => roles?.some((role) => role === user?.type) ?? false;

export const filterUser = (users, user) => users.filter((u) => u.id !== user.id);
