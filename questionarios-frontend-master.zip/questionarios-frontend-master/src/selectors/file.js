export const getName = (file) => file.name;

export const getExtension = (file) => file.type.split('/')[1];
