export const toArray = (branchesTree) => branchesTree.reduce((branches, branch) => ([
  ...branches, branch, ...toArray(branch?.childrens ?? []),
]), []);

export const toBranchList = (branches) => {
  const reduceBranch = (items) => items.reduce((prevBranches, currentBranch) => [
    ...prevBranches, currentBranch, ...reduceBranch(currentBranch?.childrens ?? []),
  ], []);
  const branchList = reduceBranch(branches);

  return branchList;
};

export const addCheckPropToBranches = (branches, config) => {
  const mapBranch = (items) => items.map((currentBranch) => {
    const isChecked = config.some((item) => item.topic === currentBranch.id);

    return { ...currentBranch, isChecked, childrens: mapBranch(currentBranch?.childrens ?? []) };
  });
  const branchListWithCheckedProp = mapBranch(branches);

  return branchListWithCheckedProp;
};

const removeChildrens = (branches) => branches.map((branch) => ({ ...branch, childrens: [] }));

export const filterPerKeyword = (keyWord, branches) => {
  const branchList = toBranchList(branches);
  const relatedBranches = branchList.filter((branch) => branch.name
    .toLowerCase().includes(keyWord.toLowerCase()));
  const branchesWithoutChildrens = removeChildrens(relatedBranches);

  return branchesWithoutChildrens;
};

export const getChildBranches = (branchesTree, branch) => {
  const branchesList = toArray(branchesTree);
  const childBranches = branchesList.reduce((branches, currentBranch) => {
    const isChildBranch = (
      currentBranch.parentBranch
      && currentBranch.id !== branch.id
      && branches.some((b) => currentBranch.parentBranch === b.id));

    return isChildBranch ? [currentBranch, ...branches] : [...branches];
  }, [branch]);

  return childBranches.slice(0, childBranches.length - 1);
};

export const getParentBranches = (branchesTree, branch) => {
  const branchesList = toArray(branchesTree);
  const parentBranches = branchesList.reverse().reduce((branches, currentBranch) => {
    const [lastInsertedBranch] = branches;

    if (currentBranch.id === lastInsertedBranch.parentBranch) return [currentBranch, ...branches];

    return [...branches];
  }, [branch]);

  return parentBranches.slice(0, parentBranches.length - 1);
};
