export const filterTest = (tests, test) => tests.filter((t) => t.id !== test.id);
