const isAnswered = (question) => Boolean(question.name);
const isCorrect = (question) => question.isCorrect;
const isIncorrect = (question) => !question.isCorrect && isAnswered(question);
const isSelected = (question) => question.selected;
export const isCancelled = (question) => question?.questionBadges?.some((badge) => badge.name === 'Anulada') ?? false;

const isNotCancelled = (question) => !isCancelled(question);

export const filterAnsweredQuestions = (questions) => questions
  ?.filter(isAnswered)?.filter(isNotCancelled) ?? [];

export const filterCorrectQuestions = (questions) => questions
  ?.filter(isCorrect)?.filter(isNotCancelled) ?? [];

export const filterIncorrectQuestions = (questions) => questions
  ?.filter(isIncorrect)?.filter(isNotCancelled) ?? [];

export const filterSelectedQuestions = (questions) => questions?.filter(isSelected) ?? [];
export const filterQuestion = (questions, question) => (
  questions.filter((t) => t.id !== question.id)
);

export const getCorrectAnswer = (question) => (
  question.answers.find((answer) => answer.correct)
);

export const sortQuestionsByPosition = (questions) => (
  questions.sort((a, b) => a.position - b.position)
);
