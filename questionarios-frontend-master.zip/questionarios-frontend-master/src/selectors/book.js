/* eslint-disable no-restricted-globals */
import { filterAnsweredQuestions, filterCorrectQuestions, filterIncorrectQuestions } from './question';

export const changeFilterValue = (filters, key, value) => filters
  .map((filter) => (filter.key === key ? ({
    ...filter,
    value,
  }) : ({ ...filter })));

export const removeBook = (folders, book) => folders.map((folder) => ({
  ...folder,
  books: folder.books.filter((b) => b.id !== book.id),
}));

export const filterValidFilters = (filters) => filters.filter((filter) => filter.value);
export const filterBookAnsweredQuestions = (book) => filterAnsweredQuestions(book?.questions ?? []);
export const filterBookCorrectQuestions = (book) => filterCorrectQuestions(book?.questions ?? []);
export const filterBookIncorrectQuestions = (book) => (
  filterIncorrectQuestions(book?.questions ?? [])
);

export const getNextRandomNotAnsweredQuestionIndex = (book) => {
  const notAnsweredQuestionsIndexes = book?.questions?.filter((question) => (
    !question.name
  )).map((question) => book.questions.indexOf(question));
  const notAnsweredQuestions = notAnsweredQuestionsIndexes.length;
  const randomNotAnsweredIndex = Math.floor(Math.random() * (notAnsweredQuestions - 0)) + 0;

  return notAnsweredQuestionsIndexes[randomNotAnsweredIndex];
};

export const getNextNotAnsweredQuestionIndex = (book, index) => book?.questions?.findIndex(
  (question, questionIndex) => !question.name && questionIndex > index,
) ?? -1;

export const getPrevNotAnsweredQuestionIndex = (book, index) => book?.questions?.findIndex(
  (question, questionIndex) => !question.name && questionIndex < index,
) ?? -1;

export const getAmountOfQuestions = (book) => {
  const hasConfig = Boolean(book.config.length);

  if (hasConfig) {
    return book
      .config.reduce((accumulator, currentItem) => accumulator + currentItem.amount, 0);
  }

  return book.questions.length;
};

export const getBookQuestionNumbers = (book) => {
  const answeredQuestions = filterBookAnsweredQuestions(book)?.length ?? 0;
  const totalOfQuestions = getAmountOfQuestions(book);

  return {
    total: totalOfQuestions,
    answered: answeredQuestions,
    notAnswered: totalOfQuestions - answeredQuestions,
  };
};

export const getBookQuestionAvg = (book) => {
  const total = book.questions.length;
  const correctAnswers = filterBookCorrectQuestions(book)?.length ?? 0;
  const incorrectAnswers = filterBookIncorrectQuestions(book)?.length ?? 0;
  const correctAnswersPercentage = (100 * correctAnswers) / total;
  const incorrectAnswersPercentage = (100 * incorrectAnswers) / total;

  return {
    correctAnswersPercentage:
      Math.floor(isNaN(correctAnswersPercentage) ? 0 : correctAnswersPercentage),
    incorrectAnswersPercentage:
      Math.floor(isNaN(incorrectAnswersPercentage) ? 0 : incorrectAnswersPercentage),
  };
};

export const getStatistics = (book, current = undefined) => ({
  resolveds: filterBookAnsweredQuestions(book)?.length ?? 0,
  correct: filterBookCorrectQuestions(book)?.length ?? 0,
  incorrect: filterBookIncorrectQuestions(book)?.length ?? 0,
  total: book?.questions?.length ?? 0,
  current: current || book?.current || 0,
});
