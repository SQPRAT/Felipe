const answerFormat = ({
  explanation,
  hasExplanation,
  index,
  ...answer
}) => ({
  ...answer,
  key: `QuestionAnswer-${index}`,
  hasExplanation: hasExplanation || Boolean(explanation),
  explanation,
});

export const questionFormat = ({ answers, ...question }) => ({
  ...question,
  badges: question.questionBadges.map((({ id, badgeId }) => ({ badgeId: (id || badgeId) }))),
  answers: answers.map((answer, index) => answerFormat({ ...answer, index })),
});
