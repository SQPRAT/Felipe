import { filterBookAnsweredQuestions } from '../selectors/book';
import { filterSelectedQuestions } from '../selectors/question';

export const bookFormat = ({
  createdAt,
  current,
  questions,
  ...book
}) => ({
  ...book,
  createdAt,
  formattedCreatedAt: new Date(createdAt).toLocaleDateString('pt-br').replaceAll('&#x2F;', ''),
  current: current || filterBookAnsweredQuestions(book).length || 0,
  questions: questions.map(({ name, ...question }) => ({
    ...question,
    selected: name,
    name,
  })),
});

export const answersFormat = (questions) => (
  filterSelectedQuestions(questions).map(({ id, selected, answers }) => ({
    id,
    option: selected,
    markeds: answers?.map((answer) => ({ marked: Boolean(answer?.marked) })),
  }))
);

export const foldersFormat = (folders) => folders.map((folder) => ({
  ...folder,
  books: folder?.books?.map(bookFormat) ?? [],
  isOpened: false,
}));
