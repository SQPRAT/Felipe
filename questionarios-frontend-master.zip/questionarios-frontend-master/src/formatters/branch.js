import { toArray } from '../selectors/branch';

const treeBranchesWithKeyFormat = (
  branchesTree,
  { key, value },
) => branchesTree.reduce((branches, branch) => ([
  ...branches,
  { ...branch, [key]: value },
  ...toArray(branch?.childBranches ?? []),
]), []);

export const treeBranchesFormat = (branchesTree, expanded = false) => treeBranchesWithKeyFormat(
  branchesTree,
  { key: 'expanded', value: expanded },
);
