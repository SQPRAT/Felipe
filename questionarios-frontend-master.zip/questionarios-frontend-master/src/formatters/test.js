import { daysDiffToNow } from '../utils/date';

export const testFormat = (tests) => tests.map((test) => ({
  name: test?.name ?? '',
  daysOnPast: daysDiffToNow(test.createdAt),
}));
