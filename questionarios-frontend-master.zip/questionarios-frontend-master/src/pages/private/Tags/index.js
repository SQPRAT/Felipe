import React, { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { IoMdAdd } from 'react-icons/io';
import BranchOptions from '../../../components/Branch/BranchOptions';
import Button from '../../../components/ui/Button';
import Page from '../../../components/ui/Page';
import Tree from '../../../components/ui/Tree';
import { treeBranchesFormat } from '../../../formatters/branch';
import useApi from '../../../hooks/useApi';
import useModel from '../../../hooks/useModel';
import useService from '../../../hooks/useService';
import { toArray } from '../../../selectors/branch';

import './index.scss';

const Tags = () => {
  const [branches, setBranches] = useState([]);
  const [branchOptionsCoords, setBranchOptionsCoords] = useState(null);
  const [needsToFetchBranches, setNeedsToFetchBranches] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const BranchAPI = useApi('branch');
  const BranchModel = useModel('branch');
  const Alert = useService('Alert');
  const { t } = useTranslation(['tags', 'question']);

  const fetchBranches = useCallback(async () => {
    setIsLoading(true);

    BranchModel.search({}, {
      onSuccess: (pureBranches) => {
        setBranches(treeBranchesFormat(pureBranches));
        setIsLoading(false);
      },
      onError: (errors) => {
        Alert.error(errors);
        setIsLoading(false);
      },
    }, BranchAPI);
  }, [Alert, BranchAPI, BranchModel]);

  useEffect(() => {
    if (needsToFetchBranches) {
      fetchBranches();
      setNeedsToFetchBranches(false);
    }
  }, [BranchModel, BranchAPI, Alert, fetchBranches, needsToFetchBranches]);

  const handleOpenBranchOptions = (e, item) => {
    e.preventDefault();

    const { clientX: x, clientY: y } = e;

    setBranchOptionsCoords({ x, y, item });
  };

  const handleCloseBranchOptions = useCallback(() => {
    setBranchOptionsCoords(null);
  }, []);

  const handleDeleteBranch = () => {
    const branchId = branchOptionsCoords?.item?.id ?? 0;

    Alert.info(t('branch:confirmRemove'), () => {
      BranchModel.remove(branchId, {
        onSuccess: () => {
          setBranchOptionsCoords(null);
          fetchBranches();
        },
        onError: Alert.error,
      }, BranchAPI);
    });
  };

  const handleCreateBranch = (branchName) => {
    const branchId = branchOptionsCoords?.item?.id ?? null;
    const newBranch = { name: branchName, ...(branchId ? { parentBranch: branchId } : {}) };

    BranchModel.register(newBranch, {
      onError: Alert.error,
      onSuccess: () => {
        setBranchOptionsCoords(null);
        fetchBranches();
      },
    }, BranchAPI);
  };

  const handleUpdateBranch = (newBranchName) => {
    const branchId = branchOptionsCoords?.item?.id ?? 0;

    BranchModel.update({
      name: newBranchName,
    }, branchId, ({
      onSuccess: () => setNeedsToFetchBranches(true),
      onError: Alert.error,
    }), BranchAPI);
  };

  const handleUpdateBranches = ({ nextParentNode, node }) => {
    const branchesList = toArray(branches);
    const prevNode = branchesList.find((b) => b.id === node.id);
    const prevParentNode = branchesList.find((b) => b.id === prevNode.parentBranch);
    const isDifferentParent = nextParentNode?.id !== prevParentNode?.id;

    if (isDifferentParent) {
      BranchModel.update({
        parentBranch: nextParentNode?.id ?? null,
      }, node.id, ({
        onSuccess: () => setNeedsToFetchBranches(true),
        onError: Alert.error,
      }), BranchAPI);
    }
  };

  const handleCreateRootBranch = () => {
    Alert.withInput({
      title: t('branch:nameSentence'),
    }, handleCreateBranch);
  };

  useEffect(() => {
    window.addEventListener('click', handleCloseBranchOptions);

    return () => {
      window.removeEventListener('click', handleCloseBranchOptions);
    };
  }, [handleCloseBranchOptions]);

  return (
    <Page variant="TagsPage" title={t('tags:manage')}>
      <Tree
        onRightClick={handleOpenBranchOptions}
        items={branches}
        onClick={() => {}}
        isDragAndDropEnabled
        onUpdate={handleUpdateBranches}
        canDrag={!isLoading}
      />
      <div className="TagsPage__branches-title">
        <p>{t('question:attributes.branch')}</p>
        <Button type="submit" variant="TagsPage__new-branch" onClick={handleCreateRootBranch}>
          <IoMdAdd />
        </Button>
      </div>
      {branchOptionsCoords && (
        <div className="TagsPage__branches" style={{ top: branchOptionsCoords.y, left: branchOptionsCoords.x }}>
          <BranchOptions
            onDelete={handleDeleteBranch}
            onClose={handleCloseBranchOptions}
            onCreate={handleCreateBranch}
            onUpdate={handleUpdateBranch}
          />
        </div>
      )}
    </Page>
  );
};

export default Tags;
