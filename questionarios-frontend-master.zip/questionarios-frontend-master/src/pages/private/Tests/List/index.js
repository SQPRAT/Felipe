/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router-dom';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useApi from '../../../../hooks/useApi';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import Input from '../../../../components/ui/Input';
import Select from '../../../../components/ui/Select';
import Loading from '../../../../components/ui/Loading';
import Paginate from '../../../../components/ui/Paginate';
import { privateRoutes } from '../../../../config/constants';
import TestPreview from '../../../../components/Test/TestPreview';
import useTestTypeOptions from '../../../../hooks/useTestTypeOptions';

import './index.scss';

const ListTestPage = () => {
  const { t } = useTranslation(['test', 'common']);
  const [tests, setTests] = useState([]);
  const [page, setPage] = useState(0);
  const [amountOfPages, setAmountOfPages] = useState(1);
  const [name, setName] = useState('');
  const [board, setBoard] = useState('');
  const [year, setYear] = useState('');
  const [type, setType] = useState('');
  const [isLoading, toggleLoading] = useState(true);
  const TestModel = useModel('test');
  const Alert = useService('Alert');
  const TestAPI = useApi('test');
  const history = useHistory();
  const testOptions = useTestTypeOptions();

  const handleShowTest = (test) => history.push(privateRoutes.SHOW_TEST.path(test.id));

  useEffect(() => {
    toggleLoading(true);

    const searchParams = {
      page,
      keyword: name,
      board,
      year,
      type,
    };

    TestModel.search(searchParams, {
      onSuccess: (newTests, newPages) => {
        setTests(newTests);
        setAmountOfPages(newPages);
        toggleLoading(false);
      },
      onError: Alert.error,
    }, TestAPI);
  }, [page, TestModel, Alert.error, TestAPI, name, board, year, type]);

  return (
    <Page title={t('test:list')}>
      <Box justifyContent="space-between" flexDirection="row" variant="ListTestPage__inputs">
        <Input
          value={name}
          onChange={setName}
          placeholder={t('test:searchBy', { item: t('test:attributes.name') })}
          variant="ListTestPage__input ListTestPage__input--medium"
        />
        <Input
          value={board}
          onChange={setBoard}
          placeholder={t('test:searchBy', { item: t('test:attributes.board') })}
          variant="ListTestPage__input ListTestPage__input--medium"
        />
        <Input
          type="number"
          value={year}
          onChange={setYear}
          placeholder={t('test:searchBy', { item: t('test:attributes.year') })}
          variant="ListTestPage__input"
        />
        <Select
          variant="ListTestPage__input"
          value={type}
          placeholder={t('test:searchBy', { item: t('test:attributes.type') })}
          options={testOptions}
          onChange={setType}
        />
      </Box>
      <Box variant="ListTestPage__tests">
        {isLoading && <Loading />}
        {tests.map((test) => (
          <div
            className="ListTestPage__test"
            key={test.id}
            onClick={() => handleShowTest(test)}
          >
            <TestPreview
              name={test.name}
              year={test.year}
              amountOfQuestions={test.amountOfQuestions}
              board={test.board}
              typeName={test?.typeName}
            />
          </div>
        ))}
      </Box>
      <div className="ListTestPage__paginate">
        <Paginate onChange={setPage} amountOfPages={amountOfPages} />
      </div>
    </Page>
  );
};

export default ListTestPage;
