import React, { useState, useEffect } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import TestForm from '../../../../components/forms/TestForm';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import { privateRoutes } from '../../../../config/constants';

import './index.scss';

const EditTestPage = () => {
  const [test, setTest] = useState(null);
  const { testId } = useParams();
  const { t } = useTranslation(['test', 'common']);
  const TestAPI = useApi('test');
  const TestModel = useModel('test');
  const Alert = useService('Alert');
  const history = useHistory();

  const handleSubmit = (newTest) => {
    TestModel.update(testId, {
      ...newTest,
      originalFiles: JSON.stringify(newTest.originalFiles),
    }, {
      onSuccess: () => Alert.success(t('common:success'), history.push(privateRoutes.LIST_TESTS.path)),
      onError: Alert.error,
    }, TestAPI);
  };

  useEffect(() => {
    TestModel.find(testId, {
      onError: () => t('common:notFound'),
      onSuccess: setTest,
    }, TestAPI);
  }, [TestModel, testId, t, TestAPI]);

  return (
    <Page title={t('test:list')}>
      <Box variant="EditTestPage__form">
        {test && (
          <TestForm
            onSubmit={handleSubmit}
            initialValues={test}
          />
        )}
      </Box>
    </Page>
  );
};

export default EditTestPage;
