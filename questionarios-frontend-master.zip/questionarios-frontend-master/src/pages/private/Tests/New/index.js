import React from 'react';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import TestForm from '../../../../components/forms/TestForm';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import { privateRoutes } from '../../../../config/constants';

import './index.scss';

const NewTestPage = () => {
  const { t } = useTranslation(['test', 'common']);
  const TestAPI = useApi('test');
  const TestModel = useModel('test');
  const Alert = useService('Alert');
  const history = useHistory();

  const handleSubmit = (test) => {
    TestModel.register(test, {
      onSuccess: (persistedTest) => Alert.success(t('common:success'), history.push(privateRoutes.TEST_WIZZARD.path(persistedTest.id))),
      onError: Alert.error,
    }, TestAPI);
  };

  return (
    <Page title={t('test:list')}>
      <Box variant="NewTestPage__form">
        <TestForm onSubmit={handleSubmit} />
      </Box>
    </Page>
  );
};

export default NewTestPage;
