import React, { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { BsFillTrashFill } from 'react-icons/bs';
import Box from '../../../../components/ui/Box';
import Button from '../../../../components/ui/Button';

import Page from '../../../../components/ui/Page';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';

import './index.scss';

export default function TypesPage() {
  const { t } = useTranslation(['testTypes', 'common']);
  const [testTypes, setTestTypes] = useState([]);
  const TestModel = useModel('test');
  const Alert = useService('Alert');
  const TestAPI = useApi('test');

  useEffect(() => {
    TestModel.all({
      onSuccess: setTestTypes,
      onError: Alert.error,
    }, TestAPI);
  }, [TestModel, Alert.error, TestAPI]);

  const handleDeleteTestType = (testTypeId) => {
    Alert.info(t('testTypes:confirmRemove'), () => {
      TestModel.removeTestType(testTypeId, {
        onSuccess: () => {
          setTestTypes((prevTestTypes) => (
            prevTestTypes.filter((testType) => testType.id !== testTypeId)));
        },
        onError: Alert.error,
      }, TestAPI);
    }, () => {});
  };

  const handleCreateTestType = useCallback(() => {
    Alert.withInput({
      title: 'Qual o nome do novo tipo de prova?',
    }, (newTestTypeName) => {
      TestModel.registerType({ name: newTestTypeName }, {
        onSuccess: (newTestType) => {
          setTestTypes((prevTestTypes) => [...prevTestTypes, newTestType]);
        },
        onError: Alert.error,
      }, TestAPI);
    });
  }, [TestModel, Alert, TestAPI]);

  return (
    <Page title={t('testTypes:list')} showStatistics>
      <div className="ListTestTypes__header">
        <Button variant="ListTestTypes__new-button" onClick={handleCreateTestType}>
          {t('testTypes:new')}
        </Button>
      </div>
      <Box variant="ListTestTypes__types">
        {testTypes.map((type) => (
          <div className="ListTestTypes__type" key={type.id}>
            <div className="ListTestTypes__type-name">{type.name}</div>
            <button onClick={() => handleDeleteTestType(type.id)} className="ListTestTypes__delete-button">
              <BsFillTrashFill className="ListTestTypes__delete-icon" />
            </button>
          </div>
        ))}
      </Box>
    </Page>
  );
}
