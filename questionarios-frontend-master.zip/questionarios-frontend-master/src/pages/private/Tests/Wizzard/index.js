import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useHistory } from 'react-router-dom';
import Page from '../../../../components/ui/Page';
import Button from '../../../../components/ui/Button';
import useApi from '../../../../hooks/useApi';
import useService from '../../../../hooks/useService';
import useModel from '../../../../hooks/useModel';
import QuestionBadgeSubtitle from '../../../../components/Question/QuestionBadgeSubtitle';
import TestWizzard from '../../../../components/Test/TestWizzard';
import { privateRoutes, questionFormPageQueryParams } from '../../../../config/constants';
import { createQueryParams } from '../../../../utils/url';

import './index.scss';

const WizzardPage = () => {
  const [test, setTest] = useState(null);
  const [badges, setBadges] = useState([]);
  const [wizzardItems, setWizzardItems] = useState([]);
  const { testId } = useParams();
  const TestAPI = useApi('test');
  const TestModel = useModel('test');
  const Alert = useService('Alert');
  const BadgeAPI = useApi('badge');
  const BadgeModel = useModel('badge');
  const { t } = useTranslation(['test', 'common']);
  const history = useHistory();

  const handleClickWizzardItem = (index) => {
    const wizzardItem = wizzardItems[index];
    const positionIsAvailable = wizzardItem.available;
    const questionId = wizzardItem.id;

    if (positionIsAvailable) {
      const questionPageParams = [
        {
          key: questionFormPageQueryParams.TEST_NAME,
          value: test?.name ?? '',
        },
        {
          key: questionFormPageQueryParams.POSITION,
          value: wizzardItem.position,
        },
      ];

      history.push([privateRoutes.NEW_QUESTION.path, createQueryParams(questionPageParams)].join('?'));
    } else {
      history.push(privateRoutes.EDIT_QUESTION.path(testId, questionId));
    }
  };

  const navigateToQuestionsPage = () => {
    history.push(privateRoutes.LIST_QUESTIONS.path(testId));
  };

  const navigateToImportWizzardPage = () => {
    history.push(privateRoutes.IMPORT_WIZZARD.path(testId));
  };

  useEffect(() => {
    TestModel.find(testId, {
      onError: () => t('common:notFound'),
      onSuccess: setTest,
    }, TestAPI);

    TestModel.wizzard(testId, {
      onError: () => t('common:notFound'),
      onSuccess: setWizzardItems,
    }, TestAPI);
  }, [TestModel, testId, t, TestAPI]);

  useEffect(() => {
    BadgeModel.all({
      onError: Alert.error,
      onSuccess: ({ badges: data }) => setBadges(data),
    }, BadgeAPI);
  }, [Alert.error, BadgeAPI, BadgeModel]);

  return (
    <Page title={t('test:wizzard', { test: test?.name ?? '' })}>
      <ul className="WizzardPage__subtitles">
        {(badges.concat([{name: "Rascunho"}])).map((badge) => (
          <li className="WizzardPage__subtitle" key={badge.name}>
            <QuestionBadgeSubtitle name={badge.name} />
          </li>
        ))}
      </ul>
      <div className="WizzardPage__body">
        <TestWizzard items={wizzardItems} onClick={handleClickWizzardItem} />
      </div>
      <div className="WizzardPage__questions-button-wrapper">     
        <Button variant="WizzardPage__questions-button" onClick={navigateToImportWizzardPage}>
          {t('test:importQuestions')}
        </Button>
        <Button variant="WizzardPage__questions-button" onClick={navigateToQuestionsPage}>
          {t('test:listQuestions')}
        </Button>
      </div>
    </Page>
  );
};

export default WizzardPage;
