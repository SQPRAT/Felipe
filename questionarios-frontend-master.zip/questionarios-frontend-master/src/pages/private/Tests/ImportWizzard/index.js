import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useHistory } from 'react-router-dom';
import Page from '../../../../components/ui/Page';
import Button from '../../../../components/ui/Button';
import useApi from '../../../../hooks/useApi';
import useService from '../../../../hooks/useService';
import useModel from '../../../../hooks/useModel';
import QuestionBadgeSubtitle from '../../../../components/Question/QuestionBadgeSubtitle';
import TestWizzard from '../../../../components/Test/TestWizzard';
import { privateRoutes, questionFormPageQueryParams } from '../../../../config/constants';
import { createQueryParams } from '../../../../utils/url';

import './index.scss';
import File from '../../../../components/ui/File';

const questionConverter = imp => {
  const question = {
    position: imp.position,
    description: (imp.description || "").split("\n").map(l => '<p>' + l + '</p>').join("\n"),
    explanation: (imp.explanation || "").split("\n").map(l => '<p>' + l + '</p>').join("\n"),
    answers: imp.answers.map((ra, ri) => {
      return {
        description: (ra || "").split("\n").map(l => '<p>' + l + '</p>').join("\n"),
        explanation: '',
        correct: ri === imp.answerIndex
      }
    }),
    questionBadges: [],
    isDraft: true
  };

  // if (imp.tipo_alternativas === "abcde") {
  //   for (const tk of imp.tipo_alternativas.split("")) {
  //     question.answers.push({
  //       description: imp.alternativas["(" + tk + ")"],
  //       explanation: '',
  //       correct: false
  //     })
  //   }
  // }
  return question;
}

const ImportWizzardPage = () => {
  const [file, setFile] = useState([]);
  const [test, setTest] = useState(null);
  const [badges, setBadges] = useState([]);
  const [importedData, setImportedData] = useState([]);
  const [wizzardItems, setWizzardItems] = useState([]);
  const { testId } = useParams();
  const TestAPI = useApi('test');
  const TestModel = useModel('test');
  const Alert = useService('Alert');
  const BadgeAPI = useApi('badge');
  const BadgeModel = useModel('badge');
  const QuestionModel = useModel('question');
  const QuestionAPI = useApi('question');
  const { t } = useTranslation(['test', 'common']);
  const history = useHistory();

  const handleClickWizzardItem = (index) => {
    const wizzardItem = wizzardItems[index];
    const positionIsAvailable = wizzardItem.available;
    const questionId = wizzardItem.id;

    if (positionIsAvailable) {
      const questionPageParams = [
        {
          key: questionFormPageQueryParams.TEST_NAME,
          value: test?.name ?? '',
        },
        {
          key: questionFormPageQueryParams.POSITION,
          value: wizzardItem.position,
        },
      ];

      history.push([privateRoutes.NEW_QUESTION.path, createQueryParams(questionPageParams)].join('?'));
    } else {
      history.push(privateRoutes.EDIT_QUESTION.path(testId, questionId));
    }
  };

  const navigateToQuestionsPage = () => {
    history.push(privateRoutes.LIST_QUESTIONS.path(testId));
  };

  useEffect(() => {

    TestModel.find(testId, {
      onError: () => t('common:notFound'),
      onSuccess: setTest,
    }, TestAPI);

    TestModel.wizzard(testId, {
      onError: () => t('common:notFound'),
      onSuccess: (wi) => {
        // setImportedData(impTeste);
        setWizzardItems(wi);
      },
    }, TestAPI);
  }, [TestModel, testId, t, TestAPI]);

  useEffect(() => {
    BadgeModel.all({
      onError: Alert.error,
      onSuccess: ({ badges: data }) => setBadges(data),
    }, BadgeAPI);
  }, [Alert.error, BadgeAPI, BadgeModel]);

  return (
    <Page title={t('test:import_wizzard', { test: test?.name ?? '' })}>

      <div className="Form__field Form__field--file">
        <File
          // onRemove={handleRemoveFile}
          files={file}
          onChangeDescription={() => {

          }}
          onUpload={(e) => {
            const file = e.target.files[0];
            let reader = new FileReader();
            reader.readAsText(file);

            reader.onload = async function () {
              const raw = JSON.parse(reader.result);
              
              const availablePos = wizzardItems.filter(wi => wi.available).map(wi => wi.position);
              const errors = [];
              for (const rq of raw) {
                const question = questionConverter(rq);
                if (!availablePos.includes(question.position)) continue;

                question.test = { id: testId, questionTypes: 2 }
                await new Promise(resolve => {
                  QuestionModel.register(question, {
                    onSuccess: () => {
                      resolve()
                    },
                    onError: errorList => {
                      errors.push(errorList);
                      resolve();
                    },
                  }, QuestionAPI);
                })
              }

              if (errors.length === 0){
                Alert.success(t('common:success'), () => history.push(privateRoutes.TEST_WIZZARD.path(testId)))              
              } else {
                Alert.error(errors);
              }              
            };

            reader.onerror = function () {
              console.log(reader.error);
            };

            setFile([file])
          }}
        />
      </div>

      {importedData.map(imp => {
        return <div onClick={() => {
          const position = imp.label * 1;
          const question = {
            position: position,
            description: imp.enunciado_raw.map(er => er.text).join("\n"),
            answers: []
          };

          if (imp.tipo_alternativas === "abcde") {
            for (const tk of imp.tipo_alternativas.split("")) {
              question.answers.push({
                description: imp.alternativas["(" + tk + ")"],
                correct: false
              })
            }
          }

          const tqKey = `question_${testId}_${position}`;
          sessionStorage.setItem(tqKey, JSON.stringify(question));
          history.push(privateRoutes.EDIT_IMPORT_QUESTION.path(testId, position));

        }}>{imp.label}</div>
      })}

      <div className="WizzardPage__questions-button-wrapper">
        <Button variant="WizzardPage__questions-button" onClick={navigateToQuestionsPage}>
          {t('test:importQuestions')}
        </Button>
      </div>
    </Page>
  );
};

export default ImportWizzardPage;
