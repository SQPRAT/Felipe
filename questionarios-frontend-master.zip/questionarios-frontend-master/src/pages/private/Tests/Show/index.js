import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory, useParams } from 'react-router-dom';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import Page from '../../../../components/ui/Page';
import Button from '../../../../components/ui/Button';
import Loading from '../../../../components/ui/Loading';
import TestPreview from '../../../../components/Test/TestPreview';
import { privateRoutes } from '../../../../config/constants';

import './index.scss';

const ShowTestPage = () => {
  const [test, setTest] = useState(null);
  const { testId } = useParams();
  const { t } = useTranslation(['test', 'common', 'question']);
  const TestAPI = useApi('test');
  const TestModel = useModel('test');
  const Alert = useService('Alert');
  const history = useHistory();

  useEffect(() => {
    TestModel.find(testId, {
      onError: () => t('common:notFound'),
      onSuccess: setTest,
    }, TestAPI);
  }, [TestModel, testId, t, TestAPI]);

  const handleDeleteTest = () => Alert.info(t('test:confirmRemove'), () => TestModel.remove(testId, {
    onSuccess: () => history.push(privateRoutes.LIST_TESTS.path),
    onError: Alert.error,
  }, TestAPI));

  const handleNavigateToWizzard = () => history.push(privateRoutes.TEST_WIZZARD.path(testId));

  const handleEditTest = () => history.push(privateRoutes.EDIT_TEST.path(testId));

  return (
    <Page title={t('question:attributes.test')}>
      {test ? (
        <>
          <div className="ShowTestPage__info">
            <TestPreview {...test} />
          </div>
          <Button onClick={handleEditTest} variant="ShowTestPage__button">
            {t('test:edit')}
          </Button>
          <Button onClick={handleDeleteTest} variant="ShowTestPage__button">
            {t('test:delete')}
          </Button>
          <Button onClick={handleNavigateToWizzard} variant="ShowTestPage__button">
            {t('test:questions')}
          </Button>
        </>
      ) : (
        <Loading />
      )}
    </Page>
  );
};

export default ShowTestPage;
