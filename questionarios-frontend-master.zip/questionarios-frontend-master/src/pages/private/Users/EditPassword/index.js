import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import { privateRoutes } from '../../../../config/constants';
import useUser from '../../../../hooks/useUser';
import Input from '../../../../components/ui/Input';
import Button from '../../../../components/ui/Button';

import './index.scss';

const EditPasswordPage = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const { id } = useUser();
  const { t } = useTranslation(['user', 'common']);
  const UserAPI = useApi('user');
  const UserModel = useModel('user');
  const Alert = useService('Alert');
  const history = useHistory();

  const handleSubmit = (e) => {
    e.preventDefault();

    UserModel.update(id, { password, confirmPassword }, {
      onSuccess: () => Alert.success(t('common:success'), () => history.push(privateRoutes.HOME.path)),
      onError: Alert.error,
    }, UserAPI);
  };

  return (
    <Page title={t('user:editPassword')}>
      <Box variant="EditPasswordPage__form">
        <form onSubmit={handleSubmit} className="EditPasswordPage__form-wrapper">
          <div className="EditPasswordPage__field">
            <Input value={password} onChange={setPassword} type="password" placeholder="Senha" />
          </div>
          <div className="EditPasswordPage__field">
            <Input value={confirmPassword} onChange={setConfirmPassword} type="password" placeholder="Confirmação de senha" />
          </div>
          <div className="EditPasswordPage__button">
            <Button type="submit" onClick={handleSubmit}>Salvar</Button>
          </div>
        </form>
      </Box>
    </Page>
  );
};

export default EditPasswordPage;
