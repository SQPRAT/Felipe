import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useApi from '../../../../hooks/useApi';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import Paginate from '../../../../components/ui/Paginate';

import './index.scss';

const ListUserAccessesPage = () => {
  const { t } = useTranslation(['user', 'common']);
  const [accesses, setAccesses] = useState([]);
  const [page, setPage] = useState(0);
  const [amountOfPages, setAmountOfPages] = useState(1);
  const UserModel = useModel('user');
  const Alert = useService('Alert');
  const UserAPI = useApi('user');

  useEffect(() => {
    UserModel.accesses('', page, {
      onSuccess: (newAccesses, newPages) => {
        setAccesses(newAccesses);
        setAmountOfPages(newPages);
      },
      onError: Alert.error,
    }, UserAPI);
  }, [page, UserModel, Alert.error, UserAPI]);

  return (
    <Page title={t('user:accesses')} showStatistics>
      <Box variant="ListUserAccessesPage__accesses">
        {accesses.map((access) => (
          <div className="ListUserAccessesPage__access" key={access.id}>
            <div className="ListUserAccessesPage__field">{new Date(access.createdAt).toLocaleDateString('pt-br').replaceAll('&#x2F;', '')}</div>
            <div className="ListUserAccessesPage__field">{access.user.name}</div>
            <div className="ListUserAccessesPage__field">{access.user.email}</div>
            <div className="ListUserAccessesPage__field">{access.ip}</div>
          </div>
        ))}
      </Box>
      <div className="ListUserAccessesPage__paginate">
        <Paginate onChange={setPage} amountOfPages={amountOfPages} />
      </div>
    </Page>
  );
};

export default ListUserAccessesPage;
