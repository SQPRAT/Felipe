import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router-dom';
import { BsTrashFill } from 'react-icons/bs';
import { AiFillEdit } from 'react-icons/ai';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useApi from '../../../../hooks/useApi';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import Paginate from '../../../../components/ui/Paginate';
import { privateRoutes } from '../../../../config/constants';
import { filterUser } from '../../../../selectors/user';

import './index.scss';

const ListUsersPage = () => {
  const { t } = useTranslation(['user', 'common']);
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(0);
  const [amountOfPages, setAmountOfPages] = useState(1);
  const UserModel = useModel('user');
  const Alert = useService('Alert');
  const UserAPI = useApi('user');
  const history = useHistory();

  const handleDeleteUser = (user) => Alert.info(t('user:confirmRemove'), () => UserModel.remove(user.id, {
    onSuccess: () => setUsers((prevUsers) => filterUser(prevUsers, user)),
    onError: Alert.error,
  }, UserAPI));

  const handleEditUser = (user) => history.push(privateRoutes.EDIT_USER.path(user.id));

  useEffect(() => {
    UserModel.search(page, {
      onSuccess: (newUsers, newPages) => {
        setUsers(newUsers);
        setAmountOfPages(newPages);
      },
      onError: Alert.error,
    }, UserAPI);
  }, [page, UserModel, Alert.error, UserAPI]);

  return (
    <Page title={t('user:list')} showStatistics>
      <Box variant="ListUsersPage__users">
        {users.map((user) => (
          <div className="ListUsersPage__user" key={user.id}>
            <div className="ListUsersPage__user-email">{user.email}</div>
            <div className="ListUsersPage__user-name">{user.name}</div>
            <div className="ListUsersPage__user-type">{t(`user:types.${user.type}`)}</div>
            <div className="ListUsersPage__user-actions">
              <button className="ListUsersPage__user-action" onClick={() => handleDeleteUser(user)}>
                <BsTrashFill />
              </button>
              <button onClick={() => handleEditUser(user)} className="ListUsersPage__user-action">
                <AiFillEdit />
              </button>
            </div>
          </div>
        ))}
      </Box>
      <div className="ListUsersPage__paginate">
        <Paginate onChange={setPage} amountOfPages={amountOfPages} />
      </div>
    </Page>
  );
};

export default ListUsersPage;
