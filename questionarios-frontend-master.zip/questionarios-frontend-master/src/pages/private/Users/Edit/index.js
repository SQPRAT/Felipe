import React, { useState, useEffect } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import UserForm from '../../../../components/forms/UserForm';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import { privateRoutes } from '../../../../config/constants';

import './index.scss';

const EditUserPage = () => {
  const [user, setUser] = useState(null);
  const { userId } = useParams();
  const { t } = useTranslation(['user', 'common']);
  const UserAPI = useApi('user');
  const UserModel = useModel('user');
  const Alert = useService('Alert');
  const history = useHistory();

  const handleSubmit = (newUser) => {
    UserModel.update(userId, newUser, {
      onSuccess: () => Alert.success(t('common:success'), history.push(privateRoutes.LIST_USERS.path)),
      onError: Alert.error,
    }, UserAPI);
  };

  useEffect(() => {
    UserModel.find(userId, {
      onError: () => t('common:notFound'),
      onSuccess: setUser,
    }, UserAPI);
  }, [UserModel, userId, t, UserAPI]);

  return (
    <Page title={t('user:list')}>
      <Box variant="EditUserPage__form">
        {user && (
          <UserForm
            onSubmit={handleSubmit}
            initialValues={user}
            hide={{ password: true, confirmPassword: true }}
          />
        )}
      </Box>
    </Page>
  );
};

export default EditUserPage;
