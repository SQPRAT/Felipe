import React from 'react';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import UserForm from '../../../../components/forms/UserForm';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import { privateRoutes } from '../../../../config/constants';

import './index.scss';

const NewUserPage = () => {
  const { t } = useTranslation(['user', 'common']);
  const UserAPI = useApi('user');
  const UserModel = useModel('user');
  const Alert = useService('Alert');
  const history = useHistory();

  const handleSubmit = (user) => {
    UserModel.register(user, {
      onSuccess: () => Alert.success(t('common:success'), history.push(privateRoutes.LIST_USERS.path)),
      onError: Alert.error,
    }, UserAPI);
  };

  return (
    <Page title={t('user:list')}>
      <Box variant="NewUserPage__form">
        <UserForm onSubmit={handleSubmit} />
      </Box>
    </Page>
  );
};

export default NewUserPage;
