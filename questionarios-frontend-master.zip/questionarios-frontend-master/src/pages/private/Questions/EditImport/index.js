import React, { useState, useEffect } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import QuestionForm from '../../../../components/forms/QuestionForm';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useQueryParam from '../../../../hooks/useQueryParam';
import { createQueryParams } from '../../../../utils/url';
import { bookPageQueryParams, privateRoutes, questionFormPageQueryParams } from '../../../../config/constants';

import './index.scss';

const EditImportQuestionPage = () => {
  const [question, setQuestion] = useState(null);
  const { testId, position } = useParams();
  const { t } = useTranslation(['question', 'common']);
  const QuestionAPI = useApi('question');
  const QuestionModel = useModel('question');
  const Alert = useService('Alert');
  const history = useHistory();
  const bookQueryParam = useQueryParam(questionFormPageQueryParams.BOOK);

  const handleSubmit = (newQuestion) => {
    QuestionModel.update(testId, position, newQuestion, {
      onSuccess: () => Alert.success(t('common:success'), () => {
        if (bookQueryParam) {
          const book = JSON.parse(bookQueryParam || '{}');

          history.push([
            privateRoutes.SHOW_BOOK.path(book.folder, book.book),
            createQueryParams([
              {
                key: bookPageQueryParams.QUESTION_INDEX,
                value: book.questionIndex,
              },
            ]),
          ].join('?'));

          return;
        }

        history.push(privateRoutes.TEST_WIZZARD.path(testId));
      }),
      onError: Alert.error,
    }, QuestionAPI);
  };

  useEffect(() => {
    setQuestion(JSON.parse(sessionStorage.getItem(`question_${testId}_${position}`)))

    // QuestionModel.find(testId, questionId, {
    //   onError: () => t('common:notFound'),
    //   onSuccess: setQuestion,
    // }, QuestionAPI);
  }, [QuestionModel, testId, t, QuestionAPI, position]);

  return (
    <Page title={t('question:list')}>
      <Box variant="EditQuestionPage__form">
        {question && (
          <QuestionForm
            onSubmit={handleSubmit}
            initialValues={{ ...question, test: { id: Number(testId) } }}
            hide={{ test: true }}
          />
        )}
      </Box>
    </Page>
  );
};

export default EditImportQuestionPage;
