import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory, useParams } from 'react-router-dom';
import { BsTrashFill } from 'react-icons/bs';
import { AiFillEdit } from 'react-icons/ai';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useApi from '../../../../hooks/useApi';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import Paginate from '../../../../components/ui/Paginate';
import { privateRoutes } from '../../../../config/constants';
import { filterQuestion } from '../../../../selectors/question';

import './index.scss';

const ListQuestionsPage = () => {
  const { t } = useTranslation(['question', 'common']);
  const [questions, setQuestions] = useState([]);
  const [page, setPage] = useState(0);
  const [amountOfPages, setAmountOfPages] = useState(1);
  const QuestionModel = useModel('question');
  const Alert = useService('Alert');
  const QuestionAPI = useApi('question');
  const history = useHistory();
  const { testId } = useParams();

  const handleDeleteQuestion = (question) => Alert.info(t('question:confirmRemove'), () => QuestionModel.remove({ ...question, test: { id: testId } }, {
    onSuccess: () => setQuestions((prevQuestions) => filterQuestion(
      prevQuestions, question,
    )),
    onError: Alert.error,
  }, QuestionAPI));

  const handleEditQuestion = (question) => history.push(
    privateRoutes.EDIT_QUESTION.path(testId, question.id),
  );

  useEffect(() => {
    QuestionModel.search(testId, page, {
      onSuccess: (newQuestions, newPages) => {
        setQuestions(newQuestions);
        setAmountOfPages(newPages);
      },
      onError: Alert.error,
    }, QuestionAPI);
  }, [page, QuestionModel, Alert.error, QuestionAPI, testId]);

  return (
    <Page title={t('question:list')}>
      <Box variant="ListQuestionsPage__questions">
        {questions.map((question) => (
          <div className="ListQuestionsPage__question" key={question.id}>
            <div className="ListQuestionsPage__question-status">
              {['#', question.position].join('')}
            </div>
            <div className="ListQuestionsPage__question-actions">
              <button className="ListQuestionsPage__question-action" onClick={() => handleDeleteQuestion(question)}>
                <BsTrashFill />
              </button>
              <button onClick={() => handleEditQuestion(question)} className="ListQuestionsPage__question-action">
                <AiFillEdit />
              </button>
            </div>
          </div>
        ))}
      </Box>
      <div className="ListQuestionsPage__paginate">
        <Paginate onChange={setPage} amountOfPages={amountOfPages} />
      </div>
    </Page>
  );
};

export default ListQuestionsPage;
