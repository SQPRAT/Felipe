import React, { useState, useEffect, useMemo } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import QuestionForm from '../../../../components/forms/QuestionForm';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useQueryParam from '../../../../hooks/useQueryParam';
import { createQueryParams } from '../../../../utils/url';
import { bookPageQueryParams, privateRoutes, questionFormPageQueryParams } from '../../../../config/constants';

import './index.scss';
import QuestionElaborated from '../../../../components/Question/QuestionElaborated';
import { isCancelled } from '../../../../selectors/question';

const ViewQuestionPage = () => {
  const [question, setQuestion] = useState(null);
  const [selected, setSelected] = useState('');
  const [selectedAnswerIndex, setSelectedAnswerIndex] = useState(0);
  const { testId, questionId } = useParams();
  const { t } = useTranslation(['question', 'common']);
  const QuestionAPI = useApi('question');
  const QuestionModel = useModel('question');
  const Alert = useService('Alert');
  const history = useHistory();
  const bookQueryParam = useQueryParam(questionFormPageQueryParams.BOOK);

  useEffect(() => {
    QuestionModel.find(testId, questionId, {
      onError: () => t('common:notFound'),
      onSuccess: setQuestion,
    }, QuestionAPI);
  }, [QuestionModel, testId, t, QuestionAPI, questionId]);

  const currentQuestionIsCancelled = useMemo(() => (
    isCancelled(question)
  ), [question]);

  const handleChangeAnswer = (newAnswer, newAnswerIndex) => {
    setSelected(newAnswer?.description || '');
    setSelectedAnswerIndex(newAnswerIndex);
  };

  return (
    <Page title={t('question:view')}>
      <Box variant="EditQuestionPage__form">
        {/* {question && (
          <div>{JSON.stringify(question)}</div>
        )} */}
        {question && (
          <QuestionElaborated
            id={question?.id}
            readOnly
            testId={question?.testId}
            test={question?.test?.name ?? ''}
            description={question?.description ?? ''}
            explanation={question?.explanation ?? ''}
            answers={question?.answers ?? []}
            onSelectAnswer={handleChangeAnswer}
            selected={selected}
            selectedAnswerIndex={selectedAnswerIndex}
            // showExplanation={showExplanation}
            // onMarkAnswer={handleMarkAnswer}
            // showAnswer={showAnswer}
            isCancelledQuestion={currentQuestionIsCancelled}
          />
        )}
      </Box>
    </Page>
  );
};

export default ViewQuestionPage;
