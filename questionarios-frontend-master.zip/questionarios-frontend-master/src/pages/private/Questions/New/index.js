import React from 'react';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import QuestionForm from '../../../../components/forms/QuestionForm';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useQueryParam from '../../../../hooks/useQueryParam';
import { privateRoutes, questionFormPageQueryParams } from '../../../../config/constants';
import { createQueryParams } from '../../../../utils/url';

import './index.scss';

const NewQuestionPage = () => {
  const { t } = useTranslation(['question', 'common']);
  const QuestionAPI = useApi('question');
  const QuestionModel = useModel('question');
  const TestAPI = useApi('test');
  const TestModel = useModel('test');
  const Alert = useService('Alert');
  const history = useHistory();
  const testNameQueryParam = useQueryParam(questionFormPageQueryParams.TEST_NAME);
  const positionQueryParam = useQueryParam(questionFormPageQueryParams.POSITION);

  const handleSubmit = (question) => {
    QuestionModel.register(question, {
      onSuccess: () => Alert.success(t('common:success'), () => history.push(privateRoutes.TEST_WIZZARD.path(question.test.id))),
      onError: Alert.error,
    }, QuestionAPI);
  };

  const handleSubmitAndNavigateToNextQuestion = (question) => {
    QuestionModel.register(question, {
      onSuccess: () => {
        Alert.success(t('common:success'), () => {
          TestModel.wizzard(question.test.id, {
            onError: () => t('common:notFound'),
            onSuccess: (wizzard) => {
              const nextPositionToAnswer = wizzard.find((item) => (
                item.available && item.position > question.position));

              if (nextPositionToAnswer) {
                history.push([
                  privateRoutes.NEW_QUESTION.path,
                  createQueryParams([
                    {
                      key: questionFormPageQueryParams.POSITION,
                      value: nextPositionToAnswer.position,
                    },
                    {
                      key: questionFormPageQueryParams.TEST_NAME,
                      value: question.test.name || testNameQueryParam,
                    },
                  ]),
                ].join('?'));
              } else {
                history.push(privateRoutes.LIST_QUESTIONS.path(question.test.id));
                Alert.info(t('question:allQuestionsFilled'));
              }
            },
          }, TestAPI);
        });
      },
      onError: Alert.error,
    }, QuestionAPI);
  };

  return (
    <Page title={t('question:list')}>
      <Box variant="NewQuestionPage__form">
        <QuestionForm
          onSubmit={handleSubmit}
          initialValues={{
            test: {
              name: testNameQueryParam,
            },
            position: positionQueryParam,
          }}
          onSubmitAndNavigateToNextQuestion={handleSubmitAndNavigateToNextQuestion}
        />
      </Box>
    </Page>
  );
};

export default NewQuestionPage;
