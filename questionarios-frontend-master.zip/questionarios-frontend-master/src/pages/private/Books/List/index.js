import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { FaSearch } from 'react-icons/fa';
import BookFolder from '../../../../components/Book/BookFolder';
import Page from '../../../../components/ui/Page';
import Input from '../../../../components/ui/Input';
import Box from '../../../../components/ui/Box';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useApi from '../../../../hooks/useApi';
import useUser from '../../../../hooks/useUser';
import { removeBook } from '../../../../selectors/book';

import './index.scss';

const ListBookPage = () => {
  const { t } = useTranslation(['book', 'common', 'folder']);
  const [folders, setFolders] = useState([]);
  const [keyword, setKeyword] = useState('');
  const [filteredFolders, setFilteredFolders] = useState([]);
  const BookModel = useModel('book');
  const FolderModel = useModel('folder');
  const Alert = useService('Alert');
  const BookAPI = useApi('book');
  const FolderAPI = useApi('folder');
  const { id: userId } = useUser();

  const fetchFolders = useCallback(() => {
    BookModel.all(userId, {
      onSuccess: setFolders,
      onError: Alert.error,
    }, BookAPI);
  }, [BookModel, Alert.error, BookAPI, userId]);

  const handleDeleteBook = (folder, book) => Alert.info(t('book:confirmRemove'), () => BookModel.remove(userId, folder, book, {
    onSuccess: () => setFolders((prevFolders) => removeBook(
      prevFolders, book,
    )),
    onError: Alert.error,
  }, BookAPI));

  const handleDeleteFolder = (folderId) => Alert.info(t('folder:confirmRemove'), () => FolderModel.remove(userId, folderId, {
    onSuccess: () => setFolders((prevFolders) => prevFolders.filter((f) => f.id !== folderId)),
    onError: Alert.error,
  }, FolderAPI));

  const handleEditFolder = (folderId) => Alert.withInput({
    title: t('folder:nameSentence'),
  }, (newName) => FolderModel.update(userId, folderId, { name: newName }, {
    onError: Alert.error,
    // eslint-disable-next-line max-len
    onSuccess: () => setFolders((prevFolders) => prevFolders.map((folder) => (folder.id === folderId ? ({ ...folder, name: newName }) : ({ ...folder })))),
  }, FolderAPI));

  const handleToggleFolderOptions = (index) => setFolders((prevFolders) => prevFolders.map(
    // eslint-disable-next-line max-len
    (folder, folderIndex) => (folderIndex === index ? ({ ...folder, isOpened: !folder.isOpened }) : ({ ...folder })),
  ));

  const handleExpandFolder = (index) => setFolders((prevFolders) => prevFolders.map(
    // eslint-disable-next-line max-len
    (folder, folderIndex) => (folderIndex === index ? ({ ...folder, expanded: !folder.expanded }) : ({ ...folder })),
  ));

  const handleCreateFolder = () => Alert.withInput({
    title: t('folder:nameSentence'),
  }, (name) => FolderModel.register(userId, { name }, {
    onError: Alert.error,
    onSuccess: () => {
      fetchFolders();
    },
  }, FolderAPI));

  useEffect(() => {
    fetchFolders();
  }, [fetchFolders]);

  useEffect(() => {
    const newFilteredFolders = folders.filter((folder) => {
      const hasStringOnName = folder?.name?.toUpperCase()?.includes(keyword.toUpperCase()) ?? false;
      const someBookHasStringOnName = folder?.books?.some(
        (book) => book?.name?.toUpperCase()?.includes(keyword.toUpperCase()),
      ) ?? false;

      return hasStringOnName || someBookHasStringOnName;
    });

    setFilteredFolders(newFilteredFolders);
  }, [keyword, folders]);

  return (
    <Page
      title={(
        <div className="ListBookPage__title">
          <p>{t('book:list')}</p>
          <button onClick={handleCreateFolder} className="ListBookPage__new-folder">{['+', t('folder:create')].join(' ')}</button>
          <FaSearch className="ListBookPage__search-icon" />
          <Input variant="ListBookPage__filter" value={keyword} onChange={setKeyword} type="search" placeholder={t('book:searchBookAndFolder')} />
        </div>
      )}
      showStatistics
    >
      {(keyword ? filteredFolders : folders).map((folder, folderIndex) => (
        <Box variant="ListBookPage__folder" key={`${folder.id}-${folder.name}`}>
          <BookFolder
            id={folder.id}
            name={folder.name}
            isOpened={folder.isOpened}
            books={folder.books}
            onEdit={handleEditFolder}
            onToggleOptions={() => handleToggleFolderOptions(folderIndex)}
            onExpandFolder={() => handleExpandFolder(folderIndex)}
            isExpanded={folder.expanded}
            onDeleteBook={(book) => handleDeleteBook(folder, book)}
            onDeleteFolder={handleDeleteFolder}
          />
        </Box>
      ))}
    </Page>
  );
};

export default ListBookPage;
