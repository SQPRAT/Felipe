import React from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Page from '../../../../components/ui/Page';
import Box from '../../../../components/ui/Box';
import BookForm from '../../../../components/forms/BookForm';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useService from '../../../../hooks/useService';
import useUser from '../../../../hooks/useUser';
import { privateRoutes } from '../../../../config/constants';

import './index.scss';

const NewBookPage = () => {
  const { t } = useTranslation(['book']);
  const BookAPI = useApi('book');
  const BookModel = useModel('book');
  const Alert = useService('Alert');
  const user = useUser();
  const history = useHistory();
  const { folderId } = useParams();

  const handleSubmit = (book) => BookModel.register(user, folderId, book, {
    onSuccess: () => Alert.success(t('common:success'), history.push(privateRoutes.LIST_BOOKS.path)),
    onError: Alert.error,
  }, BookAPI);

  return (
    <Page title={t('book:list')} showStatistics>
      <Box variant="NewBookPage__form">
        <BookForm
          onSubmit={handleSubmit}
          hide={{
            name: false,
            config: false,
            board: false,
          }}
        />
      </Box>
    </Page>
  );
};

export default NewBookPage;
