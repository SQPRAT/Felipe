import React, {
  useEffect,
  useMemo,
  useState,
  useCallback,
} from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useHistory } from 'react-router-dom';
import * as KeyCode from 'keycode-js';
import BookStatistics from '../../../../components/Book/BookStatistics';
import BookControllers from '../../../../components/Book/BookControllers';
import QuestionElaborated from '../../../../components/Question/QuestionElaborated';
import QuestionFeedback from '../../../../components/Question/QuestionFeedback';
import QuestionBadge from '../../../../components/Question/QuestionBadge';
import Page from '../../../../components/ui/Page';
import Button from '../../../../components/ui/Button';
import Box from '../../../../components/ui/Box';
import EyeButton from '../../../../components/ui/EyeButton';
import useApi from '../../../../hooks/useApi';
import useModel from '../../../../hooks/useModel';
import useUser from '../../../../hooks/useUser';
import QuestionTagPath from '../../../../components/Question/QuestionTagPath';
import { bookPageQueryParams, privateRoutes, questionFormPageQueryParams } from '../../../../config/constants';
import {
  getNextNotAnsweredQuestionIndex,
  getNextRandomNotAnsweredQuestionIndex,
  getPrevNotAnsweredQuestionIndex,
  getStatistics as getBookStatistics,
} from '../../../../selectors/book';
import { getCorrectAnswer, isCancelled } from '../../../../selectors/question';
import { createQueryParams } from '../../../../utils/url';
import usePreviousValue from '../../../../hooks/usePreviousValue';
import useQueryParam from '../../../../hooks/useQueryParam';

import './index.scss';

const ShowBookPage = () => {
  const [book, setBook] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionindex] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [showAnswer, setShowAnswer] = useState(false);
  const [showTags, setShowTags] = useState(false);
  const [showStatistics, setShowStatistics] = useState(false);
  const [showPageMenu, setShowPageMenu] = useState(false);
  const [lastPressedKey, setLastPressedKey] = useState(null);
  const [lastPressedKeyTime, setLastPressedKeyTime] = useState(new Date());
  const { bookId, folderId } = useParams();
  const { t } = useTranslation(['book', 'common', 'question']);
  const BookAPI = useApi('book');
  const BookModel = useModel('book');
  const user = useUser();
  const history = useHistory();
  const bookStatistics = useMemo(() => getBookStatistics(book, currentQuestionIndex), [
    book,
    currentQuestionIndex,
  ]);
  const currentQuestion = book?.questions[currentQuestionIndex] ?? {};
  const prevCurrentQuestion = usePreviousValue(currentQuestion);
  const currentQuestionId = currentQuestion?.id ?? 0;
  const currentQuestionIsCancelled = useMemo(() => (
    isCancelled(currentQuestion)
  ), [currentQuestion]);
  const questionIndexQueryParam = useQueryParam(bookPageQueryParams.QUESTION_INDEX);

  const isCurrentQuestionRight = useMemo(() => {
    if (!book) return false;

    return currentQuestion.selected === getCorrectAnswer(currentQuestion)?.description;
  }, [currentQuestion, book]);

  const toggleExplanation = () => setShowExplanation(!showExplanation);
  const togglePageMenu = () => setShowPageMenu(!showPageMenu);

  const handlePaginateQuestion = (newPage) => {
    setShowExplanation(false);
    setShowAnswer(false);

    if (newPage < 0 || newPage >= bookStatistics?.total) return;

    setCurrentQuestionindex(newPage);
    setBook((prevBook) => ({ ...prevBook, current: newPage }));

    BookModel.check(user?.id, folderId, bookId, book, {
      onError: () => {},
      onSuccess: () => {},
    }, BookAPI);
  };

  const handleChangeAnswer = (newAnswer, newAnswerIndex) => {
    if (showAnswer) return;

    setBook((prevBook) => ({
      ...prevBook,
      questions: book.questions.map((question, index) => (index === currentQuestionIndex ? ({
        ...question,
        selected: newAnswer?.description,
        selectedIndex: newAnswerIndex,
      }) : ({ ...question }))),
    }));
  };

  const handleSelectBooleanOption = (truthy) => {
    const description = truthy ? 'Verdadeiro' : 'Falso';
    const newAnswer = currentQuestion?.answers.find((answer) => (
      answer.description.toUpperCase() === description.toUpperCase()));

    handleChangeAnswer(newAnswer, currentQuestion.indexOf(newAnswer));
  };

  const handleSelectAlternativeOption = (index) => {
    const newAnswer = currentQuestion?.answers?.find((answer, answerIndex) => (
      answerIndex === index));

    if (!newAnswer) return;

    handleChangeAnswer(newAnswer, index);
  };

  const handleResolveCurrentQuestion = () => {
    BookModel.check(user?.id, folderId, bookId, book, {
      onError: () => {},
      onSuccess: () => {
        setBook((prevBook) => ({
          ...prevBook,
          questions: book.questions.map((question, index) => (index === currentQuestionIndex ? ({
            ...question,
            isCorrect: isCurrentQuestionRight,
            name: question.selected,
          }) : ({ ...question }))),
        }));
      },
    }, BookAPI);

    setShowAnswer(true);
  };

  const handlePaginateToNextQuestionNotAnswered = () => {
    const indexNextQuestionNotAnswered = getNextNotAnsweredQuestionIndex(
      book,
      currentQuestionIndex,
    );

    if (indexNextQuestionNotAnswered > -1) handlePaginateQuestion(indexNextQuestionNotAnswered);
  };

  const handlePaginateToNextRandomQuestionNotAnswered = () => {
    const indexNextRandomQuestionNotAnswered = getNextRandomNotAnsweredQuestionIndex(book);

    if (indexNextRandomQuestionNotAnswered > -1) {
      handlePaginateQuestion(indexNextRandomQuestionNotAnswered);
    }
  };

  const handlePaginateToPrevQuestionNotAnswered = () => {
    const indexPrevQuestionNotAnswered = getPrevNotAnsweredQuestionIndex(
      book,
      currentQuestionIndex,
    );

    if (indexPrevQuestionNotAnswered > -1) handlePaginateQuestion(indexPrevQuestionNotAnswered);
  };

  const findBook = useCallback(() => {
    BookModel.find(user, folderId, bookId, {
      onError: () => t('common:notFound'),
      onSuccess: setBook,
    }, BookAPI);
    // eslint-disable-next-line
  }, [BookModel, BookAPI, bookId, t]);

  const handleMarkAnswer = (id, answerIindex) => setBook((prevBook) => ({
    ...prevBook,
    questions: book.questions.map((question) => (question.id === id ? ({
      ...question,
      selected: '',
      answers: question.answers.map((answer, index) => (index === answerIindex ? ({
        ...answer,
        marked: !answer?.marked,
      }) : ({ ...answer }))),
    }) : ({ ...question }))),
  }));

  const bookShortcuts = ({
    [KeyCode.KEY_RIGHT]: () => handlePaginateQuestion(currentQuestionIndex + 1),
    [KeyCode.KEY_LEFT]: () => handlePaginateQuestion(currentQuestionIndex - 1),
    [KeyCode.KEY_V]: () => handleSelectBooleanOption(true),
    [KeyCode.KEY_F]: () => handleSelectBooleanOption(false),
    [KeyCode.KEY_A]: () => handleSelectAlternativeOption(0),
    [KeyCode.KEY_B]: () => handleSelectAlternativeOption(1),
    [KeyCode.KEY_C]: () => handleSelectAlternativeOption(2),
    [KeyCode.KEY_D]: () => handleSelectAlternativeOption(3),
    [KeyCode.KEY_E]: () => handleSelectAlternativeOption(4),
    [KeyCode.KEY_SPACE]: handleResolveCurrentQuestion,
    [KeyCode.KEY_Z]: toggleExplanation,
    [KeyCode.KEY_X]: toggleExplanation,
    [KeyCode.KEY_ALT]: toggleExplanation,
    [KeyCode.KEY_O]: toggleExplanation,
    [KeyCode.KEY_N]: handlePaginateToNextQuestionNotAnswered,
    [KeyCode.KEY_P]: togglePageMenu,
  });

  const bookDoubleShortcuts = ({
    [KeyCode.KEY_V]: () => handleMarkAnswer(currentQuestionId, 0),
    [KeyCode.KEY_F]: () => handleMarkAnswer(currentQuestionId, 1),
    [KeyCode.KEY_A]: () => handleMarkAnswer(currentQuestionId, 0),
    [KeyCode.KEY_B]: () => handleMarkAnswer(currentQuestionId, 1),
    [KeyCode.KEY_C]: () => handleMarkAnswer(currentQuestionId, 2),
    [KeyCode.KEY_D]: () => handleMarkAnswer(currentQuestionId, 3),
    [KeyCode.KEY_E]: () => handleMarkAnswer(currentQuestionId, 4),
  });

  const handleKeyUp = useCallback((e) => {
    const pressedKey = e.keyCode;
    const currentTime = new Date();
    const isSameSecond = currentTime.getTime() - lastPressedKeyTime.getTime() < 1000;
    const isDoublePressedKey = pressedKey === lastPressedKey && isSameSecond;
    const shortCuts = isDoublePressedKey ? bookDoubleShortcuts : bookShortcuts;
    const currentShortCut = shortCuts[pressedKey] || bookShortcuts[pressedKey];

    if (currentShortCut) currentShortCut();

    setLastPressedKey(pressedKey);
    setLastPressedKeyTime(currentTime);
  }, [bookShortcuts, bookDoubleShortcuts, lastPressedKeyTime, lastPressedKey]);

  useEffect(() => findBook(), [findBook]);

  useEffect(() => {
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleKeyUp]);

  useEffect(() => {
    BookModel.check(user?.id, folderId, bookId, book, {
      onError: () => {},
      onSuccess: () => {},
    }, BookAPI);
    // eslint-disable-next-line
  }, [currentQuestionIndex, folderId, bookId, user, BookAPI, BookModel]);

  useEffect(() => {
    const isDifferentQuestion = prevCurrentQuestion?.id !== currentQuestion?.id;

    if (!isDifferentQuestion) return;

    setShowAnswer(Boolean(currentQuestion.name || currentQuestion.selected));
  }, [currentQuestion, prevCurrentQuestion]);

  useEffect(() => {
    if (questionIndexQueryParam) {
      setCurrentQuestionindex(Number(questionIndexQueryParam));
    }
  }, [questionIndexQueryParam]);

  return (
    <Page
      showMenu={false}
      title={(
        <p className="ShowBookPage__title">
          {t('book:title', { name: book?.name ?? '' })}
          <span className="ShowBookPage__created-at">{['(', t('book:createdAt', { createdAt: book?.formattedCreatedAt ?? '' }).replaceAll('&#x2F;', '/'), ')'].join('')}</span>
        </p>
      )}
    >
      <Box variant="ShowBookPage" flexDirection="column" justifyContent="space-between">
        <div className="ShowBookPage__header">
          <div className="ShowBookPage__statistics">
            <div className="ShowBookPage__statistics-header">
              <div className="ShowBookPage__statistics-content">
                <BookStatistics
                  {...bookStatistics}
                  showDetails={showStatistics}
                  onToggleDetails={setShowStatistics}
                />
              </div>
              <div className="ShowBookPage__badges">
                {(currentQuestion?.questionBadges ?? []).map((badge) => (
                  <QuestionBadge key={badge.name} name={badge.name} isSelected />
                ))}
              </div>
            </div>
            <div className="ShowBookPage__tags">
              <p className="ShowBookPage__tag-title">{[t('question:tags'), ':'].join('')}</p>
              <EyeButton onClick={setShowTags} isOpened={showTags} />
              {showTags && (
                <div className="ShowBookPage__tags-list">
                  {currentQuestion?.questionBranches?.map((branch) => (
                    <div
                      key={`${branch.name}-${branch.id}`}
                      className="ShowBookPage__tag-container"
                    >
                      <QuestionTagPath path={branch?.path} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="ShowBookPage__controllers">
            <BookControllers
              onPaginate={handlePaginateQuestion}
              currentPage={currentQuestionIndex}
              total={bookStatistics.total}
              onSeeExplanation={toggleExplanation}
              onPaginateToNextQuestionNotAnswered={handlePaginateToNextQuestionNotAnswered}
              onPaginateToNextRandomQuestionNotAnswered={
                handlePaginateToNextRandomQuestionNotAnswered
              }
              onPaginateToPrevQuestionNotAnswered={handlePaginateToPrevQuestionNotAnswered}
              onTogglePageMenu={togglePageMenu}
              showPageMenu={showPageMenu}
            />
          </div>
        </div>
        <div className="ShowBookPage__body">
          <QuestionElaborated
            id={currentQuestionId}
            testId={currentQuestion?.testId}
            test={currentQuestion?.test?.name ?? ''}
            description={currentQuestion?.description ?? ''}
            explanation={currentQuestion?.explanation ?? ''}
            answers={currentQuestion?.answers ?? []}
            onSelectAnswer={handleChangeAnswer}
            selected={currentQuestion?.selected ?? ''}
            selectedAnswerIndex={currentQuestion?.selectedIndex ?? 0}
            showExplanation={showExplanation}
            onMarkAnswer={handleMarkAnswer}
            showAnswer={showAnswer}
            isCancelledQuestion={currentQuestionIsCancelled}
          />
        </div>
        {showAnswer && (
          <div className="ShowBookPage__feedback">
            <QuestionFeedback
              isCancelledQuestion={currentQuestionIsCancelled}
              correct={isCurrentQuestionRight}
              onToggleExplanation={toggleExplanation}
              isCommented={currentQuestion?.isCommented}
            />
          </div>
        )}
        <div className="ShowBookPage__footer">
          <Button onClick={handleResolveCurrentQuestion} variant="ShowBookPage__footer-button">
            {t('book:resolveQuestion')}
          </Button>
          <Button
            onClick={() => history.push([
              privateRoutes.EDIT_QUESTION.path(currentQuestion.testId, currentQuestion.id),
              createQueryParams([
                {
                  key: questionFormPageQueryParams.BOOK,
                  value: JSON.stringify({
                    book: bookId,
                    folder: folderId,
                    questionIndex: currentQuestionIndex,
                  }),
                },
              ]),
            ].join('?'))}
            variant="ShowBookPage__footer-button"
          >
            {t('book:editQuestion')}
          </Button>
        </div>
      </Box>
    </Page>
  );
};

export default ShowBookPage;
