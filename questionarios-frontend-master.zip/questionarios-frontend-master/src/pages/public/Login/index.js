import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Logo from '../../../components/ui/Logo';
import Box from '../../../components/ui/Box';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import useModel from '../../../hooks/useModel';
import useApi from '../../../hooks/useApi';
import useService from '../../../hooks/useService';

import './index.scss';

const Login = () => {
  const { t } = useTranslation(['user', 'login']);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const UserModel = useModel('user');
  const UserAPI = useApi('user');
  const Alert = useService('Alert');
  const LocalStorage = useService('LocalStorage');
  const history = useHistory();

  const handleLogin = (e) => {
    e.preventDefault();

    UserModel.login(email, password, {
      onSuccess: ({ user, token }) => {
        LocalStorage.setUser(user);
        LocalStorage.setToken(token);

        UserModel.statistics(user, {
          onSuccess: ({ status }) => {
            LocalStorage.setStatus(status);

            history.push(UserModel.getMainRoute());
          },
          onError: Alert.error,
        }, UserAPI);
      },
      onError: Alert.error,
    }, UserAPI);
  };

  const handleRecoverPassword = (e) => {
    e.preventDefault();

    Alert.withInput({
      title: t('login:whatIsYourEmail'),
    }, (emailInputValue) => {
      UserAPI.recoverPassword(emailInputValue);

      Alert.success(t('login:successRecoverPasswordMessage'));
    });
  };

  return (
    <section className="Login">
      <Logo variant="Login__logo" />
      <Box variant="Login__form">
        <p className="Login__title Login__text">{t('login:title')}</p>
        <p className="Login__description Login__text">{t('login:description')}</p>
        <form onSubmit={handleLogin}>
          <Input value={email} onChange={setEmail} type="email" placeholder={t('user:attributes.email')} variant="Login__input" />
          <Input value={password} onChange={setPassword} placeholder={t('user:attributes.password')} type="password" variant="Login__input" />
          <Button variant="Login__button" type="submit" onClick={handleLogin}>{t('login:title')}</Button>
          <button onClick={handleRecoverPassword} className="Login__recover-password-button">{t('login:recoverPassword')}</button>
        </form>
      </Box>
    </section>
  );
};

export default Login;
