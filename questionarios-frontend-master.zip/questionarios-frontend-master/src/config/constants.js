export const userTypes = {
  ADMIN: 0,
  QUESTION_RECORDER: 1,
  QUESTION_RECORDER_AND_STUDENT: 2,
};

export const publicRoutes = {
  LOGIN: '/login',
};

export const questionTypes = {
  BOOLEAN: 1,
  ALTERNATIVES: 2,
};

export const privateRoutes = {
  HOME: {
    path: '/home',
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER],
  },
  NEW_USER: {
    path: '/users/new',
    roles: [userTypes.ADMIN],
  },
  LIST_USERS: {
    path: '/users',
    roles: [userTypes.ADMIN],
  },
  EDIT_USER: {
    path: (userId) => `/users/${userId}/edit`,
    roles: [userTypes.ADMIN],
  },
  NEW_TEST: {
    path: '/tests/new',
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  LIST_TESTS: {
    path: '/tests',
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  EDIT_TEST: {
    path: (testId) => `/tests/${testId}/edit`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  SHOW_TEST: {
    path: (testId) => `/tests/${testId}`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  NEW_QUESTION: {
    path: '/questions/new',
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  LIST_QUESTIONS: {
    path: (testId) => `/tests/${testId}/questions`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  IMPORT_WIZZARD: {
    path: (testId) => `/tests/${testId}/import`,    
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  TEST_WIZZARD: {
    path: (testId) => `/tests/${testId}/wizzard`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  EDIT_QUESTION: {
    path: (testId, questionId) => `/tests/${testId}/questions/${questionId}/edit`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  VIEW_QUESTION: {
    path: (questionId) => `/q/${questionId}/view`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  EDIT_IMPORT_QUESTION: {
    path: (testId, questionId) => `/tests/${testId}/questions/${questionId}/edit-import`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  EDIT_QUESTION_DIRECTLY: {
    path: (questionId) => `/q/${questionId}`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
  NEW_BOOK: {
    path: (folderId) => `/folders/${folderId}/books/new`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER],
  },
  LIST_BOOKS: {
    path: '/books',
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER],
  },
  SHOW_BOOK: {
    path: (folderId, bookId) => `/folders/${folderId}/books/${bookId}`,
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER],
  },
  TAGS: {
    path: '/tags',
    roles: [userTypes.ADMIN],
  },
  LIST_ACCESSES: {
    path: '/accesses',
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER],
  },
  TEST_TYPES: {
    path: '/test-types',
    roles: [userTypes.ADMIN],
  },
  EDIT_PASSWORD: {
    path: '/edit-password',
    roles: [userTypes.ADMIN, userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT],
  },
};

export const QUESTION_LETTERS = ['A', 'B', 'C', 'D', 'E'];

export const questionFormPageQueryParams = {
  TEST_NAME: 'test-name',
  POSITION: 'position',
  BOOK: 'book',
};

export const bookPageQueryParams = {
  QUESTION_INDEX: 'question-index',
};

export const BADGE_COLORS = {
  DESATUALIZADA: 'out-of-date',
  ADAPTADA: 'adapted',
  REVISAR: 'review',
  ANULADA: 'null',
  RASCUNHO: 'draft'
};
