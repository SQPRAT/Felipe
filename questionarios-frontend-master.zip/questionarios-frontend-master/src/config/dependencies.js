import services from '../services';
import models from '../models';

export default {
  services,
  models,
};
