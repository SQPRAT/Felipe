import { apiReponseToString } from '../utils/errors';

export const register = async (test, callback, testService) => {
  const apiReponse = await testService.register(test);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.test)
    : callback.onError(apiReponseToString(apiReponse));
};

export const search = async (queryParams, callback, testService) => {
  const apiReponse = await testService.search(queryParams);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.tests, apiReponse.pages)
    : callback.onError(apiReponseToString(apiReponse));
};

export const remove = async (testId, callback, testService) => {
  const apiReponse = await testService.remove(testId);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const find = async (testId, callback, testService) => {
  const apiReponse = await testService.find(testId);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.test)
    : callback.onError(apiReponseToString(apiReponse));
};

export const wizzard = async (testId, callback, testService) => {
  const apiReponse = await testService.wizzard(testId);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.wizzard)
    : callback.onError(apiReponseToString(apiReponse));
};

export const update = async (testId, newProps, callback, testService) => {
  const apiReponse = await testService.update(testId, newProps);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const searchBoards = async (keyword, callback, testService) => {
  const apiRseponse = await testService.searchBoards(keyword);

  return apiRseponse.ok
    ? callback.onSuccess(apiRseponse.boards)
    : callback.onError(apiReponseToString(apiRseponse));
};

export const registerType = async (testType, callback, testService) => {
  const apiReponse = await testService.registerType(testType);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.testType)
    : callback.onError(apiReponseToString(apiReponse));
};

export const all = async (callback, testService) => {
  const apiReponse = await testService.findAllTypes();

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.testTypes)
    : callback.onError(apiReponseToString(apiReponse));
};

export const removeTestType = async (testTypeId, callback, testService) => {
  const apiReponse = await testService.removeTestType(testTypeId);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};
