import * as user from './user';
import * as test from './test';
import * as question from './question';
import * as branch from './branch';
import * as book from './book';
import * as folder from './folder';
import * as badge from './badge';

export default {
  user,
  test,
  question,
  branch,
  folder,
  book,
  badge,
};
