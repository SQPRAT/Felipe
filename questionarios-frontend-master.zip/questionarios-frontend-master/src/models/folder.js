import { apiReponseToString } from '../utils/errors';

export const remove = async (userId, folderId, callback, folderService) => {
  const apiReponse = await folderService.remove(userId, folderId);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const update = async (userId, folderId, newProps, callback, folderService) => {
  const apiReponse = await folderService.update(userId, folderId, newProps);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const register = async (userId, folder, callback, folderService) => {
  const apiReponse = await folderService.register(userId, folder);

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};
