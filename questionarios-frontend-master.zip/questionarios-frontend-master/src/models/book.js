import { answersFormat, bookFormat, foldersFormat } from '../formatters/book';
import { apiReponseToString } from '../utils/errors';

export const register = async (user, folderId, book, callback, bookService) => {
  const apiReponse = await bookService.register(user.id, folderId, book);

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};

export const all = async (userId, callback, bookService) => {
  const apiReponse = await bookService.all(userId);

  if (apiReponse.ok) {
    const foldersWithBooks = foldersFormat(apiReponse?.folders ?? []);

    return callback.onSuccess(foldersWithBooks);
  }

  return callback.onError(apiReponseToString(apiReponse));
};

export const searchBoards = async (keyWord, callback, bookService) => {
  const apiReponse = await bookService.searchBoards(keyWord);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.boards)
    : callback.onError(apiReponseToString(apiReponse));
};

export const check = async (userId, folderId, bookId, book, callback, bookService) => {
  const apiReponse = await bookService.check(
    userId,
    folderId,
    bookId,
    answersFormat(book?.questions ?? []),
  );

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const remove = async (userId, folder, book, callback, bookService) => {
  const apiReponse = await bookService.remove(userId, folder.id, book.id);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const find = async (user, folderId, id, callback, bookService) => {
  const userId = user?.id ?? 0;
  const apiReponse = await bookService.find(userId, folderId, id);

  return apiReponse.ok
    ? callback.onSuccess(bookFormat(apiReponse.book))
    : callback.onError(apiReponseToString(apiReponse));
};

export const getFilters = async (callback, bookService) => {
  const apiReponse = await bookService.getFilters();

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.includerFilters, apiReponse.blockerFilters)
    : callback.onError(apiReponseToString(apiReponse));
};
