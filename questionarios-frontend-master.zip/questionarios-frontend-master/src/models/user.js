import { getUser } from '../services/LocalStorage';
import { privateRoutes, publicRoutes } from '../config/constants';
import { testFormat } from '../formatters/test';
import {
  MENU_LINKS,
  isSuperAdmin,
  isAdmin,
  isStudent,
} from '../selectors/user';
import { apiReponseToString } from '../utils/errors';

export const login = async (email, password, callback, userService) => {
  const apiReponse = await userService.login(email, password);

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};

export const statistics = async (user, callback, userService) => {
  const apiResponse = await userService.statistics(user.id);

  return apiResponse.ok
    ? callback.onSuccess({
      ...apiResponse,
      status: {
        ...apiResponse?.status,
        tests: testFormat(apiResponse?.status?.tests ?? []),
      },
    })
    : callback.onError(apiReponseToString(apiResponse));
};

export const register = async (user, callback, userService) => {
  const apiReponse = await userService.register(user);

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};

export const search = async (page, callback, userService) => {
  const apiReponse = await userService.search(page);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.users, apiReponse.pages)
    : callback.onError(apiReponseToString(apiReponse));
};

export const accesses = async (keyword, page, callback, userService) => {
  const apiReponse = await userService.accesses(keyword, page);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.accesses, apiReponse.pages)
    : callback.onError(apiReponseToString(apiReponse));
};

export const remove = async (userId, callback, userService) => {
  const apiReponse = await userService.remove(userId);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const find = async (userId, callback, userService) => {
  const apiReponse = await userService.find(userId);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.user)
    : callback.onError(apiReponseToString(apiReponse));
};

export const update = async (userId, newProps, callback, userService) => {
  const apiReponse = await userService.update(userId, newProps);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const isAuthenticated = () => Boolean(getUser());

export const getMainRoute = (user) => {
  if (isSuperAdmin(user) || isAdmin(user)) return privateRoutes.HOME.path;
  if (isStudent(user)) return privateRoutes.NEW_QUESTION.path;

  return publicRoutes.LOGIN;
};

export const getMenuLinks = (user) => (
  MENU_LINKS.filter((menuLink) => menuLink.roles.some((role) => role === user?.type))
);
