import { apiReponseToString } from '../utils/errors';

export const register = async (badge, callback, badgeService) => {
  const apiReponse = await badgeService.register(badge);

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};

export const all = async (callback, badgeService) => {
  const apiReponse = await badgeService.all();

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};
