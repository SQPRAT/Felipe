import { apiReponseToString } from '../utils/errors';

export const search = async (params, callback, branchService) => {
  const apiReponse = await branchService.search(params);

  return apiReponse.ok
    ? callback.onSuccess(apiReponse.branches, apiReponse.total)
    : callback.onError(apiReponseToString(apiReponse));
};

export const remove = async (branchId, callback, branchService) => {
  const apiReponse = await branchService.remove(branchId);

  return apiReponse.ok
    ? callback.onSuccess()
    : callback.onError(apiReponseToString(apiReponse));
};

export const register = async (branch, callback, branchService) => {
  const apiReponse = await branchService.register(branch);

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};

export const update = async (newProps, branchId, callback, branchService) => {
  const apiReponse = await branchService.update(newProps, branchId);

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};
