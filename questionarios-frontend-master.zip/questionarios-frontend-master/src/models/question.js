import { questionFormat } from '../formatters/question';
import { sortQuestionsByPosition } from '../selectors/question';
import { apiReponseToString } from '../utils/errors';

export const register = async (question, callback, questionService) => {
  const apiReponse = await questionService.register(question.test.id, questionFormat(question));

  return apiReponse.ok
    ? callback.onSuccess({ ...apiReponse })
    : callback.onError(apiReponseToString(apiReponse));
};

export const search = async (testId, page, callback, questionService) => {
  const apiReponse = await questionService.search(testId, page);

  return apiReponse.ok
    ? callback.onSuccess(sortQuestionsByPosition(apiReponse.questions), apiReponse.pages)
    : callback.onError(apiReponseToString(apiReponse));
};

export const remove = async (question, callback, questionService) => {
  const apiReponse = await questionService.remove(question.test.id, question.id);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};

export const find = async (testId, id, callback, questionService) => {
  const apiReponse = await (testId
    ? questionService.find(testId, id)
    : questionService.findDirectly(id));

  return apiReponse.ok
    ? callback.onSuccess(questionFormat(apiReponse.question))
    : callback.onError(apiReponseToString(apiReponse));
};

export const update = async (testId, id, newProps, callback, questionService) => {
  const apiReponse = await questionService.update(testId, id, newProps);

  return apiReponse.ok ? callback.onSuccess() : callback.onError(apiReponseToString(apiReponse));
};
