import useLocalStorage from './useLocalStorage';

const useUser = () => {
  const LocalStorage = useLocalStorage();
  const user = LocalStorage.getUser();

  return user;
};

export default useUser;
