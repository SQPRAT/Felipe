import { useContext } from 'react';
import { MainContext } from '../containers/Main';

const useModel = (modelName) => {
  const dependencies = useContext(MainContext);
  const { models } = dependencies;
  const model = models[modelName];

  return model;
};

export default useModel;
