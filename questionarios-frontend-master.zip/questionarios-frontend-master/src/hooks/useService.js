import { useContext } from 'react';
import { MainContext } from '../containers/Main';

const useService = (serviceName) => {
  const dependencies = useContext(MainContext);
  const { services } = dependencies;
  const service = services[serviceName];

  return service;
};

export default useService;
