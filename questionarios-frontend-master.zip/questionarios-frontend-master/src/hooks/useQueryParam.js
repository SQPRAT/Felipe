import { useLocation } from 'react-router-dom';

export default (queryKey) => {
  const queryObject = new URLSearchParams(useLocation().search);
  const queryParam = queryObject.get(queryKey);

  return queryParam;
};
