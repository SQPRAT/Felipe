import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import useApi from './useApi';
import useModel from './useModel';

export default function useTestTypeOptions() {
  const [testTypes, setTestTypes] = useState([]);
  const { t } = useTranslation(['common']);
  const TestModel = useModel('test');
  const TestAPI = useApi('test');

  useEffect(() => {
    const fetchTestTypes = async () => {
      TestModel.all({
        onError: () => t('common:notFound'),
        onSuccess: setTestTypes,
      }, TestAPI);
    };

    fetchTestTypes();
  }, [TestModel, TestAPI, t]);

  const testOptions = useMemo(() => [{value: '', label: t('common:selectOption')}].concat(testTypes.map((testType) => ({
    value: testType.id,
    label: testType.name,
  }))), [testTypes]);

  return testOptions;
}
