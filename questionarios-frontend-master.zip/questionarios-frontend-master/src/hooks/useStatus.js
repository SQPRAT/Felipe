import useLocalStorage from './useLocalStorage';

const useStatus = () => {
  const LocalStorage = useLocalStorage();
  const status = LocalStorage.getStatus();

  return status;
};

export default useStatus;
