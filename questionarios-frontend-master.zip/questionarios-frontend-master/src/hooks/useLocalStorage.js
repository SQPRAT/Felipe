import useService from './useService';

const useStorage = () => {
  const LocalStorage = useService('LocalStorage');

  return LocalStorage;
};

export default useStorage;
