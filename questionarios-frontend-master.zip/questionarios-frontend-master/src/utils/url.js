const createParam = (key, value) => `${key}=${value}`;

export const createQueryParams = (paramsArray) => {
  const stringParamsArray = paramsArray?.map(({ key, value }) => createParam(key, value)) ?? [];
  const stringQuery = stringParamsArray.join('&');

  return stringQuery;
};
