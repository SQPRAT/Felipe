export const apiReponseToString = (apiReponse) => apiReponse?.errors?.join(' ') ?? '';
