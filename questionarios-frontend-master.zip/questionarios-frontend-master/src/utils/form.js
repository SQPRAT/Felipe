export const filterFields = (hideConfig, fields) => {
  const hideKeys = Object
    .entries(hideConfig).filter(([, value]) => Boolean(value)).map(([key]) => key);
  const object = Object
    .fromEntries(Object.entries(fields).filter(([key]) => !hideKeys.includes(key)));

  return object;
};

export const toFormData = (object) => {
  const formData = new FormData();

  Object.entries(object).forEach(([key, value]) => {
    if (key === 'files') {
      value.forEach((file) => (
        formData.append('files', file)
      ));
    } else {
      formData.append(key, value);
    }
  });

  return formData;
};
