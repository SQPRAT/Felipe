import ptBR from './pt-BR';

export default {
  'pt-BR': ptBR,
};
