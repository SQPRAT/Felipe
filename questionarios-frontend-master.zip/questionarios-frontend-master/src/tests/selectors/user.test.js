import * as User from '../../selectors/user';
import { userTypes } from '../../config/constants';

describe('User selector', () => {
  describe('isSuperAdmin', () => {
    const notAdminsTypes = [userTypes.QUESTION_RECORDER, userTypes.QUESTION_RECORDER_AND_STUDENT];

    notAdminsTypes.forEach((type) => {
      it('returns falsy', () => {
        expect(User.isSuperAdmin({ type })).toBeFalsy();
      });
    });

    it('returns truthy', () => {
      const user = { type: userTypes.ADMIN };

      expect(User.isSuperAdmin(user)).toBeTruthy();
    });
  });
});
