import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import QuestionAnswer from '../../../components/Question/QuestionAnswer';

describe('<QuestionAnswer />', () => {
  const renderQuestionAnswer = overrideProps => {
    const defaultProps = {
      explanation: 'explanation',
      description: 'description',
      isSelected: false,
      showAnswer: false,
      showExplanation: true,
      letter: 'A',
      isCorrect: false,
    };
    const { container, getByText } = render(<QuestionAnswer {...defaultProps} {...overrideProps} />);

    return { container, getByText };
  };

  it('renders the component', () => {
    const { container } = renderQuestionAnswer();

    expect(container).toBeInTheDocument();
  });

  it('renders description', () => {
    const description = 'I am the description';
    const { getByText } = renderQuestionAnswer({ description });

    expect(getByText(description)).toBeInTheDocument();
  });

  it('renders the explanation', () => {
    const explanation = 'I am the explanation';
    const { getByText } = renderQuestionAnswer({ explanation, showAnswer: true });

    expect(getByText(explanation)).toBeInTheDocument();
  });
});
