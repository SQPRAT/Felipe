import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import BookControl from '../../../components/Book/BookControl';

describe('<BookControl />', () => {
  const renderBookControl = overrideProps => {
    const defaultProps = {
      children: 'children',
      onClick: jest.fn(),
    };
    const { container, getByText } = render(<BookControl {...defaultProps} {...overrideProps} />);

    return { container, getByText };
  };

  it('renders the components', () => {
    const { container } = renderBookControl();

    expect(container).toBeInTheDocument();
  });

  it('renders children', () => {
    const children = 'I am the children';
    const { container, getByText } = renderBookControl({ children });

    expect(getByText(children)).toBeInTheDocument();
  });

  it('calls onClick', () => {
    const children = 'I am the children';
    const onClick = jest.fn();
    const { getByText } = renderBookControl({ children, onClick });

    fireEvent.click(getByText(children));

    expect(onClick).toHaveBeenCalled();
  });
});
