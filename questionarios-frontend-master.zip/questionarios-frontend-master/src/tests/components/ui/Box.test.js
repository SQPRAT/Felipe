import React from 'react';
import Box from '../../../components/ui/Box';
import { render } from '@testing-library/react';

describe('<Box />', () => {
  const renderBox = overrideProps => {
    const defaultProps = {
      children: 'children',
    };
    const { container, getByText } = render(<Box {...defaultProps} {...overrideProps} />);

    return { container, getByText };
  };

  it('renders the component', () => {
    const { container } = renderBox();

    expect(container).toBeVisible();
  });

  it('renders children', () => {
    const children = 'I am the children!';
    const { getByText } = renderBox({ children });

    expect(getByText(children)).toBeVisible();
  });
});
