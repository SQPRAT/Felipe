import React from 'react';
import Paginate from '../../../components/ui/Paginate';
import { render, fireEvent, getByText } from '@testing-library/react';

describe('<Paginate />', () => {
  const renderPaginate = overrideProps => {
    const defaultProps = {
      onChange: jest.fn(),
      amountOfPages: 1,
    };
    const { container, getByText } = render(<Paginate {...defaultProps} {...overrideProps} />);

    return { container, getByText };
  };

  it('renders the component', () => {
    const { container } = renderPaginate();

    expect(container).toBeVisible();
  });

  it('renders pages', () => {
    const amountOfPages = 5;
    const { getByText } = renderPaginate({ amountOfPages });

    expect(getByText('1')).toBeVisible();
    expect(getByText('2')).toBeVisible();
    expect(getByText('3')).toBeVisible();
    expect(getByText('4')).toBeVisible();
    expect(getByText('5')).toBeVisible();
  });

  it('calls onChange', () => {
    const amountOfPages = 5;
    const onChange = jest.fn();
    const { getByText } = renderPaginate({ amountOfPages, onChange });

    fireEvent.click(getByText('5'));

    expect(onChange).toHaveBeenCalledWith(amountOfPages - 1);
  });
});
