import React from 'react';
import Select from '../../../components/ui/Select';
import { render, fireEvent } from '@testing-library/react';

describe('<Select />', () => {
  const renderSelect = overrideProps => {
    const defaultProps = {
      value: 1,
      onChange: jest.fn(),
      options: [],
    };
    const { container, getByText } = render(<Select {...defaultProps} {...overrideProps} />);

    return { container, getByText };
  };

  it('renders the component', () => {
    const { container } = renderSelect();

    expect(container).toBeVisible();
  });

  it('renders the placeholder', () => {
    const placeholder = 'I am the placeholder!';
    const { getByText } = renderSelect({ placeholder });

    expect(getByText(placeholder)).toBeVisible();
  });

  it('renders options', () => {
    const option = { value: 1, label: 'Label!' };
    const { getByText } = renderSelect({ options: [option] });

    expect(getByText(option.label)).toBeVisible();
  });
});
