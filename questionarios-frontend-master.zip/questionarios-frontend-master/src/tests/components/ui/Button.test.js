import React from 'react';
import Button from '../../../components/ui/Button';
import { render, fireEvent } from '@testing-library/react';

describe('<Button />', () => {
  const renderButton = overrideProps => {
    const defaultProps = {
      children: 'children',
      onClick: jest.fn(),
    };
    const { container, getByText } = render(<Button {...defaultProps} {...overrideProps} />);

    return { container, getByText };
  };

  it('renders the component', () => {
    const { container } = renderButton();

    expect(container).toBeVisible();
  });

  it('calls onClick', () => {
    const onClick = jest.fn();
    const buttonContent = 'Click me!';
    const { getByText } = renderButton({ onClick, children: buttonContent });

    fireEvent.click(getByText(buttonContent));

    expect(onClick).toHaveBeenCalled();
  });

  it('renders the children', () => {
    const children = 'I am children!';
    const { getByText } = renderButton({ children });

    expect(getByText(children)).toBeVisible();
  });
});
